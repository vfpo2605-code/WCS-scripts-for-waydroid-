# Module management

Magisk module validation and lifecycle operations are implemented in `core/module_manager.py` and delegated to Magisk's native installer and marker conventions. No module payload is bundled.
