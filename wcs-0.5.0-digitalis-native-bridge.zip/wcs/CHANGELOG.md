# Changelog

## 0.5.0 - 2026-11-15

- Added Digitalis/Berberis as a third, distinct ARM64-to-x86_64 Native Bridge provider. WCS does not combine the proprietary libndk and libhoudini binaries or claim to have written a new translator engine.
- Added a pinned 74-artifact Digitalis bundle for WayDroid-ATV LineageOS 23.2 / Android 16 QPR2, with a pinned Git manifest object and per-artifact SHA-256 checks.
- Added strict compatibility gates for Android 16 QPR2, x86_64 host/guest and `mount_overlays=True`; generic Android 16, Android 17 and unverified ROM/builds are refused before overlay changes.
- Digitalis installation now copies the complete host bridge, ARM64 guest Bionic/linker/app_process, runner, binfmt configuration, init hook and proxy libraries; masks the image's competing `ndk_translation` binfmt init hook.
- All WCS-managed Native Bridge installs now persist the provider in `[properties]`, `[waydroid]` and `/data/misc/waydroid_settings`, then run `waydroid upgrade --offline` to regenerate Waydroid's derived configuration.
- Added integrity checks for installed Digitalis files and configuration, transactional rollback, and restoration of overlay files, INI settings and Android data settings when removing or switching providers.
- Added host-side regression tests for manifest pinning, path traversal, ELF machine checks, QPR2 image gating, installation, selector persistence and rollback. Real Waydroid boot and APK execution remain unverified here.

## 0.4.1 - 2026-11-15

- Added real `libndk` and `libhoudini` Native Bridge installers for Waydroid x86_64 on Android 11 and 13, using pinned upstream archives and checksum verification.
- The selected WCS translator now overrides an image-provided Native Bridge through the Waydroid system overlay instead of skipping installation when the image already declares a translator.
- Added overlay file and Waydroid property snapshots with restore-on-remove and restore-before-switch behavior; only one of libndk/libhoudini can be active at a time.
- Added the upstream Houdini `houdini.rc` binfmt_misc registration hook, which is generated during installation and included in rollback/removal.
- Added strict payload completeness, archive size/CRC, path-traversal, and symlink checks; Android versions without a matching pinned payload (including Android 16/17) are refused without modifying the image.
- Added host tests for image-provided translator replacement, translator switching/removal, Houdini init hook generation, incomplete payload rejection, and Android 17 refusal.

## 0.4.0 - 2026-11-13

- Corrigido o transporte de ZIPs de módulos Magisk: a instalação agora envia `magisk --install-module` pelo stdin de `waydroid shell`, evitando que o parser do Waydroid consuma `--install-module` como argumento do host.
- O WCS exige um marcador explícito do código de saída do Magisk dentro do Android; uma saída zero do Waydroid sem confirmação do guest não é considerada sucesso.
- Mantida a limpeza do ZIP temporário tanto em sucesso quanto em falha e adicionados testes de regressão para transporte, código de saída e validação do nome remoto.

- Expandido o reconhecimento para os canais OTA oficiais Waydroid, separados das releases WayDroid-ATV.
- Adicionado catálogo de manifestos oficiais por arquitetura, ROM (`lineage`/`bliss`) e tipo (`VANILLA`/`FOSS`/`GAPPS`); combinações sem manifesto são omitidas.
- Ampliado o mapeamento de versões Android por API de 26 a 37 (Android 8.0–17), sem presumir que todas as imagens são Android 16/17.
- A troca de imagem passou a usar os parâmetros e canais oficiais do `waydroid init -f`, preservando o `images_path` configurado e deixando o Waydroid resolver arquitetura e vendor type.
- Removido `waydroid upgrade` redundante após `waydroid init`: o inicializador upstream já baixa, valida por SHA-256 e extrai o par system/vendor.
- Adicionada proteção para não iniciar uma troca OTA em diretórios preinstalled padrão, porque o Waydroid ignora os canais quando encontra imagens pré-instaladas.
- Adicionada proteção que bloqueia troca de imagem enquanto o adaptador Magisk WCS está aplicado, evitando invalidar os hooks/overlays gerenciados pelo WCS.
- Expandida a arquitetura detectada para x86, x86_64, ARM e ARM64 e o catálogo inclui o alvo arm64_only quando publicado.
- Atualizadas a documentação de compatibilidade, paridade do Waydroid Script e matriz de testes para imagens oficiais e customizadas.
- Adicionados testes para parse de OTA oficial, mapeamento API, catálogo real/404 e pré-condições da seleção oficial de imagem.
- Adicionado o comando somente leitura `wcs microg` e o campo `microg_diagnostics` em `wcs extras`, com evidências de pacotes, permissões privilegiadas, WebView, Custom Tabs e GServices.
- O diagnóstico microG mantém spoofing de assinatura e autenticação como `RUNTIME_REQUIRED`; Self-Check, registro, login, sincronização e Play Store/Aurora continuam exigindo validação no guest real.

## 0.3.0 - 2026-11-13

- Reintroduced the full original Waydroid Script component catalog in the interactive menu and CLI: GApps, microG, libndk, libhoudini, Magisk, Widevine, Smart Dock, F-Droid Privileged Extension, custom CA, nodataperm and hide-status-bar.
- Added a modern microG Magisk-module installer that discovers the official stable release and requires the GitHub-published SHA-256 digest before installation; it refuses to install over detected GApps and Android 17 is blocked because the selected module does not document API 37 support.
- Added Smart Dock installation from the current official F-Droid APK as a regular Android app.
- Added a systemless F-Droid Privileged Extension module generated from the official F-Droid OTA ZIP.
- Added a systemless Conscrypt APEX CA module for user-supplied PEM certificates, marked experimental until runtime reboot testing.
- Added an explicit GAPPS/VANILLA image-variant switch using the WayDroid-ATV Android 16/17 OTA channels, with an image-pair backup and explicit confirmation.
- libndk/libhoudini and Widevine now appear in the catalog with detection and safe compatibility gates; old blobs are not forced over Android 16/17 images.
- The old Android 11-only nodataperm and hide-status-bar installers are present in the catalog but refuse to patch Android 16/17.
- Added tests for feature catalog parity, microG asset digest requirements, blocked legacy hacks, module packaging, and image-variant preconditions.

## 0.1.1 - 2026-11-12

- Stop the Waydroid user session before stopping the container; poll Waydroid status and direct LXC state instead of failing on an immediate status race.
- Treat frozen, freezing and aborting states as active, so image writes remain blocked until shutdown is confirmed.
- When the overlay has no `bootanim.rc`, mount the configured `system.img` read-only and copy the stock init file into the overlay as a new override.
- Preserve the original overlay state for rollback and uninstall.
- Added regression tests for shutdown, timeout handling, read-only image source and empty overlay layers.

## 0.1.0 - 2026-11-12

- Initial WCS source package with host detection, release catalog, image fingerprinting and verified paired image backups/restoration.
- Experimental pinned Magisk 31.0 Waydroid overlay adapter with byte-level patch guards and baseline recovery.
- Magisk-native module ZIP validation and lifecycle operations.
- No Android runtime compatibility claims without target-image test evidence.

## 0.2.0

- Iniciada a reconstrução funcional dos recursos do Waydroid Script original.
- Adicionado gerenciamento de APKs via `waydroid app install/list/remove`.
- Adicionada obtenção validada do Android ID para certificação Google Play.
- Adicionada inspeção runtime de GSF, Play Services, Play Store, pacotes microG, Native Bridge e bibliotecas Widevine.
