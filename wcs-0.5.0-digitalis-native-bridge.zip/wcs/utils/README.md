# Utilities

Shared host primitives currently live in `core/common.py` to avoid duplicating path, command, checksum, and download behavior. This directory is reserved for standalone helper assets when a real need appears.
