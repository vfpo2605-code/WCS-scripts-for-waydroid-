# Digitalis QPR2 prebuilt bundle notice

The WCS Digitalis installer downloads (it does not include in the WCS ZIP) the
74-file `digitalis-qpr2` bundle from the pinned Refract repository commit:

- Repository: https://github.com/MIXIDtheSilly/Refract
- Commit: `ddef6e6ae7de37dd3e400d6a07d3f18cb21a0ebc`
- Bundle path: `prebuilts/digitalis-qpr2`
- Build date: 2026-10-08
- Target product: `sdk_phone64_x86_64_digitalis`
- Manifest Git blob: `36cecbaef116a541e6a807dde6bcb6bfad076b18`

License and provenance summary from the upstream bundle `NOTICE`:

- Digitalis/Berberis files (`system/lib64/libberberis_*`,
  `system/bin/berberis_program_runner_*`, `system/etc/*`) are identified as
  Apache License 2.0 components from AOSP
  `frameworks/libs/binary_translation`.
- The ARM64 guest libraries and linker are built from AOSP and retain their
  individual upstream licenses. The bundle notice identifies the principal
  families as Apache 2.0, Bionic BSD-style, ICU Unicode, BoringSSL
  OpenSSL/ISC, zlib license, SQLite public domain, and libc++ Apache 2.0 with
  LLVM exception.
- The `libberberis_arm64.so` bundle file includes changes maintained in
  Refract's `tools/translator/` area.
- The upstream notice states that the binaries are supplied "AS IS", without
  warranty. Refer to the pinned repository's actual `NOTICE` and each AOSP
  component's license for the complete legal terms; this summary is not a
  replacement for those texts.

The bundle is specifically built for Android 16 QPR2's Bionic layout. It is not
interchangeable with Android 16 QPR0 or Android 17. WCS gates installation to
the matching WayDroid-ATV LineageOS 23.2 / QPR2 image and verifies each artifact
against the pinned SHA-256 manifest before writing to the system overlay.
