# Waydroid Custom Script (WCS)

**Versão:** 0.5.0 · **Licença:** GPL-3.0-or-later · **Runtime:** Python 3.10+ (biblioteca padrão)

WCS é um gerenciador independente para instalações Waydroid. A partir da versão 0.4.0, ele reconhece os canais OTA oficiais do Waydroid, as imagens pré-instaladas/customizadas e as releases adicionais do WayDroid-ATV. O suporte aos canais oficiais não depende de uma geração específica do Android nem de uma única variante GAPPS/VANILLA.

## Imagens oficiais reconhecidas

O WCS trabalha com as opções expostas pelo inicializador oficial do Waydroid:

| Dimensão | Opções |
|---|---|
| ROM | `lineage`, `bliss` |
| Tipo de sistema | `VANILLA`, `FOSS`, `GAPPS` |
| Arquiteturas de catálogo | `x86_64`, `x86`, `arm64`, `arm`, `arm64_only` |
| Android detectável pelo SDK | API 26–37 (Android 8.0–17) |

A disponibilidade é específica de cada combinação: o catálogo consulta os manifestos OTA e omite combinações que o servidor oficial não publica (HTTP 404). `arm64_only` também é exibida quando há manifesto publicado; o inicializador escolhe a arquitetura executável para o host, não força uma arquitetura incompatível.

O Waydroid oficial usa os canais `https://ota.waydro.id/system` e `https://ota.waydro.id/vendor`. O WCS não constrói nomes de ZIP nem inventa tipo de vendor: para troca de imagem, passa ROM, tipo de sistema e caminho de imagens ao `waydroid init`, que resolve arquitetura e vendor OTA e valida os arquivos usando os hashes dos manifestos oficiais.

O WayDroid-ATV continua disponível em um catálogo separado. Ele não é confundido com os canais oficiais do Waydroid.

## Instalação e uso

Extraia o pacote e execute o instalador:

```bash
sudo bash install.sh
wcs --version
wcs --help
```

Para executar a versão diretamente do diretório extraído:

```bash
./wcs --help
./wcs info
```

## Catálogo oficial e imagem instalada

```bash
# Combinações publicadas para a arquitetura deste computador
wcs images catalog

# Todos os alvos de arquitetura, ROM e tipo de sistema com manifesto publicado
wcs images catalog --arch all --rom all --type all

# Filtrar Bliss, GAPPS, x86_64
wcs images catalog --arch x86_64 --rom bliss --type GAPPS

# Releases WayDroid-ATV, em catálogo separado
wcs images atv-catalog --android all

# Examinar os manifestos configurados na instalação atual
wcs images ota

# Verificar presença e hashes locais de system.img/vendor.img
wcs images verify

# Trocar para uma imagem oficial. A operação exige confirmação e cria backup.
sudo wcs images switch --rom lineage --type VANILLA
sudo wcs images switch --rom bliss --type FOSS --yes
sudo wcs images switch --rom lineage --type GAPPS --yes
```

`waydroid init -f` já baixa, valida e extrai as imagens de system e vendor. O WCS não executa um `waydroid upgrade` adicional depois disso. O caminho atual de imagens é passado com `--images_path` para evitar mudar acidentalmente o diretório configurado.

Antes da troca, o WCS cria um backup verificado de `system.img` e `vendor.img`. **O backup não inclui `/data` nem os dados dos aplicativos.** O inicializador oficial também pode recriar a camada writable do overlay. Por segurança, WCS bloqueia a troca enquanto sua integração Magisk estiver aplicada no overlay. Remova-a primeiro com `sudo wcs root remove`.

Imagens pré-instaladas localizadas em `/etc/waydroid-extra/images` ou `/usr/share/waydroid-extra/images` são reconhecidas como `PREINSTALLED_OR_NO_OTA`. Nessa situação, a troca automática por OTA é bloqueada: o próprio inicializador oficial dá prioridade a essas imagens e ignora os canais OTA. Inspeção, verificação local e backup continuam disponíveis.

## Detecção de imagens oficiais e personalizadas

```bash
wcs info
wcs doctor
wcs images ota
wcs images verify
wcs compatibility --android 13
wcs compatibility --android 16
```

O WCS lê `system_ota`, `vendor_ota`, `images_path`, arquitetura, tipo de vendor e propriedades Android reais quando o contêiner está em execução. Imagens pré-instaladas sem OTA não são tratadas como erro nem como uma release específica. Quando o Waydroid está parado e o canal não codifica a versão Android, a versão fica como `UNKNOWN` até uma leitura real do SDK.

## Recursos recriados do Waydroid Script

```bash
wcs features
sudo wcs install microg
sudo wcs install smartdock
sudo wcs install fdroidpriv
sudo wcs install digitalis  # somente imagem WayDroid-ATV Android 16 QPR2 compatível
sudo wcs install mitm --ca-cert ~/Downloads/proxy-ca.pem
sudo wcs install gapps --variant GAPPS --rom lineage --yes
sudo wcs remove microg
```

O catálogo mantém os onze componentes herdados do Waydroid Script e acrescenta `digitalis`, um terceiro provider de Native Bridge ARM64→x86_64. `libndk` e `libhoudini` continuam com seus instaladores próprios para Android 11/13 x86_64 e são mutuamente exclusivos. Para uma combinação específica Android 16 QPR2, WCS 0.5.0 também integra o engine **Digitalis/Berberis** (backend de tradução binária do AOSP), com um bundle precompilado para WayDroid-ATV LineageOS 23.2 / release 20260717. Isso não combina nem converte os binários proprietários de libndk/Houdini: é um terceiro engine, separado, selecionado pela propriedade Native Bridge do Android.

**Digitalis só é instalado quando o WCS confirma Android 16 QPR2, host e guest x86_64, `mount_overlays=True` e o canal `a16-qpr2` ou a identificação da release WayDroid-ATV 20260717.** O bundle tem 74 artefatos, commit upstream fixado, manifesto também fixado e SHA-256 verificado individualmente. O WCS salva os arquivos que o overlay substitui, define o provider em `[waydroid]`, `[properties]` e `/data/misc/waydroid_settings`, mascara o registro concorrente de `ndk_translation` e executa `waydroid upgrade --offline` para regenerar a configuração. A remoção restaura os arquivos e os três locais de configuração. Android 17, Android 16 genérico/QPR0 e outras imagens não recebem esse bundle QPR2; o WCS mantém a Native Bridge da imagem em vez de forçar bibliotecas Bionic incompatíveis.

Instalar ou alternar providers (Waydroid deve estar parado; a imagem precisa usar overlay):

```bash
sudo wcs install digitalis    # Digitalis/Berberis para o alvo Android 16 QPR2 suportado
sudo wcs remove digitalis     # restaura overlay e configuração anteriores
sudo wcs install libndk       # alternativa para Android 11/13 x86_64
sudo wcs install libhoudini   # alternativa para Android 11/13 x86_64
```

Somente um provider pode ficar ativo por vez. Os downloads e backups ficam em `/var/lib/wcs`; Digitalis usa `/var/lib/wcs/cache/digitalis-qpr2` e compartilha a transação de overlay em `/var/lib/wcs/arm-translation`. O Digitalis não fornece driver gráfico/Vulkan: a execução de jogos Vulkan continua dependendo do stack gráfico da imagem e do host. A instalação dos arquivos não garante que todo APK ARM64 execute; boot, ART e aplicativos reais precisam de teste no Waydroid de destino.

- **microG:** módulo systemless DresOS, restrito a Android API 26–36 e imagem sem componentes GApps. Requer Magisk e suporte à assinatura falsa fornecido pela ROM. A presença de um instalador não comprova login Google nem corrige automaticamente todo problema de autenticação.
- **Smart Dock:** APK normal da origem F-Droid.
- **F-Droid Privileged e certificado CA:** módulos Magisk experimentais, exigem reinicialização e verificação real.
- **Magisk:** adaptador WCS 31.0 com patches binários fixados; experimental e limitado às APIs/ABIs documentadas em `docs/COMPATIBILITY.md`.

## APKs, módulos e certificação

```bash
wcs apps list
wcs apps install ~/Downloads/aplicativo.apk
wcs apps remove com.exemplo.aplicativo

sudo wcs modules list
sudo wcs modules install ./modulo.zip
sudo wcs modules enable modulo_id
sudo wcs modules disable modulo_id
sudo wcs modules remove modulo_id
```

A instalação de ZIPs é executada dentro do Android pelo stdin de `waydroid shell`. O WCS não passa `--install-module` como argumento do comando Waydroid e só confirma sucesso quando recebe o código de saída explícito do Magisk.

```bash
wcs certified
wcs extras
wcs microg
```

`wcs microg` executa um probe somente leitura dentro do guest: registra pistas de pacotes, localização privilegiada, allowlists, indicador de `FAKE_PACKAGE_SIGNATURE`, WebView/Custom Tabs e estado do banco GServices. Os nomes `com.google.android.*` também podem pertencer a GApps e não são prova de microG. O resultado mantém `signature_spoofing.status` e `authentication.status` como `RUNTIME_REQUIRED`: o teste autoritativo é **microG Settings → Self-Check**, especialmente “System spoofs signature”, seguido de registro do dispositivo, login real, sincronização e teste de Play Store/Aurora. O módulo DresOS não inclui Zygisk/Xposed para spoofing.

## Backups

```bash
sudo wcs backup create
sudo wcs backup list
sudo wcs backup restore NOME_DO_BACKUP
```

Os backups de imagem incluem apenas `system.img` e `vendor.img`. Os backups do adaptador Magisk são separados e protegem apenas os caminhos de overlay pertencentes ao WCS.

## Limites de validação

Os testes automatizados verificam detecção, parsing de manifestos, argumentos enviados ao inicializador oficial, backups, validação de ZIPs e bloqueios de segurança. Eles não inicializam Android dentro do host de testes e não substituem um Fedora real com SELinux Enforcing. Magisk, daemon/MagiskSU, Zygisk, LSPosed/Vector, microG, Widevine, permissões privilegiadas, AVCs do host e login Google ainda precisam ser validados em boots reais para cada imagem/ABI. A matriz fica em [`docs/COMPATIBILITY.md`](docs/COMPATIBILITY.md) e os critérios em [`docs/TEST-PLAN.md`](docs/TEST-PLAN.md).

WCS não instala pacotes no host e não altera kernel, firewall, serviços systemd ou a configuração de rede do Waydroid.
