#!/usr/bin/env bash
set -euo pipefail
PREFIX="${PREFIX:-/usr/local}"
DEST="$PREFIX/lib/wcs"

if [[ $EUID -ne 0 ]]; then
  echo "Execute com sudo: sudo bash uninstall.sh" >&2
  exit 1
fi
if [[ "$PREFIX" != /* || "$PREFIX" == *"/../"* || "$PREFIX" == */.. ]]; then
  echo "PREFIX deve ser um caminho absoluto sem componentes '..'." >&2
  exit 1
fi

check_no_symlink_components() {
  local path="$1" current="/" part
  local -a parts=()
  IFS='/' read -r -a parts <<< "${path#/}"
  for part in "${parts[@]}"; do
    [[ -n "$part" ]] || continue
    current="${current%/}/$part"
    if [[ -L "$current" ]]; then
      echo "Caminho de instalação contém link simbólico: $current" >&2
      exit 1
    fi
  done
}

for path in "$PREFIX" "$PREFIX/lib" "$DEST" "$PREFIX/bin"; do
  check_no_symlink_components "$path"
done
if [[ -L "$PREFIX/bin/wcs" ]]; then
  if [[ "$(readlink -- "$PREFIX/bin/wcs")" != "$DEST/wcs" ]]; then
    echo "O link $PREFIX/bin/wcs não aponta para a instalação WCS esperada; nada foi removido." >&2
    exit 1
  fi
  rm -f -- "$PREFIX/bin/wcs"
elif [[ -e "$PREFIX/bin/wcs" ]]; then
  echo "O arquivo $PREFIX/bin/wcs não é o link simbólico do WCS; nada foi removido." >&2
  exit 1
fi
if [[ -e "$DEST" ]]; then
  [[ -d "$DEST" ]] || { echo "Destino WCS não é diretório: $DEST" >&2; exit 1; }
  rm -rf -- "$DEST"
fi
echo "Código do WCS removido. Backups em /var/lib/wcs e modificações do Waydroid não foram apagados."
