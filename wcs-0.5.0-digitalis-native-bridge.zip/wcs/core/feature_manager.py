# SPDX-License-Identifier: GPL-3.0-or-later
"""Modern, guarded replacements for the feature installers in waydroid_script.

WCS deliberately does not transplant legacy Android 11/13 image patches into
official Waydroid OTA images (LineageOS/Bliss; VANILLA/FOSS/GAPPS) and WayDroid-ATV.
Features are gated by detected Android API and actual image capabilities.
"""
from __future__ import annotations

import hashlib
import io
import os
import re
import stat
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

from . import arm_translation, backup, digitalis_translation, extras, image_manager, module_manager, root_manager
from .common import STATE_DIR, WCS_VERSION, WCSError, ensure_no_symlink_path, fetch_json, require_root, run_command, sha256_file
from .detection import inspect, require_supported_android, require_android_16_or_17, require_stopped

MICROG_REPO = "The-DresOS-Foundation/DresOS-Magisk-Modules"
MICROG_RELEASES_API = f"https://api.github.com/repos/{MICROG_REPO}/releases?per_page=100"
FDROID_SMARTDOCK_PAGE = "https://f-droid.org/packages/cu.axel.smartdock/"
FDROID_PRIVILEGED_ZIP = "https://f-droid.org/repo/org.fdroid.fdroid.privileged.ota_2130.zip"
MAX_DOWNLOAD = 128 * 1024 * 1024

FEATURES: tuple[dict[str, str], ...] = (
    {"id": "gapps", "name": "Google Apps / tipo de imagem", "kind": "image", "status": "OFFICIAL_OTA_SWITCH", "description": "Troca a imagem oficial entre VANILLA, FOSS e GAPPS; aceita LineageOS ou Bliss e usa os canais OTA oficiais do Waydroid."},
    {"id": "microg", "name": "microG + componentes Aurora", "kind": "module", "status": "MAGISK_API26_TO36_VANILLA", "description": "Módulo systemless oficial de microG. Requer Magisk, imagem sem GApps e ROM com suporte à assinatura falsa; API 37 ainda bloqueada pelo mantenedor do módulo."},
    {"id": "libndk", "name": "libndk ARM translation", "kind": "overlay", "status": "INSTALLABLE_ANDROID11_13_X86_64", "description": "Instalador real do pacote Google/Guybrush para host x86_64; substitui a Native Bridge selecionada na imagem via overlay. Alternativa ao libhoudini: somente um pode ficar ativo."},
    {"id": "libhoudini", "name": "libhoudini ARM translation", "kind": "overlay", "status": "INSTALLABLE_ANDROID11_13_X86_64", "description": "Instalador real do pacote Intel/WSA para host x86_64; substitui a Native Bridge selecionada na imagem via overlay. Alternativa ao libndk: somente um pode ficar ativo."},
    {"id": "digitalis", "name": "Digitalis / Berberis ARM64 translation", "kind": "overlay", "status": "EXPERIMENTAL_ANDROID16_QPR2_WAYDROID_ATV", "description": "Native Bridge ARM64→x86_64 baseado no backend aberto Berberis/Digitalis. Bundle QPR2 fixado para WayDroid-ATV LineageOS 23.2 / Android 16 QPR2; não é compatível genericamente com Android 16/17. Exige imagem x86_64 e overlay habilitado."},
    {"id": "magisk", "name": "Magisk adaptado para Waydroid", "kind": "root", "status": "EXPERIMENTAL_API30_TO37", "description": "Adaptador Magisk 31.0, com patches binários fixados e suporte a x86/x86_64/ARM/ARM64 quando os binários existem; boot/runtime precisam ser validados por imagem."},
    {"id": "widevine", "name": "Widevine DRM L3", "kind": "detect", "status": "DETECT_ONLY", "description": "Detecta bibliotecas Widevine presentes. O WCS não instala blobs antigos em imagens modernas sem pacote específico e validado."},
    {"id": "smartdock", "name": "Smart Dock", "kind": "apk", "status": "INSTALLABLE_API26_TO37", "description": "Instala a versão atual assinada pelo F-Droid como aplicativo normal nas imagens Waydroid compatíveis."},
    {"id": "fdroidpriv", "name": "F-Droid Privileged Extension", "kind": "module", "status": "INSTALLABLE_EXPERIMENTAL_API26_TO37", "description": "Empacota o OTA oficial como módulo Magisk systemless; depende do funcionamento do Magisk na imagem."},
    {"id": "mitm", "name": "Certificado CA personalizado", "kind": "module", "status": "INSTALLABLE_EXPERIMENTAL_API30_TO37", "description": "Cria módulo Magisk para a trust store Conscrypt APEX; requer Magisk e reinicialização."},
    {"id": "nodataperm", "name": "Hack nodataperm", "kind": "legacy", "status": "LEGACY_NOT_PORTED", "description": "O patch substitui services.jar e depende de versões exatas do framework. Não é aplicado em todas as imagens oficiais."},
    {"id": "hidestatusbar", "name": "Ocultar barra de status", "kind": "legacy", "status": "LEGACY_NOT_PORTED", "description": "O APK overlay antigo não tem matriz de compatibilidade atual para todas as imagens oficiais."},
)


def catalog() -> list[dict[str, str]]:
    return [dict(item) for item in FEATURES]


def _running_info() -> dict[str, Any]:
    info = inspect()
    if not info.get("running"):
        raise WCSError("Inicie o Waydroid para instalar ou remover este componente.")
    require_supported_android(info, minimum_api=26, maximum_api=37)
    return info


def _download(url: str, destination: Path, *, max_bytes: int = MAX_DOWNLOAD) -> Path:
    allowed_hosts = {"github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com", "f-droid.org", "download.f-droid.org"}
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in allowed_hosts:
        raise WCSError("O WCS só aceita downloads HTTPS de hosts oficiais permitidos.")
    destination = Path(os.path.abspath(destination))
    ensure_no_symlink_path(Path("/"), destination.as_posix().lstrip("/"))
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_name(destination.name + f".part-{os.getpid()}")
    request = urllib.request.Request(url, headers={"User-Agent": f"Waydroid-Custom-Script/{WCS_VERSION}"})
    total = 0
    created = False
    try:
        output = temp.open("xb")
        created = True
        with urllib.request.urlopen(request, timeout=60) as response, output:
            final = urllib.parse.urlparse(response.geturl())
            if final.scheme != "https" or final.hostname not in allowed_hosts:
                raise WCSError("O servidor redirecionou o download para um host não permitido.")
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                total += len(block)
                if total > max_bytes:
                    raise WCSError(f"Download excedeu o limite de {max_bytes} bytes.")
                output.write(block)
            output.flush()
            os.fsync(output.fileno())
        if total == 0:
            raise WCSError("O servidor retornou um arquivo vazio.")
        os.chmod(temp, 0o600)
        os.replace(temp, destination)
        created = False
        return destination
    except WCSError:
        raise
    except FileExistsError as exc:
        raise WCSError(f"Já existe um download temporário em andamento: {temp}") from exc
    except Exception as exc:
        raise WCSError(f"Falha ao baixar {url}: {exc}") from exc
    finally:
        if created:
            temp.unlink(missing_ok=True)


def _download_dir() -> Path:
    path = ensure_no_symlink_path(STATE_DIR, "downloads/features")
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.is_symlink() or not path.is_dir() or path.stat().st_uid != 0:
        raise WCSError(f"Diretório de cache WCS inseguro: {path}")
    os.chmod(path, 0o700)
    return path


def _microg_asset() -> tuple[str, str, str]:
    releases = fetch_json(MICROG_RELEASES_API)
    if not isinstance(releases, list):
        raise WCSError("A API de releases do microG retornou um formato inesperado.")
    candidates = [r for r in releases if isinstance(r, dict)
                  and str(r.get("tag_name", "")).startswith("microg-v")
                  and not r.get("draft") and not r.get("prerelease")]
    if not candidates:
        raise WCSError("Nenhuma release estável do módulo microG foi encontrada.")
    release = candidates[0]
    assets = release.get("assets", [])
    matches = [a for a in assets if isinstance(a, dict)
               and str(a.get("name", "")).lower().endswith(".zip")
               and "microg" in str(a.get("name", "")).lower()]
    if len(matches) != 1:
        raise WCSError("A release microG não publicou exatamente um ZIP identificável. Download cancelado.")
    asset = matches[0]
    digest = str(asset.get("digest", ""))
    if not digest.startswith("sha256:") or not re.fullmatch(r"sha256:[0-9a-fA-F]{64}", digest):
        raise WCSError("O GitHub não publicou SHA-256 para o ZIP microG. WCS recusou baixar um arquivo sem checksum verificável.")
    return str(asset.get("browser_download_url", "")), digest.split(":", 1)[1].lower(), str(release.get("tag_name"))


def install_microg() -> dict[str, Any]:
    info = _running_info()
    try:
        api = int(str(info.get("sdk", "")))
    except (TypeError, ValueError):
        api = 36 if str(info.get("android")) == "16" else 37 if str(info.get("android")) == "17" else 0
    if api < 26 or api > 36:
        raise WCSError(
            f"O módulo microG upstream declara suporte a Android 8–16 (API 26–36); Android 17/API 37 ainda não é suportado. Esta imagem informa API {api}. "
            "A instalação foi bloqueada porque não há compatibilidade declarada para essa API."
        )
    state = module_manager.list_modules()
    if any(item["id"] == "dresosmicrog" and not item["pending_removal"] for item in state):
        raise WCSError("O módulo dresosmicrog já está instalado. Atualize pelo gerenciador Magisk ou remova-o antes de reinstalar.")
    android_extras = extras.inspect_extras()
    if (android_extras.get("google_services_framework")
            or android_extras.get("google_play_services")
            or android_extras.get("google_play_store")):
        raise WCSError(
            "A imagem em execução contém componentes GApps (GSF/Play Services/Play Store). "
            "O WCS NÃO instalará microG sobre essa imagem. Use uma imagem VANILLA e tente novamente."
        )
    url, checksum, tag = _microg_asset()
    if not url:
        raise WCSError("A release microG não contém uma URL de download válida.")
    zip_path = _download(url, _download_dir() / f"{tag}.zip")
    if sha256_file(zip_path) != checksum:
        zip_path.unlink(missing_ok=True)
        raise WCSError("SHA-256 do módulo microG não corresponde ao digest publicado pelo GitHub. Arquivo descartado.")
    result = module_manager.install_module(zip_path)
    if result.get("id") != "dresosmicrog":
        raise WCSError(f"O ZIP instalado declarou ID inesperado: {result.get('id')!r}.")
    return {"tag": tag, **result, "note": "Reinicie o Android e confira microG Settings > Self-Check. O WCS não afirma que o login Google está validado sem teste real."}


def _parse_smartdock_page(page: bytes) -> tuple[str, int]:
    matches = re.findall(rb'href=["\'](/repo/cu\.axel\.smartdock_(\d+)\.apk)["\']', page)
    if not matches:
        raise WCSError("Não foi possível encontrar um APK versionado do Smart Dock na página F-Droid.")
    path, version = max(matches, key=lambda item: int(item[1]))
    return "https://f-droid.org" + path.decode("ascii"), int(version)


def _latest_smartdock_apk() -> tuple[str, int]:
    request = urllib.request.Request(FDROID_SMARTDOCK_PAGE, headers={"User-Agent": f"Waydroid-Custom-Script/{WCS_VERSION}"})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            final = urllib.parse.urlparse(response.geturl())
            if final.scheme != "https" or final.hostname not in {"f-droid.org", "www.f-droid.org"}:
                raise WCSError("A página oficial do F-Droid redirecionou para um host não permitido.")
            page = response.read(4 * 1024 * 1024 + 1)
        if len(page) > 4 * 1024 * 1024:
            raise WCSError("Página do F-Droid excedeu o limite de 4 MiB.")
    except WCSError:
        raise
    except Exception as exc:
        raise WCSError(f"Não foi possível consultar a página oficial do Smart Dock: {exc}") from exc
    return _parse_smartdock_page(page)


def install_smartdock() -> dict[str, Any]:
    info = _running_info()
    url, version = _latest_smartdock_apk()
    apk = _download(url, _download_dir() / f"smartdock-{version}.apk", max_bytes=64 * 1024 * 1024)
    extras.validate_apk(apk)
    result = extras.install_apk(apk)
    return {"package": "cu.axel.smartdock", "versionCode": version, **result}


def _safe_zip_members(archive: zipfile.ZipFile) -> set[str]:
    names: set[str] = set()
    if len(archive.infolist()) > 2000:
        raise WCSError("ZIP OTA contém entradas demais.")
    for entry in archive.infolist():
        name = entry.filename.replace("\\", "/")
        clean = name.rstrip("/")
        parts = PurePosixPath(clean).parts
        if name.startswith("/") or not clean or any(x in ("", ".", "..") for x in parts):
            raise WCSError(f"ZIP OTA contém caminho inseguro: {entry.filename}")
        mode = entry.external_attr >> 16
        if stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR):
            raise WCSError(f"ZIP OTA contém entrada especial não aceita: {entry.filename}")
        names.add(name)
    if archive.testzip() is not None:
        raise WCSError("ZIP OTA F-Droid falhou na verificação CRC.")
    return names



def _write_zip_file(archive: zipfile.ZipFile, name: str, data: bytes | str, mode: int = 0o644) -> None:
    info = zipfile.ZipInfo(name)
    info.external_attr = (stat.S_IFREG | mode) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(info, data)

def install_fdroid_privileged() -> dict[str, Any]:
    _running_info()
    url = FDROID_PRIVILEGED_ZIP
    ota = _download(url, _download_dir() / "fdroid-privileged-ota-2130.zip", max_bytes=32 * 1024 * 1024)
    module_zip = _download_dir() / "wcs-fdroid-privileged.zip"
    required = {
        "F-Droid.apk": "system/app/F-Droid/F-Droid.apk",
        "F-DroidPrivilegedExtension.apk": "system/priv-app/F-DroidPrivilegedExtension/F-DroidPrivilegedExtension.apk",
        "permissions_org.fdroid.fdroid.privileged.xml": "system/etc/permissions/permissions_org.fdroid.fdroid.privileged.xml",
    }
    try:
        with zipfile.ZipFile(ota) as source:
            names = _safe_zip_members(source)
            missing = sorted(set(required) - names)
            if missing:
                raise WCSError("O OTA oficial F-Droid não contém os arquivos esperados: " + ", ".join(missing))
            for name in ("F-Droid.apk", "F-DroidPrivilegedExtension.apk"):
                data = source.read(name)
                try:
                    with zipfile.ZipFile(io.BytesIO(data)) as apk:
                        if "AndroidManifest.xml" not in apk.namelist():
                            raise WCSError(f"Entrada {name} não é APK válido.")
                except zipfile.BadZipFile as exc:
                    raise WCSError(f"Entrada {name} não é um APK ZIP válido.") from exc
            if not source.read("permissions_org.fdroid.fdroid.privileged.xml").lstrip().startswith(b"<"):
                raise WCSError("XML de permissões F-Droid inválido.")
            with zipfile.ZipFile(module_zip, "w", compression=zipfile.ZIP_DEFLATED) as target:
                _write_zip_file(target, "module.prop", (
                    "id=wcsfdroidpriv\nname=WCS F-Droid Privileged Extension\nversion=7d14a91\n"
                    "versionCode=2130\nauthor=F-Droid / WCS\ndescription=F-Droid privileged extension staged systemlessly by WCS\n"
                ))
                for source_name, target_name in required.items():
                    _write_zip_file(target, target_name, source.read(source_name))
    except zipfile.BadZipFile as exc:
        raise WCSError("Download F-Droid não é um ZIP válido.") from exc
    result = module_manager.install_module(module_zip)
    if result.get("id") != "wcsfdroidpriv":
        raise WCSError("O módulo F-Droid instalado não declarou o ID esperado.")
    return {**result, "note": "Reinicie Android. O pacote F-Droid principal pode precisar ser instalado/atualizado pela loja."}


def _ca_hash(cert: Path) -> str:
    cert = Path(cert).expanduser()
    if cert.is_symlink() or not cert.is_file():
        raise WCSError(f"Certificado CA ausente, não regular ou link simbólico: {cert}")
    result = run_command(["openssl", "x509", "-noout", "-subject_hash_old", "-in", str(cert)], timeout=30)
    value = result.stdout.strip().splitlines()[0] if result.stdout.strip() else ""
    if not re.fullmatch(r"[0-9a-fA-F]{8}", value):
        raise WCSError("OpenSSL não retornou um subject_hash_old válido para o certificado.")
    verify = run_command(["openssl", "x509", "-noout", "-subject", "-issuer", "-dates", "-in", str(cert)], timeout=30)
    return value.lower()


def _build_ca_module(cert: Path, slot: int) -> Path:
    cert_hash = _ca_hash(cert)
    module_zip = _download_dir() / "wcs-mitm-ca.zip"
    # Re-encode only the public X.509 certificate. If the input PEM also contains
    # a private key, it must never be copied into the module ZIP.
    normalized = run_command(["openssl", "x509", "-in", str(cert), "-outform", "PEM"], timeout=30)
    data = normalized.stdout.encode("ascii")
    with zipfile.ZipFile(module_zip, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        module_info = zipfile.ZipInfo("module.prop")
        module_info.external_attr = (stat.S_IFREG | 0o644) << 16
        module_info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(module_info, (
            "id=wcsmitmca\nname=WCS Custom CA Trust\nversion=1.0\nversionCode=1\n"
            "author=WCS\ndescription=Adds one user-supplied CA to Android Conscrypt system trust store\n"
        ))
        cert_info = zipfile.ZipInfo(f"certificates/{cert_hash}.{slot}")
        cert_info.external_attr = (stat.S_IFREG | 0o644) << 16
        cert_info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(cert_info, data)
        script_info = zipfile.ZipInfo("post-fs-data.sh")
        script_info.external_attr = (stat.S_IFREG | 0o755) << 16
        script_info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(script_info, f'''#!/system/bin/sh
MODDIR=${{0%/*}}
CERT_SOURCE="$MODDIR/certificates/{cert_hash}.{slot}"
APEX_CERT_DIR="/apex/com.android.conscrypt/cacerts"
WORK_DIR="/data/adb/wcs-mitm/cacerts"
LOG="/data/adb/wcs-mitm/install.log"
mkdir -p "$(dirname "$LOG")"
echo "WCS CA: starting" > "$LOG"
if [ ! -d "$APEX_CERT_DIR" ] || [ ! -r "$APEX_CERT_DIR" ]; then
  echo "Conscrypt APEX cert directory unavailable" >> "$LOG"
  exit 0
fi
mkdir -p "$WORK_DIR" || exit 0
rm -f "$WORK_DIR"/* 2>/dev/null
for f in "$APEX_CERT_DIR"/*; do
  [ -f "$f" ] || continue
  cp -f "$f" "$WORK_DIR/" 2>/dev/null
 done
cp -f "$CERT_SOURCE" "$WORK_DIR/" || exit 0
chown 0:0 "$WORK_DIR"/* 2>/dev/null
chmod 0644 "$WORK_DIR"/* 2>/dev/null
chmod 0755 "$WORK_DIR"
chcon --reference="$APEX_CERT_DIR" "$WORK_DIR" 2>/dev/null
for f in "$WORK_DIR"/*; do
  [ -f "$f" ] || continue
  ref="$APEX_CERT_DIR/${{f##*/}}"
  if [ -f "$ref" ]; then
    chcon --reference="$ref" "$f" 2>/dev/null
  else
    chcon u:object_r:system_security_cacerts_file:s0 "$f" 2>/dev/null
  fi
done
mount -o bind "$WORK_DIR" "$APEX_CERT_DIR" 2>> "$LOG"
if [ $? -eq 0 ]; then echo "WCS CA: bind mount active" >> "$LOG"; else echo "WCS CA: bind mount failed" >> "$LOG"; fi
''')
    os.chmod(module_zip, 0o600)
    return module_zip


def install_ca(cert: Path) -> dict[str, Any]:
    info = _running_info()
    cert_hash = _ca_hash(cert)
    apex = extras._shell_value("test -d /apex/com.android.conscrypt/cacerts && echo yes")
    if apex.strip() != "yes":
        raise WCSError("Não foi encontrada a trust store do Conscrypt APEX. O WCS não vai gravar em /system/etc/security/cacerts sem confirmar o layout desta imagem.")
    slot = 0
    while slot < 100:
        existing = extras._shell_value(f"test -e /apex/com.android.conscrypt/cacerts/{cert_hash}.{slot} && echo yes")
        if existing.strip() != "yes":
            break
        slot += 1
    if slot >= 100:
        raise WCSError("Não foi possível encontrar um slot de certificado livre.")
    module_zip = _build_ca_module(Path(cert).expanduser(), slot)
    result = module_manager.install_module(module_zip)
    if result.get("id") != "wcsmitmca":
        raise WCSError("O módulo de certificado não declarou o ID esperado.")
    return {**result, "certificate_hash": cert_hash, "slot": slot,
            "note": "Reinicie o Android. A instalação foi preparada, mas o WCS não pode provar a confiança da CA antes do próximo boot."}


def set_system_image_type(
    variant: str, *, rom_type: str = "lineage", source: str = "official",
) -> dict[str, Any]:
    """Switch to a supported official Waydroid system-image flavor, preserving /data."""
    require_root()
    variant = variant.upper()
    rom_type = rom_type.lower()
    if variant not in ("GAPPS", "VANILLA", "FOSS"):
        raise WCSError("Tipo de imagem inválido. Escolha GAPPS, VANILLA ou FOSS.")
    if rom_type not in ("lineage", "bliss"):
        raise WCSError("ROM oficial inválida. Escolha lineage ou bliss.")
    if source != "official":
        raise WCSError("A troca automática desta versão usa os canais OTA oficiais do Waydroid. Canais ATV/custom precisam de um perfil de imagem próprio.")
    info = inspect()
    require_stopped(info)
    images = info.get("images", {})
    if not isinstance(images, dict) or not images.get("system") or not images.get("vendor"):
        raise WCSError("system.img e vendor.img precisam existir antes da troca. Nenhuma alteração foi feita.")

    # The upstream initializer downloads, SHA-256-validates and extracts the
    # selected system/vendor pair. It also clears Waydroid's writable overlay
    # layer, so do not run it over the WCS Magisk adapter or preinstalled images.
    cli_help = run_command(["waydroid", "init", "--help"], check=False, timeout=20)
    help_text = (cli_help.stdout or "") + "\n" + (cli_help.stderr or "")
    required_options = ("--images_path", "--system_channel", "--vendor_channel", "--rom_type", "--system_type")
    missing_options = [option for option in required_options if option not in help_text]
    if cli_help.returncode != 0 or missing_options:
        missing = ", ".join(missing_options) if missing_options else "comando init --help indisponível"
        raise WCSError(
            "A versão instalada do Waydroid não expõe todos os parâmetros necessários "
            f"para selecionar uma imagem oficial ({missing}). Atualize o pacote Waydroid antes de continuar."
        )

    image_dir = Path(str(info["images_path"])).resolve()
    preinstalled_dirs = {
        Path("/etc/waydroid-extra/images").resolve(),
        Path("/usr/share/waydroid-extra/images").resolve(),
    }
    if image_dir in preinstalled_dirs:
        raise WCSError(
            f"A instalação está usando imagens pré-instaladas em {image_dir}. "
            "O inicializador oficial ignora os canais OTA quando encontra esse par. "
            "Remova ou mova essas imagens manualmente antes de pedir a troca pelo WCS. Nada foi alterado."
        )

    marker = root_manager.INSTALLED_MARKER
    bootanim = Path(str(info["overlay_dir"])) / root_manager.BOOTANIM_REL
    wcs_magisk_hook = False
    if bootanim.is_file() and not bootanim.is_symlink():
        try:
            wcs_magisk_hook = "# WCS BEGIN MAGISK" in bootanim.read_text(encoding="utf-8", errors="replace")
        except OSError:
            wcs_magisk_hook = True
    if marker.exists() or marker.is_symlink() or wcs_magisk_hook:
        raise WCSError(
            "A integração Magisk do WCS está instalada no overlay. `waydroid init -f` limpa a camada "
            "writable e pode invalidar essa integração. Execute `sudo wcs root remove`, reinicie o Waydroid "
            "e só então troque a imagem. Nenhum arquivo foi alterado."
        )

    # Waydroid itself resolves host architecture, vendor type and the selected OTA manifest.
    # Its `init -f` already downloads and validates the ZIPs; a second `waydroid upgrade`
    # is redundant and can immediately apply a different update on top of the selected pair.
    before = backup.create_backup()
    init_args = [
        "waydroid", "init", "-f", "-i", str(info["images_path"]),
        "-c", image_manager.OFFICIAL_SYSTEM_BASE,
        "-v", image_manager.OFFICIAL_VENDOR_BASE,
        "-r", rom_type,
        "-s", variant,
    ]
    try:
        init = run_command(init_args, timeout=3600)
    except WCSError as exc:
        raise WCSError(
            f"A troca para {rom_type.upper()} / {variant} falhou. O backup das imagens anteriores permanece em {before}. "
            f"Confira o log do Waydroid; a troca não é considerada concluída.\n{exc}"
        ) from exc
    return {
        "source": "OFFICIAL_WAYDROID_OTA", "rom_type": rom_type,
        "system_type": variant, "backup": str(before),
        "init_output": (init.stdout or "").strip()[-3000:],
        "warning": "O waydroid init -f já baixa e valida os ZIPs do system/vendor. O backup inclui system.img e vendor.img, não /data. A camada overlay_rw pode ser recriada pelo inicializador oficial.",
    }


def set_gapps_variant(variant: str) -> dict[str, Any]:
    """Legacy WayDroid-ATV switch retained for scripts written against WCS 0.3.0."""
    require_root()
    variant = variant.upper()
    if variant not in ("GAPPS", "VANILLA"):
        raise WCSError("Variante ATV inválida. Escolha GAPPS ou VANILLA.")
    info = inspect()
    android = require_android_16_or_17(info)
    require_stopped(info)
    channel = "a16-qpr2" if android == "16" else "a17-qpr0"
    base = f"https://waydroid-atv.github.io/ota/{channel}"
    before = backup.create_backup()
    init_args = ["waydroid", "init", "-f", "-c", f"{base}/system", "-v", f"{base}/vendor", "-r", "lineage", "-s", variant]
    try:
        init = run_command(init_args, timeout=1800)
        upgrade = run_command(["waydroid", "upgrade"], timeout=3600)
    except WCSError as exc:
        raise WCSError(f"A mudança ATV para {variant} falhou. O backup permanece em {before}.\n{exc}") from exc
    return {"variant": variant, "android": android, "channel": channel, "backup": str(before),
            "init_output": (init.stdout or "").strip()[-1500:], "upgrade_output": (upgrade.stdout or "").strip()[-1500:],
            "warning": "O backup inclui system.img e vendor.img, não /data."}


def install_feature(
    feature: str, *, variant: str | None = None, ca_cert: Path | None = None,
    rom_type: str = "lineage",
) -> dict[str, Any] | str:
    require_root()
    feature = feature.lower()
    if feature == "gapps":
        if variant is None:
            raise WCSError("Informe --variant GAPPS, VANILLA ou FOSS. A troca usa o OTA oficial Waydroid e mantém /data.")
        return set_system_image_type(variant, rom_type=rom_type)
    if feature == "magisk":
        raise WCSError("Use o instalador Magisk adaptado já existente: wcs root install --stop.")
    if feature in ("libndk", "libhoudini"):
        return arm_translation.install(feature)
    if feature == "digitalis":
        return digitalis_translation.install()
    if feature == "microg":
        return install_microg()
    if feature == "smartdock":
        return install_smartdock()
    if feature == "fdroidpriv":
        return install_fdroid_privileged()
    if feature == "mitm":
        if ca_cert is None:
            raise WCSError("O componente mitm exige --ca-cert /caminho/para/certificado.pem.")
        return install_ca(ca_cert)

    info = inspect()
    android = require_supported_android(info, minimum_api=26, maximum_api=37)
    if feature == "widevine":
        if info.get("running"):
            status = extras.inspect_extras()
            libs = status.get("widevine_library_paths", [])
            if libs:
                return "Widevine já está presente: " + ", ".join(libs)
        raise WCSError(
            f"Nenhum Widevine foi detectado na imagem Android {android}. Não existe pacote oficial Waydroid universal validado; nenhum blob foi aplicado."
        )
    if feature == "nodataperm":
        raise WCSError("nodataperm substitui services.jar e depende de builds específicos do framework. Não há port validado para todas as imagens oficiais; nada foi alterado.")
    if feature == "hidestatusbar":
        raise WCSError("O overlay hidestatusbar antigo não tem builds/assinaturas validados para todas as imagens oficiais. Nada foi instalado.")
    raise WCSError(f"Componente desconhecido: {feature}")


def remove_feature(feature: str) -> str:
    require_root()
    feature = feature.lower()
    if feature == "smartdock":
        return extras.remove_app("cu.axel.smartdock") or "Solicitada remoção de cu.axel.smartdock."
    module_ids = {"microg": "dresosmicrog", "fdroidpriv": "wcsfdroidpriv", "mitm": "wcsmitmca"}
    if feature in module_ids:
        require_root()
        module_id = module_ids[feature]
        folder = module_manager.queue_module_removal(module_id)
        return f"Remoção de {module_id} agendada em {folder}/remove; será aplicada no próximo boot do Android."
    if feature in ("libndk", "libhoudini"):
        return arm_translation.remove(feature)
    if feature == "digitalis":
        return digitalis_translation.remove()
    if feature == "widevine":
        raise WCSError("widevine é gerenciado pela imagem instalada. O WCS não remove bibliotecas base do sistema.")
    if feature == "gapps":
        raise WCSError("Para sair da variante GAPPS, execute `wcs install gapps --variant VANILLA --yes`. A troca exige reinicialização/upgrade da imagem.")
    if feature == "magisk":
        raise WCSError("Use `wcs root remove` para restaurar a integração Magisk do WCS.")
    if feature in ("nodataperm", "hidestatusbar"):
        raise WCSError(f"{feature} não foi instalado pelo WCS porque não existe port validado para todas as imagens oficiais.")
    raise WCSError(f"Componente desconhecido: {feature}")
