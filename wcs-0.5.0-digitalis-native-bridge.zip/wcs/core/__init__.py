# SPDX-License-Identifier: GPL-3.0-or-later
"""WCS core package."""
