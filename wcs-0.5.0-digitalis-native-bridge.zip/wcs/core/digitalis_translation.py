# SPDX-License-Identifier: GPL-3.0-or-later
"""Pinned Digitalis/Berberis ARM64 -> x86_64 Native Bridge for one known Waydroid build.

This is an integration of the upstream Digitalis/Berberis binary bundle, not a
new instruction translator written by WCS. The bundle is pinned to the
Refract build made for WayDroid-ATV LineageOS 23.2 / Android 16 QPR2.
"""
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import os
import re
import shutil
import stat
import urllib.parse
import urllib.request
from pathlib import Path, PurePosixPath
from typing import Any

from . import arm_translation
from .common import STATE_DIR, WCS_VERSION, WCSError, ensure_no_symlink_path, json_dump
from .detection import inspect, require_stopped

REPOSITORY = "MIXIDtheSilly/Refract"
COMMIT = "ddef6e6ae7de37dd3e400d6a07d3f18cb21a0ebc"
BUNDLE_PREFIX = "prebuilts/digitalis-qpr2"
MANIFEST_GIT_BLOB_SHA1 = "36cecbaef116a541e6a807dde6bcb6bfad076b18"
MANIFEST_URL = (
    f"https://raw.githubusercontent.com/{REPOSITORY}/{COMMIT}/"
    f"{BUNDLE_PREFIX}/SHA256SUMS"
)
RAW_BASE = f"https://raw.githubusercontent.com/{REPOSITORY}/{COMMIT}/{BUNDLE_PREFIX}/"
EXPECTED_ARTIFACTS = 74
MAX_MANIFEST_BYTES = 64 * 1024
MAX_ARTIFACT_BYTES = 128 * 1024 * 1024
MAX_BUNDLE_BYTES = 512 * 1024 * 1024
MAX_WORKERS = 4
CACHE_ROOT = STATE_DIR / "cache" / "digitalis-qpr2"
STATE_ROOT = arm_translation.STATE_ROOT
STATE_FILE = arm_translation.STATE_FILE

# All paths are relative to the system root in the bundle. The ART Native
# Bridge loads this x86-64 ELF; these AArch64 guest files form its private Bionic.
REQUIRED_FILES = {
    "system/bin/arm64/app_process64",
    "system/bin/arm64/linker64",
    "system/bin/berberis_program_runner_arm64",
    "system/bin/berberis_program_runner_binfmt_misc_arm64",
    "system/etc/binfmt_misc/arm64_dyn",
    "system/etc/binfmt_misc/arm64_exe",
    "system/etc/init/berberis.rc",
    "system/etc/ld.config.arm64.txt",
    "system/lib64/libberberis_arm64.so",
    "system/lib64/libberberis_exec_region.so",
    "system/lib64/arm64/ld-android.so",
    "system/lib64/arm64/libc.so",
    "system/lib64/arm64/libdl.so",
    "system/lib64/arm64/libm.so",
    "system/lib64/libberberis_proxy_libc.so",
    "system/lib64/libberberis_proxy_libm.so",
    "system/lib64/libberberis_proxy_libvulkan.so",
}

PROPERTIES = {
    "ro.dalvik.vm.native.bridge": "libberberis_arm64.so",
    "ro.dalvik.vm.isa.arm64": "x86_64",
    "ro.enable.native.bridge.exec": "1",
    "ro.product.cpu.abilist": "x86_64,x86,arm64-v8a",
    "ro.product.cpu.abilist64": "x86_64,arm64-v8a",
    "ro.product.cpu.abilist32": "x86",
    # Refract's tested Waydroid setup uses 1 to send hot regions to the heavy
    # optimizer. This is an upstream tuning property, not a measured WCS gain.
    "berberis.gearup_min_insns": "1",
}

# This empty upper-layer file prevents the image's ndk_translation init action
# from registering a competing ARM64 binfmt handler before Berberis.
NDK_MASK_PATH = "etc/init/ndk_translation.rc"


def _git_blob_sha1(data: bytes) -> str:
    header = b"blob " + str(len(data)).encode("ascii") + b"\0"
    return hashlib.sha1(header + data).hexdigest()


def _safe_manifest_path(raw: str) -> str:
    value = raw.replace("\\", "/")
    path = PurePosixPath(value)
    if (
        not value.startswith("system/")
        or path.is_absolute()
        or any(part in ("", ".", "..") for part in path.parts)
        or "\\" in raw
    ):
        raise WCSError(f"Caminho inseguro no manifesto Digitalis: {raw!r}")
    return path.as_posix()


def _parse_manifest(
    data: bytes, *, expected_count: int = EXPECTED_ARTIFACTS,
    expected_git_blob_sha1: str = MANIFEST_GIT_BLOB_SHA1,
) -> dict[str, str]:
    if len(data) > MAX_MANIFEST_BYTES:
        raise WCSError("Manifesto Digitalis excedeu 64 KiB.")
    actual_git_sha = _git_blob_sha1(data)
    if actual_git_sha != expected_git_blob_sha1:
        raise WCSError(
            "Manifesto Digitalis não corresponde ao objeto Git fixado. "
            f"Esperado {expected_git_blob_sha1}; recebido {actual_git_sha}."
        )
    try:
        text = data.decode("ascii")
    except UnicodeDecodeError as exc:
        raise WCSError("Manifesto Digitalis não está em ASCII válido.") from exc

    entries: dict[str, str] = {}
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match:
            raise WCSError(f"Linha {number} do manifesto Digitalis tem formato inválido.")
        digest, raw_path = match.groups()
        path = _safe_manifest_path(raw_path)
        if path in entries:
            raise WCSError(f"Arquivo duplicado no manifesto Digitalis: {path}")
        entries[path] = digest

    if len(entries) != expected_count:
        raise WCSError(
            f"Manifesto Digitalis contém {len(entries)} arquivos; eram esperados {expected_count}."
        )
    missing = sorted(REQUIRED_FILES - entries.keys())
    if missing:
        raise WCSError("Manifesto Digitalis não contém arquivos essenciais: " + ", ".join(missing))
    return entries


def _download_bytes(url: str, *, limit: int, allowed_host: str) -> bytes:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.hostname != allowed_host:
        raise WCSError(f"URL de download Digitalis não autorizada: {url}")
    request = urllib.request.Request(url, headers={"User-Agent": f"Waydroid-Custom-Script/{WCS_VERSION}"})
    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            final = urllib.parse.urlparse(response.geturl())
            if response.status != 200 or final.scheme != "https" or final.hostname != allowed_host:
                raise WCSError("Download Digitalis redirecionado para origem não autorizada.")
            payload = response.read(limit + 1)
        if not payload or len(payload) > limit:
            raise WCSError(f"Download Digitalis vazio ou excedeu o limite de {limit} bytes.")
        return payload
    except WCSError:
        raise
    except Exception as exc:
        raise WCSError(f"Falha ao baixar artefato Digitalis: {exc}") from exc


def _ensure_root_cache() -> None:
    arm_translation._ensure_root_dir(CACHE_ROOT.parent)
    CACHE_ROOT.mkdir(parents=True, exist_ok=True, mode=0o700)
    if CACHE_ROOT.is_symlink() or not CACHE_ROOT.is_dir() or CACHE_ROOT.stat().st_uid != 0:
        raise WCSError(f"Cache Digitalis inseguro: {CACHE_ROOT}")
    os.chmod(CACHE_ROOT, 0o700)


def _download_verified_artifact(relative: str, digest: str) -> Path:
    destination = CACHE_ROOT.joinpath(*PurePosixPath(relative).parts)
    ensure_no_symlink_path(CACHE_ROOT, relative)
    if destination.is_file() and not destination.is_symlink():
        if arm_translation._sha256_file(destination) == digest:
            return destination
        destination.unlink()
    elif destination.exists() or destination.is_symlink():
        raise WCSError(f"Cache Digitalis contém destino que não é arquivo regular: {destination}")

    destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    ensure_no_symlink_path(CACHE_ROOT, PurePosixPath(relative).parent.as_posix())
    temp = destination.with_name(destination.name + f".part-{os.getpid()}-{hashlib.sha1(relative.encode()).hexdigest()[:8]}")
    if temp.exists() or temp.is_symlink():
        raise WCSError(f"Arquivo temporário Digitalis já existe: {temp}")

    url = RAW_BASE + urllib.parse.quote(relative, safe="/")
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.hostname != "raw.githubusercontent.com":
        raise WCSError("URL interna Digitalis não passou pela validação de origem.")

    fd: int | None = None
    created = False
    digest_obj = hashlib.sha256()
    total = 0
    try:
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
        created = True
        request = urllib.request.Request(url, headers={"User-Agent": f"Waydroid-Custom-Script/{WCS_VERSION}"})
        with urllib.request.urlopen(request, timeout=90) as response:
            final = urllib.parse.urlparse(response.geturl())
            if response.status != 200 or final.scheme != "https" or final.hostname != "raw.githubusercontent.com":
                raise WCSError(f"Download de {relative} redirecionado para origem não autorizada.")
            output_fd = fd
            fd = None
            with os.fdopen(output_fd, "wb") as output:
                while True:
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    total += len(block)
                    if total > MAX_ARTIFACT_BYTES:
                        raise WCSError(f"Artefato Digitalis excedeu 128 MiB: {relative}")
                    digest_obj.update(block)
                    output.write(block)
                output.flush()
                os.fsync(output.fileno())
        actual = digest_obj.hexdigest()
        if total == 0 or actual != digest:
            raise WCSError(
                f"SHA-256 inválido para {relative}. Esperado {digest}; recebido {actual}."
            )
        os.chmod(temp, 0o600)
        os.replace(temp, destination)
        created = False
        return destination
    except WCSError:
        raise
    except Exception as exc:
        raise WCSError(f"Falha ao baixar {relative}: {exc}") from exc
    finally:
        if fd is not None:
            os.close(fd)
        if created:
            temp.unlink(missing_ok=True)


def _elf_machine(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(20)
    if len(header) < 20 or header[:4] != b"\x7fELF":
        raise WCSError(f"Artefato Digitalis não é ELF: {path.name}")
    elf_class = header[4]
    data_encoding = header[5]
    if elf_class != 2 or data_encoding not in (1, 2):
        raise WCSError(f"Artefato Digitalis não é ELF64 válido: {path.name}")
    byte_order = "little" if data_encoding == 1 else "big"
    machine = int.from_bytes(header[18:20], byte_order)
    return elf_class, machine


def _validate_bundle(cache_root: Path, entries: dict[str, str]) -> None:
    for relative, expected_machine in (
        ("system/lib64/libberberis_arm64.so", 62),
        ("system/bin/berberis_program_runner_arm64", 62),
        ("system/bin/berberis_program_runner_binfmt_misc_arm64", 62),
        ("system/bin/arm64/linker64", 183),
        ("system/bin/arm64/app_process64", 183),
        ("system/lib64/arm64/libc.so", 183),
    ):
        path = cache_root / relative
        if not path.is_file() or path.is_symlink():
            raise WCSError(f"Artefato Digitalis essencial ausente/inseguro: {relative}")
        _, machine = _elf_machine(path)
        if machine != expected_machine:
            expected = "x86-64 (EM_X86_64)" if expected_machine == 62 else "AArch64 (EM_AARCH64)"
            raise WCSError(f"Arquitetura ELF inesperada em {relative}: e_machine={machine}; esperado {expected}.")
        if arm_translation._sha256_file(path) != entries[relative]:
            raise WCSError(f"SHA-256 do cache Digitalis mudou após o download: {relative}")


def _load_bundle() -> tuple[dict[str, str], dict[str, Path]]:
    _ensure_root_cache()
    manifest_data = _download_bytes(MANIFEST_URL, limit=MAX_MANIFEST_BYTES, allowed_host="raw.githubusercontent.com")
    entries = _parse_manifest(manifest_data)
    parsed: dict[str, Path] = {}
    errors: list[str] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        futures = {
            pool.submit(_download_verified_artifact, relative, digest): relative
            for relative, digest in entries.items()
        }
        for future in concurrent.futures.as_completed(futures):
            relative = futures[future]
            try:
                parsed[relative] = future.result()
            except Exception as exc:
                errors.append(f"{relative}: {exc}")
    if errors:
        raise WCSError(
            f"Não foi possível validar todos os artefatos Digitalis ({len(errors)} falhas): "
            + " | ".join(errors[:6])
        )
    total = sum(path.stat().st_size for path in parsed.values())
    if total > MAX_BUNDLE_BYTES:
        raise WCSError(f"Bundle Digitalis excedeu o limite total de {MAX_BUNDLE_BYTES} bytes.")
    _validate_bundle(CACHE_ROOT, entries)
    return entries, parsed


def _compatible_image(info: dict[str, Any]) -> str:
    if str(info.get("android", "UNKNOWN")) != "16":
        raise WCSError(
            "Este bundle Digitalis foi compilado para Android 16 QPR2, não para "
            f"Android {info.get('android', 'UNKNOWN')} (API {info.get('sdk', 'UNKNOWN')}). "
            "WCS não vai reutilizar bibliotecas Bionic de outra geração."
        )
    system_ota = str(info.get("system_ota", "")).strip()
    parsed_channel = urllib.parse.urlparse(system_ota)
    is_qpr2_channel = (
        parsed_channel.scheme == "https"
        and parsed_channel.hostname == "waydroid-atv.github.io"
        and parsed_channel.path.rstrip("/") == "/ota/a16-qpr2/system"
    )
    system_datetime = re.sub(r"[^0-9]", "", str(info.get("system_datetime", "")))
    preinstalled_release = (
        str(info.get("channel_kind", "")).upper() == "PREINSTALLED_OR_NO_OTA"
        and system_datetime.startswith("20260717")
    )
    if not (is_qpr2_channel or preinstalled_release):
        raise WCSError(
            "Digitalis deste WCS exige WayDroid-ATV LineageOS 23.2 / Android 16 QPR2 "
            "(canal a16-qpr2 ou imagem pré-instalada identificada como release 20260717). "
            "A imagem atual não prova essa correspondência; nenhum arquivo foi alterado."
        )
    if str(info.get("rom_type", "")).lower() not in ("lineage", "unknown"):
        raise WCSError("O bundle Digitalis QPR2 foi preparado para LineageOS 23.2; ROM diferente bloqueada.")
    host_arch = str(info.get("host_arch", "")).lower()
    guest_arch = str(info.get("arch", "")).lower()
    if host_arch not in {"x86_64", "amd64"} or guest_arch not in {"x86_64", "amd64"}:
        raise WCSError(f"Digitalis QPR2 exige host e guest x86_64; detectado host={host_arch}, guest={guest_arch}.")
    if str(info.get("mount_overlays", "")).strip().lower() != "true":
        raise WCSError("Digitalis precisa de mount_overlays=True para instalar o bundle no system overlay.")
    if not isinstance(info.get("images"), dict) or not info["images"].get("system"):
        raise WCSError("system.img não encontrada para identificar a imagem Digitalis alvo.")
    return "a16-qpr2-channel" if is_qpr2_channel else "preinstalled-20260717-qpr2"


def _restore_previous_provider() -> None:
    if STATE_ROOT.exists() or STATE_ROOT.is_symlink():
        if STATE_ROOT.is_symlink() or not STATE_ROOT.is_dir() or STATE_FILE.is_symlink() or not STATE_FILE.is_file():
            raise WCSError("Há estado órfão/inseguro em /var/lib/wcs/arm-translation; não vou substituir o provider anterior.")
        arm_translation._restore_state()


def _already_installed(info: dict[str, Any]) -> bool:
    if STATE_FILE.is_symlink() or not STATE_FILE.is_file():
        return False
    try:
        state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception as exc:
        raise WCSError(f"Registro de instalação Digitalis ilegível: {exc}") from exc
    if state.get("manager") != "wcs-arm-translation" or state.get("active") != "digitalis":
        return False
    if state.get("bundle_commit") != COMMIT or state.get("status") != "installed":
        return False
    overlay = Path(state.get("overlay", ""))
    if not overlay.is_absolute() or overlay.is_symlink():
        raise WCSError("Overlay registrado para Digitalis está inválido.")
    system_root = overlay / "system"
    for item in state.get("installed_files", []):
        destination = arm_translation._path_under(system_root, item["path"])
        if not destination.is_file() or destination.is_symlink():
            raise WCSError(f"Arquivo Digitalis instalado desapareceu ou mudou de tipo: {destination}")
        if arm_translation._sha256_file(destination) != item.get("installed_sha256"):
            raise WCSError(f"Arquivo Digitalis foi alterado após a instalação: {destination}")
    config_path = Path(state.get("config_path", ""))
    if arm_translation._read_properties(config_path, list(PROPERTIES)) != PROPERTIES:
        raise WCSError("O registro Digitalis existe, mas as propriedades [properties] foram alteradas. Reinstalação automática bloqueada; remova/repare primeiro.")
    bridge_key = "ro.dalvik.vm.native.bridge"
    expected_waydroid = {bridge_key: PROPERTIES[bridge_key]}
    if arm_translation._read_section_values(config_path, "waydroid", [bridge_key]) != expected_waydroid:
        raise WCSError("O registro Digitalis existe, mas [waydroid] não seleciona libberberis_arm64.so.")
    settings_item = state.get("waydroid_settings", {})
    settings_path = Path(settings_item.get("path", ""))
    if not settings_path.is_file() or settings_path.is_symlink():
        raise WCSError("waydroid_settings não existe; o Native Bridge pode não estar sendo selecionado no /data.")
    if arm_translation._sha256_file(settings_path) != state.get("installed_settings_sha256"):
        raise WCSError("waydroid_settings mudou após instalar Digitalis; não será declarado como íntegro.")
    try:
        settings_lines = settings_path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as exc:
        raise WCSError(f"Não foi possível verificar waydroid_settings: {exc}") from exc
    if f"{bridge_key}={PROPERTIES[bridge_key]}" not in settings_lines:
        raise WCSError("waydroid_settings não contém o Native Bridge Digitalis.")
    return True


def install() -> dict[str, Any]:
    """Install the pinned QPR2 Digitalis bundle transactionally into Waydroid's system overlay."""
    info = inspect()
    require_stopped(info)
    image_release = _compatible_image(info)

    overlay = Path(str(info.get("overlay_dir", "")))
    if not overlay.is_absolute() or overlay == Path("/") or overlay.is_symlink():
        raise WCSError("Caminho do overlay Waydroid inválido/inseguro.")
    ensure_no_symlink_path(Path("/"), overlay.as_posix().lstrip("/"))
    system_root = overlay / "system"
    system_root.mkdir(parents=True, exist_ok=True)
    ensure_no_symlink_path(Path("/"), system_root.as_posix().lstrip("/"))
    config_path = Path(str(info.get("config_path", "/var/lib/waydroid/waydroid.cfg")))
    data_path = Path(str(info.get("data_path", "")))
    if not data_path.is_absolute() or not data_path.is_dir() or data_path.is_symlink():
        raise WCSError("Não foi possível resolver o data_path real do Waydroid para persistir Digitalis.")
    ensure_no_symlink_path(Path("/"), data_path.as_posix().lstrip("/"))
    arm_translation.load_waydroid_config(config_path)
    misc_dir = data_path / "misc"
    if misc_dir.is_symlink() or (misc_dir.exists() and not misc_dir.is_dir()):
        raise WCSError(f"Diretório /data/misc inválido: {misc_dir}")
    if misc_dir.exists():
        ensure_no_symlink_path(data_path, "misc")
    settings_path = misc_dir / "waydroid_settings"
    if settings_path.is_symlink() or (settings_path.exists() and not settings_path.is_file()):
        raise WCSError(f"/data/misc/waydroid_settings inválido: {settings_path}")

    if _already_installed(info):
        state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        return {
            "feature": "digitalis", "already_installed": True, "android": "16",
            "image_release": state.get("image_release", image_release),
            "artifacts": EXPECTED_ARTIFACTS,
            "active_native_bridge": PROPERTIES["ro.dalvik.vm.native.bridge"],
            "note": "Digitalis está íntegro no overlay e selecionado em waydroid.cfg e /data/misc/waydroid_settings; isso ainda não comprova execução de todo APK ARM64.",
        }

    entries, cache_files = _load_bundle()

    # Keep the manifest's system/... paths and add only the empty mask required
    # by the upstream Waydroid integration to prevent a competing ndk handler.
    staged: dict[str, Path | None] = {}
    for relative in entries:
        system_relative = relative.removeprefix("system/")
        staged[system_relative] = cache_files[relative]
    staged[NDK_MASK_PATH] = None

    properties = dict(PROPERTIES)

    # Validate the config before changing the currently active provider.
    arm_translation.load_waydroid_config(config_path)

    # Restore any WCS-managed libndk/libhoudini provider first. The property
    # snapshot below must capture the image baseline, not that previous WCS layer.
    _restore_previous_provider()
    arm_translation._ensure_root_dir(STATE_ROOT)
    originals_dir = STATE_ROOT / "originals"
    originals_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    bridge_key = "ro.dalvik.vm.native.bridge"
    original_properties = arm_translation._read_properties(config_path, list(properties))
    original_waydroid_options = arm_translation._read_section_values(config_path, "waydroid", [bridge_key])
    settings_original = (
        arm_translation._snapshot_original(settings_path, originals_dir / "data/misc/waydroid_settings")
        if settings_path.exists() else {"kind": "missing"}
    )

    original_paths: dict[str, dict[str, Any]] = {}
    created_dirs: set[str] = set()
    required_dirs: set[str] = set()
    try:
        for relative in staged:
            parts = PurePosixPath(relative).parts
            for index in range(1, len(parts)):
                required_dirs.add(PurePosixPath(*parts[:index]).as_posix())
        for relative in sorted(required_dirs, key=lambda value: (value.count("/"), value)):
            destination = arm_translation._path_under(system_root, relative)
            if destination.exists() or destination.is_symlink():
                if destination.is_symlink() or not destination.is_dir():
                    raise WCSError(f"Diretório necessário do Digitalis já existe como arquivo/link: {destination}")
            else:
                created_dirs.add(relative)
        for relative in staged:
            destination = arm_translation._path_under(system_root, relative)
            if destination.exists() or destination.is_symlink():
                if destination.is_dir() and not destination.is_symlink():
                    raise WCSError(f"Arquivo Digitalis colidiria com diretório preexistente: {destination}")
                original_paths[relative] = {"path": relative, **arm_translation._snapshot_original(
                    destination, originals_dir / relative
                )}
            else:
                original_paths[relative] = {"path": relative, "kind": "missing"}
    except Exception:
        shutil.rmtree(STATE_ROOT, ignore_errors=True)
        raise

    installed_files = [{"path": path, "installed_kind": "pending"} for path in staged]
    state = {
        "schema": 1,
        "manager": "wcs-arm-translation",
        "active": "digitalis",
        "android": "16",
        "image_release": image_release,
        "bundle_commit": COMMIT,
        "manifest_git_blob_sha1": MANIFEST_GIT_BLOB_SHA1,
        "overlay": str(overlay),
        "config_path": str(config_path),
        "original_properties": original_properties,
        "original_waydroid_options": original_waydroid_options,
        "installed_properties": properties,
        "installed_waydroid_options": {bridge_key: properties[bridge_key]},
        "refresh_waydroid_config": True,
        "waydroid_settings": {"path": str(settings_path), "original": settings_original},
        "settings_misc_created": not misc_dir.exists(),
        "originals": [item for item in original_paths.values() if item["kind"] != "missing"],
        "missing_paths": [path for path, item in original_paths.items() if item["kind"] == "missing"],
        "installed_files": installed_files,
        "created_dirs": sorted(created_dirs, key=lambda value: (value.count("/"), value)),
        "status": "installing",
    }
    arm_translation.json_dump(STATE_FILE, state)

    try:
        for relative in sorted(original_paths, key=lambda value: value.count("/"), reverse=True):
            arm_translation._remove_path(arm_translation._path_under(system_root, relative))
        for relative in sorted(required_dirs, key=lambda value: (value.count("/"), value)):
            destination = arm_translation._path_under(system_root, relative)
            destination.mkdir(parents=True, exist_ok=True)
            if not destination.is_symlink():
                os.chown(destination, 0, 2000 if "bin" in PurePosixPath(relative).parts else 0)
                os.chmod(destination, 0o755)

        installed_state: list[dict[str, Any]] = []
        for relative, source in staged.items():
            destination = arm_translation._path_under(system_root, relative)
            destination.parent.mkdir(parents=True, exist_ok=True)
            if source is None:
                destination.write_bytes(b"")
                mode = 0o644
            else:
                shutil.copyfile(source, destination)
                mode = 0o755 if relative.startswith("bin/") else 0o644
            gid = 2000 if relative.startswith("bin/") else 0
            os.chown(destination, 0, gid)
            os.chmod(destination, mode)
            installed_state.append({
                "path": relative,
                "installed_kind": "file",
                "installed_sha256": arm_translation._sha256_file(destination),
            })

        arm_translation._rewrite_config_section(config_path, "waydroid", {bridge_key: properties[bridge_key]})
        arm_translation._rewrite_properties(config_path, properties)
        settings_state, misc_created, settings_hash = arm_translation._prepare_waydroid_settings(
            data_path, properties[bridge_key], originals_dir
        )
        state["waydroid_settings"] = settings_state
        state["settings_misc_created"] = misc_created
        state["installed_settings_sha256"] = settings_hash
        state["installed_files"] = installed_state
        arm_translation.json_dump(STATE_FILE, state)
        arm_translation.run_command(["waydroid", "upgrade", "--offline"], timeout=900)
        state["status"] = "installed"
        arm_translation.json_dump(STATE_FILE, state)
    except Exception as exc:
        try:
            partial = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            partial["installed_files"] = [{"path": path, "installed_kind": "pending"} for path in staged]
            arm_translation.json_dump(STATE_FILE, partial)
            arm_translation._restore_state(verify_current=False)
        except Exception as restore_exc:
            raise WCSError(
                f"Instalação Digitalis falhou: {exc}. Rollback também falhou: {restore_exc}. "
                f"Backups preservados em {STATE_ROOT}."
            ) from exc
        if isinstance(exc, WCSError):
            raise
        raise WCSError(f"Instalação Digitalis falhou; overlay e propriedades restaurados: {exc}") from exc

    return {
        "feature": "digitalis",
        "android": "16",
        "image_release": image_release,
        "source": f"{REPOSITORY}@{COMMIT}",
        "manifest_git_blob_sha1": MANIFEST_GIT_BLOB_SHA1,
        "artifacts_verified": len(entries),
        "files_installed": len(installed_files),
        "overlay": str(overlay),
        "active_native_bridge": PROPERTIES["ro.dalvik.vm.native.bridge"],
        "restorable": True,
        "note": (
            "Digitalis/Berberis instalado no overlay. O tradutor não substitui o stack gráfico: "
            "apps Vulkan ainda dependem do driver/proxy da imagem. Reinicie Waydroid e teste o APK ARM64; "
            "o host-side installer não consegue provar que o app abriu."
        ),
    }


def remove() -> str:
    info = inspect()
    require_stopped(info)
    if STATE_ROOT.is_symlink() or not STATE_ROOT.is_dir() or STATE_FILE.is_symlink() or not STATE_FILE.is_file():
        raise WCSError("Não há instalação Digitalis registrada pelo WCS para remover.")
    state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    if state.get("manager") != "wcs-arm-translation" or state.get("active") != "digitalis":
        raise WCSError(f"O provider Native Bridge ativo gerenciado pelo WCS é {state.get('active')}, não Digitalis.")
    active = arm_translation._restore_state()
    return f"{active} removido; overlay e propriedades originais restaurados."


def status() -> dict[str, Any]:
    current = arm_translation.status()
    if current.get("managed") and current.get("active") == "digitalis":
        return {**current, "provider": "Digitalis/Berberis", "translator": "ARM64 -> x86_64"}
    return {"managed": False, "active": None, "provider": None}
