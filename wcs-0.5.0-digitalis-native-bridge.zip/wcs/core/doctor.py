# SPDX-License-Identifier: GPL-3.0-or-later
"""Diagnostics for the host and Waydroid instance."""
from __future__ import annotations

import os
import shutil
from pathlib import Path

from .common import WAYDROID_CONFIG, STATE_DIR, WCSError, load_waydroid_config
from .detection import inspect


def run_doctor() -> list[tuple[str, str, str]]:
    checks: list[tuple[str, str, str]] = []
    checks.append(("waydroid binary", "OK" if shutil.which("waydroid") else "MISSING", shutil.which("waydroid") or "comando waydroid não encontrado"))
    checks.append(("waydroid config", "OK" if WAYDROID_CONFIG.is_file() else "MISSING", str(WAYDROID_CONFIG)))
    checks.append(("python", "OK", os.sys.version.split()[0]))
    checks.append(("host privilege", "OK" if os.geteuid() == 0 else "INFO", "root" if os.geteuid() == 0 else "operações de escrita exigem sudo"))
    if not WAYDROID_CONFIG.is_file():
        return checks
    try:
        info = inspect()
        checks.append(("container", "RUNNING" if info["running"] else "STOPPED", f"{info['status'].get('raw', '')} | LXC={info.get('lxc_state', 'UNKNOWN')}"))
        checks.append(("Android target", "DETECTED" if str(info["sdk"]).isdigit() else "UNKNOWN", f"Android {info['android']} / API {info['sdk']} | {info.get('image_source', 'UNKNOWN')}"))
        checks.append(("architecture", "DETECTED" if info["arch"] else "UNKNOWN", f"guest={info['arch']} host={info['host_arch']}"))
        checks.append(("system.img", "OK" if info["images"]["system"] else "MISSING", str(Path(str(info["images_path"])) / "system.img")))
        checks.append(("vendor.img", "OK" if info["images"]["vendor"] else "MISSING", str(Path(str(info["images_path"])) / "vendor.img")))
        checks.append(("overlay", "OK" if info["overlay_exists"] else "MISSING", f"{info['overlay_dir']} (mount_overlays={info['mount_overlays']})"))
        checks.append(("Android data path", "OK" if info["data_exists"] else "MISSING", str(info["data_path"])))
    except WCSError as exc:
        checks.append(("Waydroid inspection", "ERROR", str(exc)))
    checks.append(("WCS state dir", "OK" if STATE_DIR.exists() else "NOT CREATED", str(STATE_DIR)))
    return checks
