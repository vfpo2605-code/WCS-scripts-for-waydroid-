# SPDX-License-Identifier: GPL-3.0-or-later
"""Transactional backups for Waydroid's system.img and vendor.img."""
from __future__ import annotations

import json
import os
import shutil
import stat
import time
from pathlib import Path

from .common import STATE_DIR, WCSError, ensure_no_symlink_path, human_size, json_dump, sha256_file
from .detection import inspect, require_stopped

BACKUP_DIR = STATE_DIR / "backups" / "images"
IMAGE_NAMES = ("system.img", "vendor.img")


def _timestamp() -> str:
    return time.strftime("%Y%m%d-%H%M%S", time.gmtime())


def _validate_backup_root(*, must_exist: bool = False) -> None:
    """Reject symlinks in the state path and require its final directory to be root-owned."""
    absolute = BACKUP_DIR.absolute()
    current = Path(absolute.anchor)
    for part in absolute.parts[1:]:
        current = current / part
        if current.is_symlink():
            raise WCSError(f"Caminho de backup contém link simbólico: {current}")
    if must_exist and not BACKUP_DIR.is_dir():
        raise WCSError(f"Diretório de backups não existe: {BACKUP_DIR}")
    if BACKUP_DIR.exists():
        if not BACKUP_DIR.is_dir() or BACKUP_DIR.stat().st_uid != 0:
            raise WCSError(f"Diretório de backups não é diretório root-owned: {BACKUP_DIR}")


def _copy_checked(src: Path, dst: Path) -> tuple[int, str]:
    dst.parent.mkdir(parents=True, exist_ok=True)
    part = dst.with_name(dst.name + f".part-{os.getpid()}")
    digest_size = 0
    try:
        with src.open("rb") as source, part.open("xb") as target:
            import hashlib
            digest = hashlib.sha256()
            while True:
                block = source.read(1024 * 1024)
                if not block:
                    break
                digest.update(block)
                target.write(block)
                digest_size += len(block)
            target.flush()
            os.fsync(target.fileno())
        shutil.copystat(src, part, follow_symlinks=False)
        os.replace(part, dst)
        return digest_size, digest.hexdigest()
    finally:
        try:
            part.unlink()
        except FileNotFoundError:
            pass


def create_backup() -> Path:
    info = inspect()
    require_stopped(info)
    source_dir = Path(os.path.abspath(str(info["images_path"])))
    ensure_no_symlink_path(Path("/"), source_dir.as_posix().lstrip("/"))
    if not source_dir.is_dir():
        raise WCSError(f"Diretório de imagens não existe ou não é diretório: {source_dir}")
    sources = [source_dir / name for name in IMAGE_NAMES]
    if any(path.is_symlink() for path in sources):
        raise WCSError("Uma imagem configurada é link simbólico; backup bloqueado.")
    missing = [str(p) for p in sources if not p.is_file()]
    if missing:
        raise WCSError("Não foi possível fazer backup; imagem ausente: " + ", ".join(missing))
    total = sum(p.stat().st_size for p in sources)
    _validate_backup_root()
    BACKUP_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    _validate_backup_root(must_exist=True)
    os.chmod(BACKUP_DIR, 0o700)
    free = shutil.disk_usage(BACKUP_DIR).free
    if free < total + 128 * 1024 * 1024:
        raise WCSError(f"Espaço insuficiente. Backup precisa de aproximadamente {human_size(total)}; disponível: {human_size(free)}.")

    unique = time.time_ns()
    work = BACKUP_DIR / f".wcs-{_timestamp()}-{os.getpid()}-{unique}.partial"
    final = BACKUP_DIR / f"{_timestamp()}-{os.getpid()}-{unique}"
    work.mkdir(mode=0o700)
    files: dict[str, dict[str, object]] = {}
    try:
        for source in sources:
            size, checksum = _copy_checked(source, work / source.name)
            files[source.name] = {"size": size, "sha256": checksum}
        manifest = {
            "format": 1,
            "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "source_images_path": str(source_dir),
            "files": files,
            "scope": "system.img e vendor.img; não inclui /data nem dados pessoais Android",
        }
        json_dump(work / "manifest.json", manifest)
        os.rename(work, final)
        return final
    except Exception:
        shutil.rmtree(work, ignore_errors=True)
        raise


def list_backups() -> list[dict[str, object]]:
    _validate_backup_root()
    if not BACKUP_DIR.is_dir():
        return []
    found: list[dict[str, object]] = []
    for folder in sorted(BACKUP_DIR.iterdir(), reverse=True):
        if folder.is_symlink() or not folder.is_dir() or folder.name.startswith("."):
            continue
        manifest_path = folder / "manifest.json"
        try:
            manifest_stat = manifest_path.lstat()
            if not stat.S_ISREG(manifest_stat.st_mode) or manifest_stat.st_uid != 0:
                raise WCSError("Manifesto de backup não é arquivo regular root-owned.")
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            found.append({"name": folder.name, "path": str(folder), "manifest": manifest})
        except (OSError, json.JSONDecodeError, WCSError):
            found.append({"name": folder.name, "path": str(folder), "manifest": None})
    return found


def restore_backup(name: str) -> Path:
    if not name or name in (".", "..") or "/" in name or "\\" in name:
        raise WCSError("Nome de backup inválido.")
    _validate_backup_root(must_exist=True)
    info = inspect()
    require_stopped(info)
    source = BACKUP_DIR / name
    manifest_file = source / "manifest.json"
    if source.is_symlink() or manifest_file.is_symlink():
        raise WCSError("Backup ou manifesto é link simbólico; restauração bloqueada.")
    if not source.is_dir() or source.stat().st_uid != 0 or not manifest_file.is_file():
        raise WCSError(f"Backup não encontrado, inseguro ou sem manifesto: {name}")
    manifest_stat = manifest_file.stat(follow_symlinks=False)
    if manifest_stat.st_uid != 0 or not stat.S_ISREG(manifest_stat.st_mode):
        raise WCSError("Manifesto do backup não é um arquivo regular pertencente a root.")
    try:
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise WCSError(f"Manifesto de backup inválido: {exc}") from exc
    records = manifest.get("files") if isinstance(manifest, dict) else None
    if not isinstance(manifest, dict) or manifest.get("format") != 1 or not isinstance(records, dict) or set(records) != set(IMAGE_NAMES):
        raise WCSError("Formato de backup incompatível ou incompleto.")

    for filename in IMAGE_NAMES:
        image = source / filename
        record = records[filename]
        if not isinstance(record, dict):
            raise WCSError(f"Registro de integridade inválido: {filename}")
        expected_size = record.get("size")
        expected_hash = record.get("sha256")
        if not isinstance(expected_size, int) or expected_size < 1 or not isinstance(expected_hash, str) or len(expected_hash) != 64:
            raise WCSError(f"Metadados de integridade inválidos: {filename}")
        if image.is_symlink() or not image.is_file() or image.stat().st_uid != 0 or image.stat().st_size != expected_size or sha256_file(image) != expected_hash:
            raise WCSError(f"Integridade do backup falhou: {filename}")

    current_dir = Path(os.path.abspath(str(info["images_path"])))
    ensure_no_symlink_path(Path("/"), current_dir.as_posix().lstrip("/"))
    if not current_dir.is_dir():
        raise WCSError(f"Diretório atual de imagens não existe: {current_dir}")
    current_files = [current_dir / filename for filename in IMAGE_NAMES]
    if any(p.is_symlink() or not p.is_file() for p in current_files):
        raise WCSError("As imagens atuais não estão completas ou contêm link simbólico; restauração recusada.")
    total = sum((source / f).stat().st_size for f in IMAGE_NAMES)
    if shutil.disk_usage(current_dir).free < total + 128 * 1024 * 1024:
        raise WCSError("Espaço insuficiente para preparar a restauração atômica.")

    # Snapshot current pair before the first replacement.
    before = create_backup()
    staged: dict[str, Path] = {}
    old: dict[str, Path] = {}
    installed: list[str] = []
    try:
        for filename in IMAGE_NAMES:
            staged_path = current_dir / f".{filename}.wcs-restore-{os.getpid()}"
            _copy_checked(source / filename, staged_path)
            staged[filename] = staged_path
        for filename in IMAGE_NAMES:
            target = current_dir / filename
            old_path = current_dir / f".{filename}.wcs-old-{os.getpid()}"
            os.replace(target, old_path)
            old[filename] = old_path
            os.replace(staged[filename], target)
            installed.append(filename)
        for path in old.values():
            path.unlink(missing_ok=True)
        return before
    except Exception as exc:
        for filename in reversed(installed):
            (current_dir / filename).unlink(missing_ok=True)
        for filename, old_path in old.items():
            if old_path.exists():
                os.replace(old_path, current_dir / filename)
        raise WCSError(f"Restauração falhou e o par anterior foi recuperado quando possível: {exc}") from exc
    finally:
        for path in staged.values():
            path.unlink(missing_ok=True)
