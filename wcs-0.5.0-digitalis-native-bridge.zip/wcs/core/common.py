# SPDX-License-Identifier: GPL-3.0-or-later
"""Shared host-side primitives for Waydroid Custom Script."""
from __future__ import annotations

import configparser
import hashlib
import json
import os
import platform
import shutil
import stat
import subprocess
import urllib.request
from pathlib import Path
from typing import Any, Iterable

WCS_VERSION = "0.5.0"
WAYDROID_CONFIG = Path(os.environ.get("WAYDROID_CONFIG", "/var/lib/waydroid/waydroid.cfg"))
STATE_DIR = Path(os.environ.get("WCS_STATE_DIR", "/var/lib/wcs"))
API_HEADERS = {
    "User-Agent": f"Waydroid-Custom-Script/{WCS_VERSION}",
    "Accept": "application/vnd.github+json",
}


class WCSError(RuntimeError):
    """An expected, user-correctable WCS error."""


def require_root() -> None:
    if os.geteuid() != 0:
        raise WCSError("Esta operação modifica arquivos do Waydroid e precisa ser executada como root (sudo).")


def run_command(
    argv: Iterable[str], *, check: bool = True, input_text: str | None = None,
    timeout: int = 180, env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    args = [str(x) for x in argv]
    try:
        result = subprocess.run(
            args, text=True, input=input_text, capture_output=True,
            timeout=timeout, env=env, stdin=None if input_text is not None else subprocess.DEVNULL,
            check=False,
        )
    except FileNotFoundError as exc:
        raise WCSError(f"Comando não encontrado: {args[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise WCSError(f"Tempo limite excedido ao executar: {' '.join(args[:4])}") from exc
    if check and result.returncode != 0:
        detail = (result.stderr or result.stdout or "sem detalhes").strip()[-1200:]
        raise WCSError(f"Comando falhou ({result.returncode}): {' '.join(args[:5])}\n{detail}")
    return result


def load_waydroid_config(path: Path = WAYDROID_CONFIG) -> configparser.ConfigParser:
    cfg = configparser.ConfigParser(interpolation=None)
    if path.is_symlink() or not path.is_file():
        raise WCSError(f"Configuração do Waydroid ausente, insegura ou não é arquivo regular: {path}")
    try:
        cfg.read(path, encoding="utf-8")
    except (OSError, configparser.Error) as exc:
        raise WCSError(f"Não foi possível ler {path}: {exc}") from exc
    if "waydroid" not in cfg:
        raise WCSError(f"A seção [waydroid] não existe em {path}")
    return cfg


def waydroid_root(config_path: Path = WAYDROID_CONFIG) -> Path:
    return config_path.parent


def get_data_path(cfg: configparser.ConfigParser, *, config_path: Path = WAYDROID_CONFIG) -> Path:
    """Resolve the host-side path that is mounted as Android /data."""
    configured = cfg["waydroid"].get("data_path", "").strip()
    candidates: list[Path] = []
    if configured:
        candidates.append(Path(configured).expanduser())

    sudo_user = os.environ.get("SUDO_USER")
    if sudo_user:
        try:
            import pwd
            home = Path(pwd.getpwnam(sudo_user).pw_dir)
            candidates.append(home / ".local/share/waydroid/data")
        except KeyError:
            pass
    home_env = Path(os.environ.get("HOME", str(Path.home())))
    candidates.extend([
        home_env / ".local/share/waydroid/data",
        config_path.parent / "data",
    ])
    for candidate in candidates:
        if candidate.is_symlink():
            raise WCSError(f"O data_path do Waydroid é um link simbólico; operação bloqueada: {candidate}")
        if candidate.is_dir():
            return candidate
    # Return the first configured candidate only when none currently exists, for diagnostics.
    return candidates[0] if candidates else config_path.parent / "data"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write(path: Path, data: bytes, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".wcs-tmp-{os.getpid()}")
    try:
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), mode)
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temp, mode)
        os.replace(temp, path)
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass


def fetch_json(url: str, *, timeout: int = 30) -> Any:
    request = urllib.request.Request(url, headers=API_HEADERS)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            if response.status != 200:
                raise WCSError(f"Servidor respondeu HTTP {response.status}: {url}")
            payload = response.read(16 * 1024 * 1024 + 1)
        if len(payload) > 16 * 1024 * 1024:
            raise WCSError("Resposta JSON excedeu o limite de 16 MiB.")
        return json.loads(payload.decode("utf-8"))
    except WCSError:
        raise
    except Exception as exc:
        raise WCSError(f"Falha ao consultar {url}: {exc}") from exc


def download_verified(url: str, destination: Path, expected_sha256: str, *, max_bytes: int = 64 * 1024 * 1024) -> Path:
    """Download to an exclusive no-follow temporary file and publish only after SHA-256 matches."""
    destination = Path(os.path.abspath(os.fspath(destination)))
    ensure_no_symlink_path(Path("/"), destination.as_posix().lstrip("/"))
    if os.path.lexists(destination):
        st = destination.lstat()
        if not stat.S_ISREG(st.st_mode):
            raise WCSError(f"Destino de download não é arquivo regular: {destination}")
        if sha256_file(destination) == expected_sha256:
            return destination
    temp = destination.with_name(destination.name + f".part-{os.getpid()}")
    ensure_no_symlink_path(Path("/"), temp.as_posix().lstrip("/"))
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(url, headers={"User-Agent": API_HEADERS["User-Agent"]})
    total = 0
    digest = hashlib.sha256()
    fd: int | None = None
    try:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(temp, flags, 0o600)
        with urllib.request.urlopen(request, timeout=60) as response, os.fdopen(fd, "wb") as output:
            fd = None
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                total += len(block)
                if total > max_bytes:
                    raise WCSError(f"Download excedeu o limite de {max_bytes} bytes.")
                digest.update(block)
                output.write(block)
            output.flush()
            os.fsync(output.fileno())
        actual = digest.hexdigest()
        if actual.lower() != expected_sha256.lower():
            raise WCSError(f"SHA-256 incorreto. Esperado: {expected_sha256}; recebido: {actual}")
        os.chmod(temp, 0o600)
        os.replace(temp, destination)
        return destination
    except WCSError:
        raise
    except Exception as exc:
        raise WCSError(f"Falha ao baixar {url}: {exc}") from exc
    finally:
        if fd is not None:
            os.close(fd)
        try:
            temp.unlink()
        except FileNotFoundError:
            pass


def ensure_no_symlink_path(base: Path, relative: str) -> Path:
    """Build an absolute path while rejecting symlinks in the base and every existing component."""
    rel = Path(relative)
    if rel.is_absolute() or relative in ("", ".") or any(part in ("", ".", "..") for part in rel.parts):
        raise WCSError(f"Caminho relativo inválido: {relative}")
    base = Path(os.path.abspath(os.fspath(base)))
    current = Path(base.anchor)
    for part in base.parts[1:]:
        current = current / part
        try:
            st = current.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(st.st_mode):
            raise WCSError(f"Diretório-base contém link simbólico: {current}")
        if current != base and not stat.S_ISDIR(st.st_mode):
            raise WCSError(f"Componente do diretório-base não é diretório: {current}")
    current = base
    for part in rel.parts:
        current = current / part
        try:
            st = current.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(st.st_mode):
            raise WCSError(f"Caminho contém link simbólico, operação bloqueada: {current}")
    if base not in current.parents and current != base:
        raise WCSError(f"Caminho escapou do diretório-base: {relative}")
    return current


def json_dump(path: Path, value: Any) -> None:
    atomic_write(path, (json.dumps(value, indent=2, sort_keys=True) + "\n").encode(), 0o600)


def human_size(value: int) -> str:
    size = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if size < 1024 or unit == "TiB":
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TiB"


def host_arch() -> str:
    return platform.machine().lower()
