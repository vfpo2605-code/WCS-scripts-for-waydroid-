# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only inventory of recoverable WCS snapshots."""
from __future__ import annotations

from pathlib import Path

from .common import STATE_DIR
from .backup import list_backups


def recovery_points() -> list[dict[str, object]]:
    points: list[dict[str, object]] = []
    for entry in list_backups():
        points.append({"kind": "images", "name": entry["name"], "path": entry["path"], "valid": entry["manifest"] is not None})
    root_dir = STATE_DIR / "backups" / "root"
    if root_dir.is_symlink():
        points.append({"kind": "root-overlay", "name": "UNSAFE_SYMLINK", "path": str(root_dir), "valid": False})
    elif root_dir.is_dir():
        for path in sorted(root_dir.iterdir(), reverse=True):
            if path.is_symlink() or not path.is_dir():
                continue
            manifest = path / "manifest.json"
            valid = not manifest.is_symlink() and manifest.is_file() and manifest.stat().st_uid == 0
            points.append({"kind": "root-overlay", "name": path.name, "path": str(path), "valid": valid})
    return points
