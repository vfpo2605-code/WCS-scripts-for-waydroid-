# SPDX-License-Identifier: GPL-3.0-or-later
"""Command-line interface for Waydroid Custom Script."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from . import backup, compatibility, detection, doctor, extras, feature_manager, image_manager, module_manager, recovery, root_manager
from .common import WCSError, WCS_VERSION, require_root


def _json(value: Any) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False, default=str))


def _yes(prompt: str) -> bool:
    if not sys.stdin.isatty():
        return False
    try:
        answer = input(f"{prompt} [s/N] ").strip().lower()
    except EOFError:
        return False
    return answer in ("s", "sim", "y", "yes")


def _print_info() -> None:
    info = detection.inspect()
    print(f"WAYDROID CUSTOM SCRIPT  WCS {WCS_VERSION}")
    print("=" * 58)
    print(f"Waydroid:       {info['waydroid_bin']}")
    print(f"Session:        {info['status'].get('session', 'UNKNOWN')}")
    print(f"Container:      {info['status'].get('container', 'UNKNOWN')}")
    print(f"LXC:            {info.get('lxc_state', 'UNKNOWN')}")
    print(f"Android:        {info['android']} (API {info['sdk']})")
    print(f"Arquitetura:    {info['arch']} / {info.get('abi_list', 'UNKNOWN')} (host: {info['host_arch']})")
    print(f"Origem da imagem: {info.get('image_source', 'UNKNOWN')}")
    print(f"ROM / sistema:  {info.get('rom_type', 'UNKNOWN')} / {info.get('system_type', 'UNKNOWN')}")
    print(f"Vendor type:    {info.get('vendor_type', 'UNKNOWN')}")
    print(f"System OTA:     {info['system_ota']}")
    print(f"Vendor OTA:     {info['vendor_ota']}")
    print(f"Images:         {info['images_path']}")
    print(f"system.img:     {'OK' if info['images']['system'] else 'AUSENTE'}")
    print(f"vendor.img:     {'OK' if info['images']['vendor'] else 'AUSENTE'}")
    print(f"Overlay:        {info['overlay_dir']} (mount_overlays={info['mount_overlays']})")
    print(f"Dados Android:  {info['data_path']} ({'presente' if info['data_exists'] else 'ausente'})")
    if info["props"]:
        print("\nPropriedades Android coletadas:")
        for key, value in info["props"].items():
            print(f"  {key}: {value}")
    else:
        print("\nAndroid parado ou propriedades não disponíveis; versão inferida apenas pela configuração OTA, quando possível.")


def _print_doctor() -> None:
    print("DIAGNÓSTICO WCS")
    print("=" * 72)
    for name, status, detail in doctor.run_doctor():
        print(f"[{status:12}] {name:22} {detail}")


def _print_catalog(android: str) -> None:
    releases = image_manager.release_catalog(android)
    if not releases:
        print("Nenhuma release WayDroid-ATV correspondente foi encontrada.")
        return
    for release in releases:
        print(f"\n{release['tag']}  {release['name']}  publicado={release['published_at']}")
        print(f"  {release['html_url']}")
        for asset in release["assets"]:
            print(f"  - {asset['name']} ({asset['size_human']}) SHA256={asset['sha256']}")
    print("\nCatálogo somente leitura das releases WayDroid-ATV.")


def _print_official_catalog(arch: str, rom: str, system_type: str) -> None:
    entries = image_manager.official_image_catalog(arch=arch, rom_type=rom, system_type=system_type)
    if not entries:
        print("Nenhum manifesto OTA oficial disponível para esses filtros.")
        return
    for item in entries:
        latest = item["latest"]
        print(f"\n{item['rom_type'].upper()} / {item['system_type']} / {item['arch']}")
        print(f"  Builds publicados: {item['build_count']} | Manifesto: {item['manifest']}")
        print(f"  Mais recente: {latest['filename']} | {item['rom_type'].title()} {latest['version']}")
        print(f"  Tamanho: {latest['size_human']} | SHA-256: {latest['sha256']}")
        print(f"  Download: {latest['url']}")
    print("\nFonte: OTA oficial Waydroid. O inicializador Waydroid resolve automaticamente o vendor type para a arquitetura do host.")


def _print_compatibility(android: str) -> None:
    print(f"COMPATIBILIDADE DECLARADA / EVIDÊNCIAS DISPONÍVEIS (Android {android})")
    print("=" * 84)
    for item in compatibility.report(android):
        print(f"{item['name']}: {item['status']}")
        print(f"  {item['version']}")
        print(f"  {item['note']}")


def _print_modules() -> None:
    modules = module_manager.list_modules()
    if not modules:
        print("Nenhum módulo encontrado em /data/adb/modules ou modules_update.")
        return
    for item in modules:
        flags = []
        if item["disabled"]:
            flags.append("desativado")
        if item["pending_removal"]:
            flags.append("remoção pendente")
        if item["pending_update"]:
            flags.append("update pendente")
        state = ", ".join(flags) or "ativo"
        print(f"{item['id']} | {item['name']} | {item['version']} | {state}")
        if item["description"]:
            print(f"  {item['description']}")


def _print_root_status() -> None:
    state = root_manager.root_install_state()
    print("ROOT / MAGISK")
    print("=" * 58)
    print(f"Registro WCS:      {'presente' if state['registered'] else 'ausente'}")
    print(f"Arquivos Magisk:   {'presentes' if state['files_present'] else 'ausentes'}")
    print(f"Gatilho init:      {'presente' if state['init_hook_present'] else 'ausente'}")
    print(f"Backup original:   {'presente' if state['baseline_present'] else 'ausente'}")
    marker = state.get("marker", {})
    if marker:
        print(f"Versão:            {marker.get('magisk_version', 'desconhecida')}")
        print(f"Android alvo:      {marker.get('android', 'desconhecido')}")
        print(f"ABI:               {marker.get('abi', 'desconhecida')}")
    info = detection.inspect()
    if info["running"]:
        print("\nProva de runtime via ADB:")
        _json(root_manager.runtime_probe())
    else:
        print("\nWaydroid está parado. Daemon, MagiskSU e injeção Zygisk não podem ser provados agora.")


def _do_backup_create() -> None:
    require_root()
    path = backup.create_backup()
    print(f"Backup criado: {path}")
    print("Inclui system.img e vendor.img. Não inclui /data nem os dados pessoais dos aplicativos.")


def _do_backup_restore(name: str) -> None:
    require_root()
    before = backup.restore_backup(name)
    print(f"Backup restaurado: {name}")
    print(f"As imagens que estavam instaladas antes da restauração foram preservadas em: {before}")


def _do_root_install(stop: bool) -> None:
    require_root()
    info = detection.inspect()
    if info["running"] and not stop:
        raise WCSError("Waydroid está ativo. Para autorizar a parada automática, use: sudo wcs root install --stop")
    result = root_manager.install_magisk(confirm_stop=stop)
    print(f"Magisk {result['version']} preparado no overlay para Android {result['android']} ({result['abi']}).")
    print("<ATENÇÃO> Isso confirma a instalação dos arquivos, NÃO confirma boot, daemon, MagiskSU nem Zygisk.")
    print("Inicie o Waydroid e execute: sudo wcs root status")


def _do_root_remove() -> None:
    require_root()
    archive = root_manager.remove_magisk()
    print("Integração Magisk do WCS removida; arquivos originais do overlay restaurados.")
    print(f"Backup-base preservado em: {archive}")
    print("Os dados em /data/adb e módulos instalados não foram apagados.")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="wcs", description="Waydroid Custom Script")
    parser.add_argument("--version", action="version", version=f"WCS {WCS_VERSION}")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("info", help="exibir informações detectadas do Waydroid")
    sub.add_parser("doctor", help="diagnóstico do host e da instalação")
    compat = sub.add_parser("compatibility", help="matriz de compatibilidade baseada em evidências")
    compat.add_argument("--android", choices=("11", "12", "12L", "13", "14", "15", "16", "17"), default="13")

    images = sub.add_parser("images", help="catálogo e verificação das imagens")
    images_sub = images.add_subparsers(dest="images_command", required=True)
    catalog = images_sub.add_parser("catalog", help="consultar imagens OTA oficiais do Waydroid")
    catalog.add_argument("--source", choices=("official", "atv"), default="official")
    catalog.add_argument("--arch", choices=("host", "all", "x86_64", "x86", "arm64", "arm", "arm64_only"), default="host")
    catalog.add_argument("--rom", choices=("all", "lineage", "bliss"), default="all")
    catalog.add_argument("--type", dest="system_type", choices=("all", "VANILLA", "FOSS", "GAPPS"), default="all")
    catalog.add_argument("--android", choices=("16", "17", "all"), default="all", help="filtro exclusivo do catálogo ATV")
    atv_catalog = images_sub.add_parser("atv-catalog", help="consultar releases WayDroid-ATV")
    atv_catalog.add_argument("--android", choices=("16", "17", "all"), default="all")
    switch = images_sub.add_parser("switch", help="trocar imagem pelos canais oficiais do Waydroid")
    switch.add_argument("--rom", choices=("lineage", "bliss"), default="lineage")
    switch.add_argument("--type", dest="system_type", choices=("VANILLA", "FOSS", "GAPPS"), required=True)
    switch.add_argument("--yes", action="store_true", help="confirmar troca após criação de backup das imagens")
    images_sub.add_parser("verify", help="calcular hashes locais e verificar presença das imagens")
    images_sub.add_parser("ota", help="consultar manifests OTA reais configurados no Waydroid")

    backups = sub.add_parser("backup", help="backup e restauração de system.img/vendor.img")
    backup_sub = backups.add_subparsers(dest="backup_command", required=True)
    backup_sub.add_parser("create", help="criar backup das imagens atuais")
    backup_sub.add_parser("list", help="listar backups")
    restore = backup_sub.add_parser("restore", help="restaurar um backup de imagens")
    restore.add_argument("name")

    root = sub.add_parser("root", help="gerenciamento da integração Magisk")
    root_sub = root.add_subparsers(dest="root_command", required=True)
    root_sub.add_parser("status", help="verificar arquivos e runtime")
    install = root_sub.add_parser("install", help="instalar o adaptador Magisk 31.0 no overlay")
    install.add_argument("--stop", action="store_true", help="parar Waydroid se estiver em execução")
    root_sub.add_parser("remove", help="restaurar os arquivos originais do overlay")
    root_sub.add_parser("recover", help="restaurar backup-base após operação interrompida")

    modules = sub.add_parser("modules", help="gerenciar módulos pelo próprio Magisk")
    modules_sub = modules.add_subparsers(dest="modules_command", required=True)
    modules_sub.add_parser("list", help="listar módulos instalados")
    module_install = modules_sub.add_parser("install", help="instalar um ZIP usando magisk --install-module")
    module_install.add_argument("zip", type=Path)
    for action in ("enable", "disable", "remove"):
        item = modules_sub.add_parser(action, help=f"{action} módulo por ID")
        item.add_argument("id")

    apps = sub.add_parser("apps", help="gerenciar APKs e aplicativos Android pelo Waydroid")
    apps_sub = apps.add_subparsers(dest="apps_command", required=True)
    apps_sub.add_parser("list", help="listar aplicativos instalados")
    app_install = apps_sub.add_parser("install", help="instalar um APK")
    app_install.add_argument("apk", type=Path)
    app_remove = apps_sub.add_parser("remove", help="remover um aplicativo por nome de pacote")
    app_remove.add_argument("package")

    install_features = sub.add_parser("install", help="instalar um componente do catálogo Waydroid Script")
    install_features.add_argument("feature", choices=tuple(item["id"] for item in feature_manager.catalog()))
    install_features.add_argument("--variant", choices=("GAPPS", "VANILLA", "FOSS"), help="tipo de imagem oficial para o recurso gapps")
    install_features.add_argument("--rom", choices=("lineage", "bliss"), default="lineage", help="ROM oficial para o recurso gapps")
    install_features.add_argument("--ca-cert", type=Path, help="certificado CA PEM para o recurso mitm")
    install_features.add_argument("--yes", action="store_true", help="confirmar operações destrutivas, incluindo troca de imagem")
    install_features.add_argument("--stop", action="store_true", help="autorizar parada do Waydroid durante instalação Magisk")

    remove_features = sub.add_parser("remove", aliases=["uninstall"], help="remover um componente instalado pelo WCS")
    remove_features.add_argument("feature", choices=tuple(item["id"] for item in feature_manager.catalog()))

    sub.add_parser("features", help="listar todos os componentes do Waydroid Script e seu estado no WCS")
    hack = sub.add_parser("hack", help="executar os hacks legados do Waydroid Script (bloqueados se incompatíveis)")
    hack.add_argument("feature", choices=("nodataperm", "hidestatusbar"), nargs="+")
    sub.add_parser("certified", help="obter Android ID para registro no Google Play")
    sub.add_parser("extras", help="detectar GApps, microG, Widevine e ARM Native Bridge")
    sub.add_parser("microg", help="coletar evidências somente leitura para microG/autenticação")
    sub.add_parser("recovery", help="listar pontos de recuperação disponíveis")
    return parser



def _interactive_feature_install() -> None:
    require_root()
    features = feature_manager.catalog()
    print("\nCATÁLOGO DE COMPONENTES DO WAYDROID SCRIPT")
    print("=" * 88)
    for index, item in enumerate(features, start=1):
        print(f"[{index:02}] {item['name']} ({item['id']})")
        print(f"     Estado: {item['status']}")
        print(f"     {item['description']}")
    print("\nEscolha pelo número ou pelo identificador. Enter retorna ao menu.")
    selected = input("Componente: ").strip().lower()
    if not selected:
        return
    if selected.isdecimal():
        index = int(selected)
        if not 1 <= index <= len(features):
            raise WCSError("Número de componente fora do catálogo.")
        feature = features[index - 1]["id"]
    else:
        feature = selected
        if feature not in {item["id"] for item in features}:
            raise WCSError(f"Componente desconhecido: {feature}. Use um número ou ID exibido no catálogo.")
    variant = None
    ca_cert = None
    if feature == "gapps":
        variant = input("Tipo de imagem [VANILLA/FOSS/GAPPS]: ").strip().upper()
        if variant not in ("GAPPS", "VANILLA", "FOSS"):
            raise WCSError("Tipo de imagem inválido.")
        rom_choice = input("ROM oficial [lineage/bliss] (padrão lineage): ").strip().lower()
        rom_type = rom_choice if rom_choice in ("lineage", "bliss") else "lineage"
        if not _yes(f"A operação vai trocar a imagem oficial para {rom_type.upper()} / {variant}. Backup inclui system.img/vendor.img, mas NÃO /data. Continuar?"):
            print("Operação cancelada.")
            return
    elif feature == "mitm":
        raw = input("Caminho do certificado CA PEM: ").strip()
        if not raw:
            return
        ca_cert = Path(raw).expanduser()
    elif feature == "magisk":
        info = detection.inspect()
        stop = bool(info["running"] and _yes("Waydroid está ativo. Parar agora?"))
        _do_root_install(stop)
        return
    result = feature_manager.install_feature(feature, variant=variant, ca_cert=ca_cert, rom_type=locals().get("rom_type", "lineage"))
    print(result if isinstance(result, str) else json.dumps(result, indent=2, ensure_ascii=False, default=str))


def _interactive_feature_remove() -> None:
    require_root()
    print("\nCOMPONENTES REMOVÍVEIS")
    print("microg, smartdock, fdroidpriv, mitm, magisk")
    feature = input("Componente para remover (ou Enter para voltar): ").strip().lower()
    if not feature:
        return
    if feature == "magisk":
        if _yes("Restaurar os arquivos originais do overlay? Os dados /data não serão apagados."):
            _do_root_remove()
        return
    if not _yes(f"Agendar a remoção de {feature}?"):
        print("Operação cancelada.")
        return
    print(feature_manager.remove_feature(feature))


def interactive() -> int:
    while True:
        print("\n╔══════════════════════════════════════════╗")
        print(f"║          WAYDROID CUSTOM SCRIPT          ║\n║                 WCS {WCS_VERSION:<23}║")
        print("╚══════════════════════════════════════════╝")
        print("[1] Informações do Waydroid")
        print("[2] Catálogo oficial Waydroid (LineageOS/Bliss; VANILLA/FOSS/GAPPS)")
        print("[3] Consultar manifests OTA instalados")
        print("[4] Verificar imagens locais")
        print("[5] Fazer backup de system.img/vendor.img")
        print("[6] Listar backups")
        print("[7] Restaurar backup")
        print("[8] Status do Magisk/root")
        print("[9] Instalar Magisk 31.0 adaptado")
        print("[10] Remover integração Magisk do WCS")
        print("[11] Gerenciar módulos Magisk")
        print("[12] Diagnóstico")
        print("[13] Compatibilidade Zygisk / LSPosed")
        print("[14] Diagnóstico de extras Android (GApps/microG/Widevine/ARM bridge)")
        print("[15] Gerenciar APKs Android")
        print("[16] Obter Android ID do Google Play")
        print("[17] Catálogo e instaladores do Waydroid Script")
        print("[18] Remover componente instalado")
        print("[19] Releases WayDroid-ATV (imagens customizadas)")
        print("[20] Trocar imagem oficial (LineageOS/Bliss; VANILLA/FOSS/GAPPS)")
        print("[21] Diagnóstico somente leitura de microG/autenticação")
        print("[0] Sair")
        choice = input("\nWCS> ").strip()
        try:
            if choice == "0":
                return 0
            if choice == "1":
                _print_info()
            elif choice == "2":
                _print_official_catalog("host", "all", "all")
            elif choice == "3":
                _json(image_manager.inspect_ota_channels())
            elif choice == "4":
                _json(image_manager.verify_local_images())
                print("Nota: os SHA-256 exibidos são fingerprints locais, não comparação com checksums oficiais.")
            elif choice == "5":
                _do_backup_create()
            elif choice == "6":
                _json(backup.list_backups())
            elif choice == "7":
                name = input("Nome do backup: ").strip()
                if _yes(f"Restaurar {name}? As imagens atuais serão salvas antes."):
                    _do_backup_restore(name)
            elif choice == "8":
                _print_root_status()
            elif choice == "9":
                info = detection.inspect()
                stop = bool(info["running"] and _yes("Waydroid está ativo. Parar o contêiner agora?"))
                _do_root_install(stop)
            elif choice == "10":
                if _yes("Restaurar os arquivos originais do overlay? Os dados /data não serão apagados."):
                    _do_root_remove()
            elif choice == "11":
                _print_modules()
                print("Use `wcs modules install <arquivo.zip>`, `enable <id>`, `disable <id>` ou `remove <id>`. ")
            elif choice == "12":
                _print_doctor()
            elif choice == "13":
                for android_version in ("11", "13", "16", "17"):
                    _print_compatibility(android_version)
            elif choice == "14":
                _json(extras.inspect_extras())
            elif choice == "15":
                print("Use `wcs apps list`, `wcs apps install arquivo.apk` ou `wcs apps remove pacote.android`.")
            elif choice == "16":
                android_id = extras.get_android_id()
                print(f"Android ID: {android_id}")
                print("Registre em https://www.google.com/android/uncertified")
            elif choice == "17":
                _interactive_feature_install()
            elif choice == "18":
                _interactive_feature_remove()
            elif choice == "19":
                _print_catalog("all")
            elif choice == "20":
                rom = input("ROM [lineage/bliss] (padrão lineage): ").strip().lower() or "lineage"
                system_type = input("Tipo [VANILLA/FOSS/GAPPS]: ").strip().upper()
                if system_type not in ("VANILLA", "FOSS", "GAPPS"):
                    raise WCSError("Tipo de imagem inválido.")
                if _yes(f"Trocar para {rom.upper()} / {system_type}? Será criado backup de system.img e vendor.img, mas /data NÃO será incluído."):
                    _json(feature_manager.set_system_image_type(system_type, rom_type=rom))
            elif choice == "21":
                _json(extras.inspect_microg())
            else:
                print("Opção inválida.")
        except (WCSError, OSError) as exc:
            print(f"ERRO: {exc}", file=sys.stderr)
        input("\nPressione Enter para continuar...")


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command is None:
            return interactive()
        if args.command == "info":
            _print_info()
        elif args.command == "doctor":
            _print_doctor()
        elif args.command == "compatibility":
            _print_compatibility(args.android)
        elif args.command == "images":
            if args.images_command == "catalog":
                if args.source == "official":
                    _print_official_catalog(args.arch, args.rom, args.system_type)
                else:
                    _print_catalog(args.android)
            elif args.images_command == "atv-catalog":
                _print_catalog(args.android)
            elif args.images_command == "switch":
                if not args.yes and not _yes(
                    f"Trocar para imagem oficial {args.rom.upper()} / {args.system_type}? Backup inclui system.img/vendor.img, mas NÃO /data."
                ):
                    raise WCSError("Operação cancelada pelo usuário.")
                _json(feature_manager.set_system_image_type(args.system_type, rom_type=args.rom))
            elif args.images_command == "verify":
                _json(image_manager.verify_local_images())
                print("SHA-256 local calculado. Sem manifesto oficial, isso não certifica autenticidade da imagem.")
            elif args.images_command == "ota":
                _json(image_manager.inspect_ota_channels())
                print("Consulta somente leitura. O WCS ainda não baixa nem aplica atualizações OTA.")
        elif args.command == "backup":
            if args.backup_command == "create":
                _do_backup_create()
            elif args.backup_command == "list":
                _json(backup.list_backups())
            elif args.backup_command == "restore":
                _do_backup_restore(args.name)
        elif args.command == "root":
            if args.root_command == "status":
                _print_root_status()
            elif args.root_command == "install":
                _do_root_install(args.stop)
            elif args.root_command == "remove":
                _do_root_remove()
            elif args.root_command == "recover":
                require_root()
                archive = root_manager.recover_incomplete_install()
                print("Backup-base recuperado; overlay original restaurado.")
                print(f"Snapshot preservado em: {archive}")
        elif args.command == "modules":
            if args.modules_command == "list":
                _print_modules()
            elif args.modules_command == "install":
                require_root()
                result = module_manager.install_module(args.zip.expanduser())
                print(f"Módulo instalado/atualizado: {result['id']} ({result['name']})")
                print(f"SHA-256 do ZIP: {result['sha256']}")
                if result["output"]:
                    print(result["output"])
            elif args.modules_command in ("enable", "disable"):
                require_root()
                folder = module_manager.set_module_state(args.id, enabled=args.modules_command == "enable")
                print(f"Módulo {args.id}: {'habilitado' if args.modules_command == 'enable' else 'desabilitado'} em {folder}")
                print("A alteração entra em vigor no próximo boot do Android.")
            elif args.modules_command == "remove":
                require_root()
                folder = module_manager.queue_module_removal(args.id)
                print(f"Remoção de {args.id} agendada em {folder}/remove; será processada pelo Magisk no próximo boot.")
        elif args.command == "apps":
            if args.apps_command == "list":
                for app in extras.list_apps():
                    print(app)
            elif args.apps_command == "install":
                result = extras.install_apk(args.apk)
                print(f"APK instalado: {result['path']}")
                if result["output"]:
                    print(result["output"])
            elif args.apps_command == "remove":
                print(extras.remove_app(args.package) or f"Solicitada remoção de {args.package}.")
        elif args.command == "features":
            for item in feature_manager.catalog():
                print(f"{item['id']:14} | {item['status']:28} | {item['name']}")
                print(f"                 {item['description']}")
        elif args.command == "hack":
            require_root()
            for feature in args.feature:
                result = feature_manager.install_feature(feature)
                print(result if isinstance(result, str) else json.dumps(result, indent=2, ensure_ascii=False, default=str))
        elif args.command == "install":
            require_root()
            if args.feature == "magisk":
                _do_root_install(args.stop)
            else:
                if args.feature == "gapps" and not args.yes and not _yes(
                    f"Trocar para imagem oficial {args.rom.upper()} / {args.variant or 'tipo não definido'}? Será criado backup das imagens, mas /data não será incluído."
                ):
                    raise WCSError("Operação cancelada pelo usuário.")
                result = feature_manager.install_feature(args.feature, variant=args.variant, ca_cert=args.ca_cert, rom_type=args.rom)
                print(result if isinstance(result, str) else json.dumps(result, indent=2, ensure_ascii=False, default=str))
        elif args.command in ("remove", "uninstall"):
            require_root()
            if args.feature == "magisk":
                _do_root_remove()
            else:
                print(feature_manager.remove_feature(args.feature))
        elif args.command == "certified":
            android_id = extras.get_android_id()
            print(f"Android ID: {android_id}")
            print("Registre em https://www.google.com/android/uncertified")
        elif args.command == "extras":
            _json(extras.inspect_extras())
        elif args.command == "microg":
            _json(extras.inspect_microg())
        elif args.command == "recovery":
            _json(recovery.recovery_points())
        return 0
    except (WCSError, OSError) as exc:
        print(f"WCS: ERRO: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nOperação interrompida.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
