# SPDX-License-Identifier: GPL-3.0-or-later
"""Magisk 31.0 Waydroid overlay integration.

The release and patch offsets are pinned intentionally. They are not interchangeable with
other Magisk builds. The binary adaptations are based on the publicly documented Waydroid
integration work referenced in THIRD_PARTY_NOTICES.md; they must be validated on a real image.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import platform
import re
import shutil
import stat
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Any

from .common import (
    STATE_DIR, WCSError, atomic_write, download_verified, ensure_no_symlink_path,
    json_dump, run_command,
)
from .detection import get_status, inspect, require_stopped

MAGISK_VERSION = "31.0"
MAGISK_URL = "https://github.com/topjohnwu/Magisk/releases/download/v31.0/Magisk-v31.0.apk"
MAGISK_SHA256 = "2c8a488b9a5293e578e95ae4f07e3c57aba4feec4a52ca4dd852a2692d6dd4e8"
APK_CACHE = STATE_DIR / "cache" / f"Magisk-v{MAGISK_VERSION}.apk"
ROOT_STATE = STATE_DIR / "root-state"
BASELINE = ROOT_STATE / "baseline"
INSTALLED_MARKER = ROOT_STATE / "installed.json"
MAGISK_REL = "system/etc/init/magisk"
BOOTANIM_REL = "system/etc/init/bootanim.rc"
BOOTANIM_GZ_REL = "system/etc/init/bootanim.rc.gz"
OWNED_PATHS = (MAGISK_REL, BOOTANIM_REL, BOOTANIM_GZ_REL)

# Offsets are deliberately tied to the SHA-256-pinned v31.0 APK. A mismatch aborts installation.
PATCHES: dict[str, dict[str, tuple[tuple[int, str, str], ...]]] = {
    "x86_64": {
        "magisk": (
            (0x27B2D, "e84e0d0000837c2410008844240f", "837c2410000f94c08844240f9090"),
            (0x3B232, "7514", "9090"),
        ),
        "magisk32": ((0x3E66F, "7512", "9090"),),
    },
    "arm64-v8a": {
        "magisk": (
            (0x27B00, "dd020094f903002a", "9f020071f9179f1a"),
            (0x381E8, "c1000054", "1f2003d5"),
        ),
        "magisk32": ((0x20226, "07d1", "00bf"),),
    },
    "x86": {"magisk": ((0x3E66F, "7512", "9090"),), "magisk32": ()},
    "armeabi-v7a": {"magisk": ((0x20226, "07d1", "00bf"),), "magisk32": ()},
}

ARCH_MAP = {
    "x86_64": ("x86_64", "x86"),
    "x86": ("x86", "x86"),
    "arm64-v8a": ("arm64-v8a", "armeabi-v7a"),
    "aarch64": ("arm64-v8a", "armeabi-v7a"),
    "arm64": ("arm64-v8a", "armeabi-v7a"),
    "armeabi-v7a": ("armeabi-v7a", "armeabi-v7a"),
    "arm": ("armeabi-v7a", "armeabi-v7a"),
    "armv7l": ("armeabi-v7a", "armeabi-v7a"),
}

# These init triggers are the Waydroid-specific Magisk entry point. They do not patch boot.img.
INIT_BLOCK = r'''# WCS BEGIN MAGISK
on post-fs-data
    start logd
    mount tmpfs magisk /debug_ramdisk mode=0755
    mkdir /data/adb 0700
    exec u:r:su:s0 root root -- /system/bin/sh /system/etc/init/magisk/setup.sh
    exec u:r:su:s0 root root -- /system/bin/sh -c "if [ -w /sys/fs/cgroup/init/cgroup.procs ]; then echo 0 > /sys/fs/cgroup/init/cgroup.procs; fi; exec /debug_ramdisk/magisk --post-fs-data"

on nonencrypted
    exec u:r:su:s0 root root -- /debug_ramdisk/magisk --service

on property:vold.decrypt=trigger_restart_framework
    exec u:r:su:s0 root root -- /debug_ramdisk/magisk --service

on property:sys.boot_completed=1
    exec u:r:su:s0 root root -- /debug_ramdisk/magisk --boot-complete

on property:init.svc.zygote=restarting
    exec u:r:su:s0 root root -- /debug_ramdisk/magisk --zygote-restart

on property:init.svc.zygote=stopped
    exec u:r:su:s0 root root -- /debug_ramdisk/magisk --zygote-restart
# WCS END MAGISK
'''

SETUP_SCRIPT = r'''#!/system/bin/sh
set -e
umask 022
M=/system/etc/init/magisk
T=/debug_ramdisk
B=/data/adb/magisk
mkdir -p "$B" /data/adb/modules /data/adb/post-fs-data.d /data/adb/service.d
for f in "$M"/*; do
    case "${f##*/}" in
        stub.apk|setup.sh) ;;
        *) cp -af "$f" "$B/" ;;
    esac
done
cp -af "$M/magisk" "$M/magisk32" "$M/magiskpolicy" "$M/stub.apk" "$T/"
ln -sf ./magisk "$T/su"
ln -sf ./magisk "$T/resetprop"
ln -sf ./magiskpolicy "$T/supolicy"
mkdir -p "$T/.magisk/device" "$T/.magisk/worker"
mount -t tmpfs -o mode=0755 worker "$T/.magisk/worker"
"$M/busybox" mount --make-private "$T/.magisk/worker"
touch "$T/.magisk/config"
# Waydroid does not provide a real preinit block device. 0:0 is a harmless placeholder.
[ -e "$T/.magisk/device/preinit" ] || mknod "$T/.magisk/device/preinit" b 0 0 || true
'''


def _arch_pair(info: dict[str, Any]) -> tuple[str, str]:
    raw = str(info.get("arch", "")).lower()
    if raw in ARCH_MAP:
        return ARCH_MAP[raw]
    machine = platform.machine().lower()
    if machine in ("x86_64", "amd64"):
        return ARCH_MAP["x86_64"]
    if machine in ("aarch64", "arm64"):
        return ARCH_MAP["aarch64"]
    raise WCSError(f"Arquitetura Android não suportada pelo adaptador Magisk WCS: {raw or machine}")


def _ensure_state_dirs() -> None:
    for directory in (STATE_DIR, ROOT_STATE, STATE_DIR / "cache", STATE_DIR / "staging"):
        absolute = Path(os.path.abspath(os.fspath(directory)))
        current = Path(absolute.anchor)
        for part in absolute.parts[1:]:
            current = current / part
            if current.is_symlink():
                raise WCSError(f"Diretório de estado contém link simbólico; operação bloqueada: {current}")
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        if directory.stat().st_uid != 0:
            raise WCSError(f"Diretório de estado não pertence a root: {directory}")
        try:
            os.chmod(directory, 0o700)
        except OSError:
            pass


def _checked_overlay_path(path: Path) -> Path:
    absolute = Path(os.path.abspath(os.fspath(path)))
    ensure_no_symlink_path(Path("/"), absolute.as_posix().lstrip("/"))
    return absolute


def _snapshot_hash(path: Path) -> str:
    digest = hashlib.sha256()
    if path.is_symlink():
        raise WCSError(f"Link simbólico não pode ser incluído no backup: {path}")
    if path.is_file():
        digest.update(b"F\0")
        digest.update(path.name.encode())
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()
    if not path.is_dir():
        raise WCSError(f"Tipo de arquivo não suportado no backup: {path}")
    digest.update(b"D\0")
    for child in sorted(path.rglob("*"), key=lambda p: p.relative_to(path).as_posix()):
        if child.is_symlink():
            raise WCSError(f"Link simbólico não pode ser incluído no backup: {child}")
        rel = child.relative_to(path).as_posix().encode()
        digest.update(b"D\0" if child.is_dir() else b"F\0")
        digest.update(rel + b"\0")
        if child.is_file():
            with child.open("rb") as handle:
                for block in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(block)
    return digest.hexdigest()


def _copy_without_symlinks(source: Path, destination: Path) -> None:
    st = source.lstat()
    if stat.S_ISLNK(st.st_mode):
        raise WCSError(f"O WCS não faz backup seguindo links simbólicos: {source}")
    if stat.S_ISDIR(st.st_mode):
        destination.mkdir(parents=True, exist_ok=False)
        shutil.copystat(source, destination, follow_symlinks=False)
        os.chown(destination, st.st_uid, st.st_gid, follow_symlinks=False)
        for child in source.iterdir():
            _copy_without_symlinks(child, destination / child.name)
    elif stat.S_ISREG(st.st_mode):
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination, follow_symlinks=False)
        os.chown(destination, st.st_uid, st.st_gid, follow_symlinks=False)
    else:
        raise WCSError(f"Tipo de arquivo não suportado na árvore do overlay: {source}")


def _remove_path(path: Path) -> None:
    if not os.path.lexists(path):
        return
    st = path.lstat()
    if stat.S_ISLNK(st.st_mode):
        raise WCSError(f"Recusa a remover link simbólico na árvore do Waydroid: {path}")
    if stat.S_ISDIR(st.st_mode):
        shutil.rmtree(path)
    else:
        path.unlink()


def _snapshot_overlay(overlay: Path) -> dict[str, object]:
    overlay = _checked_overlay_path(overlay)
    if not overlay.is_dir():
        raise WCSError(f"Overlay do Waydroid não é um diretório: {overlay}")
    _ensure_state_dirs()
    if BASELINE.is_symlink() or BASELINE.exists():
        raise WCSError("Já existe um backup-base de root. Remova o Magisk instalado pelo WCS antes de instalar novamente.")
    BASELINE.mkdir(parents=True, mode=0o700)
    files_dir = BASELINE / "files"
    files_dir.mkdir(mode=0o700)
    records: dict[str, object] = {}
    try:
        for relative in OWNED_PATHS:
            source = ensure_no_symlink_path(overlay, relative)
            exists = os.path.lexists(source)
            record: dict[str, object] = {"exists": exists}
            if exists:
                dest = files_dir / relative
                _copy_without_symlinks(source, dest)
                st = source.stat(follow_symlinks=False)
                record.update({"mode": stat.S_IMODE(st.st_mode), "uid": st.st_uid, "gid": st.st_gid, "sha256": _snapshot_hash(dest)})
            records[relative] = record
        json_dump(BASELINE / "manifest.json", {"format": 1, "created": int(time.time()), "paths": records})
        return records
    except Exception:
        shutil.rmtree(BASELINE, ignore_errors=True)
        raise


def _restore_overlay(overlay: Path) -> None:
    overlay = _checked_overlay_path(overlay)
    if not overlay.is_dir():
        raise WCSError(f"Overlay do Waydroid não é um diretório: {overlay}")
    if BASELINE.is_symlink() or BASELINE.parent.is_symlink():
        raise WCSError("Backup-base de root contém link simbólico; restauração bloqueada.")
    baseline_parent = BASELINE.parent
    if baseline_parent.is_symlink() or not baseline_parent.is_dir() or baseline_parent.stat().st_uid != 0:
        raise WCSError("Diretório-pai do backup-base é inseguro ou não pertence a root.")
    if not BASELINE.is_dir() or BASELINE.stat().st_uid != 0:
        raise WCSError("Backup-base não é um diretório pertencente a root.")
    files_dir = BASELINE / "files"
    if files_dir.is_symlink() or not files_dir.is_dir() or files_dir.stat().st_uid != 0:
        raise WCSError("Diretório de arquivos do backup-base é inseguro ou não pertence a root.")
    manifest_path = BASELINE / "manifest.json"
    try:
        manifest_stat = manifest_path.lstat()
    except FileNotFoundError:
        raise WCSError("Backup-base de root não encontrado ou inválido. Restauração automática cancelada.")
    if not stat.S_ISREG(manifest_stat.st_mode) or manifest_stat.st_uid != 0:
        raise WCSError("Manifesto do backup-base não é um arquivo regular pertencente a root.")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise WCSError(f"Manifesto do backup-base está corrompido: {exc}") from exc
    if manifest.get("format") != 1 or not isinstance(manifest.get("paths"), dict) or set(manifest.get("paths", {})) != set(OWNED_PATHS):
        raise WCSError("Manifesto do backup-base não corresponde à versão esperada.")
    validated: dict[str, tuple[Path, Path, dict[str, object]]] = {}
    # Validate every saved object before removing or replacing any live overlay path.
    for relative in OWNED_PATHS:
        target = ensure_no_symlink_path(overlay, relative)
        record = manifest["paths"][relative]
        if not isinstance(record, dict):
            raise WCSError(f"Registro inválido no backup-base: {relative}")
        saved = ensure_no_symlink_path(files_dir, relative)
        exists_value = record.get("exists")
        if not isinstance(exists_value, bool):
            raise WCSError(f"Registro de existência inválido no backup-base: {relative}")
        if exists_value:
            if not os.path.lexists(saved):
                raise WCSError(f"Arquivo original ausente ou inseguro no backup: {relative}")
            saved_stat = saved.lstat()
            if not (stat.S_ISREG(saved_stat.st_mode) or stat.S_ISDIR(saved_stat.st_mode)):
                raise WCSError(f"Tipo de arquivo original não suportado no backup: {relative}")
            if _snapshot_hash(saved) != record.get("sha256"):
                raise WCSError(f"Integridade do backup-base falhou: {relative}")
            for key in ("mode", "uid", "gid"):
                if key not in record or not isinstance(record[key], int):
                    raise WCSError(f"Metadado {key} ausente/inválido no backup-base: {relative}")
        validated[relative] = (target, saved, record)

    for relative in OWNED_PATHS:
        target, saved, record = validated[relative]
        _remove_path(target)
        if not record.get("exists"):
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_name(target.name + f".wcs-restore-{os.getpid()}")
        _copy_without_symlinks(saved, temp)
        os.replace(temp, target)
        try:
            os.chown(target, int(record["uid"]), int(record["gid"]), follow_symlinks=False)
            os.chmod(target, int(record["mode"]), follow_symlinks=False)
        except (PermissionError, OSError):
            raise WCSError(f"Conteúdo restaurado, mas não foi possível restaurar proprietário/modo: {relative}")


def _apply_patch(path: Path, offset: int, expected_hex: str, replacement_hex: str) -> None:
    expected = bytes.fromhex(expected_hex)
    replacement = bytes.fromhex(replacement_hex)
    if len(expected) != len(replacement):
        raise WCSError(f"Patch com tamanhos diferentes em {path}")
    with path.open("r+b") as handle:
        handle.seek(offset)
        actual = handle.read(len(expected))
        if actual != expected:
            raise WCSError(
                f"Binário Magisk não corresponde ao patch conhecido em {path.name} @ 0x{offset:x}. "
                "A instalação foi cancelada para não corromper o arquivo."
            )
        handle.seek(offset)
        handle.write(replacement)
        handle.flush()
        os.fsync(handle.fileno())


def _extract_magisk(apk: Path, stage: Path, arch: str, arch32: str) -> None:
    stage.mkdir(parents=True, mode=0o700)
    extracted = 0
    total_size = 0
    try:
        with zipfile.ZipFile(apk, "r") as archive:
            bad = archive.testzip()
            if bad:
                raise WCSError(f"APK Magisk contém entrada ZIP inválida: {bad}")
            names = set(archive.namelist())
            wanted = [name for name in names if name.startswith(f"lib/{arch}/lib") and name.endswith(".so")]
            wanted += [name for name in names if name.startswith("assets/") and name.count("/") == 1 and name.endswith(".sh")]
            if not wanted:
                raise WCSError(f"APK não contém bibliotecas esperadas para {arch}.")
            for name in sorted(set(wanted)):
                info = archive.getinfo(name)
                if info.file_size > 32 * 1024 * 1024:
                    raise WCSError(f"Arquivo grande demais no APK: {name}")
                total_size += info.file_size
                if total_size > 128 * 1024 * 1024:
                    raise WCSError("Conteúdo extraído do APK excedeu 128 MiB.")
                base = Path(name).name
                if name.startswith("lib/"):
                    output_name = base[3:-3]
                    mode = 0o755
                else:
                    output_name = base
                    mode = 0o644
                if not re.fullmatch(r"[A-Za-z0-9_.-]+", output_name):
                    raise WCSError(f"Nome inesperado dentro do APK: {name}")
                destination = stage / output_name
                with archive.open(name) as source, destination.open("xb") as output:
                    shutil.copyfileobj(source, output)
                os.chmod(destination, mode)
                extracted += 1
            # The 32-bit Magisk binary is a separately named shared object inside its ABI folder.
            name32 = f"lib/{arch32}/libmagisk.so"
            if arch32 != arch and name32 in names:
                with archive.open(name32) as source, (stage / "magisk32").open("xb") as output:
                    shutil.copyfileobj(source, output)
                os.chmod(stage / "magisk32", 0o755)
            # The app APK itself acts as Magisk's stub payload in this integration.
            shutil.copyfile(apk, stage / "stub.apk")
            os.chmod(stage / "stub.apk", 0o644)
    except (OSError, zipfile.BadZipFile) as exc:
        raise WCSError(f"Falha ao extrair APK Magisk: {exc}") from exc

    required = ("magisk", "magiskpolicy", "busybox")
    missing = [name for name in required if not (stage / name).is_file()]
    if missing:
        raise WCSError("APK Magisk não contém componentes obrigatórios: " + ", ".join(missing))
    if arch32 != arch and not (stage / "magisk32").is_file():
        raise WCSError("APK Magisk não contém o binário de 32 bits esperado.")
    for binary, patches in PATCHES[arch].items():
        file_path = stage / binary
        if not file_path.is_file():
            if patches:
                raise WCSError(f"Binário necessário para patch não encontrado: {binary}")
            continue
        for offset, before, after in patches:
            _apply_patch(file_path, offset, before, after)

    setup = stage / "setup.sh"
    setup.write_text(SETUP_SCRIPT, encoding="utf-8")
    os.chmod(setup, 0o755)


def _chown_magisk_tree(path: Path) -> None:
    for current, dirs, files in os.walk(path, followlinks=False):
        for name in dirs + files:
            entry = Path(current) / name
            if entry.is_symlink():
                raise WCSError(f"Link simbólico inesperado no staging Magisk: {entry}")
            os.chown(entry, 0, 2000)
            os.chmod(entry, 0o755 if entry.is_dir() or os.access(entry, os.X_OK) else 0o644)
    os.chown(path, 0, 2000)
    os.chmod(path, 0o755)


def _get_android_arch(info: dict[str, Any], fallback: tuple[str, str]) -> tuple[str, str]:
    value = str(info.get("arch", "")).lower()
    if value in ARCH_MAP:
        return ARCH_MAP[value]
    return fallback


def _version_from_running_info(info: dict[str, Any]) -> str:
    return str(info.get("android", "UNKNOWN"))



ACTIVE_WAYDROID_STATES = {"RUNNING", "STARTING", "STOPPING", "FROZEN", "FREEZING", "ABORTING"}


def _lxc_status(info: dict[str, Any]) -> str:
    """Read the LXC state directly as a second check after Waydroid's D-Bus stop."""
    if shutil.which("lxc-info") is None:
        return "UNKNOWN"
    root = Path(str(info.get("waydroid_root", "/var/lib/waydroid")))
    lxc_path = root / "lxc"
    result = run_command(
        ["lxc-info", "-P", str(lxc_path), "-n", "waydroid", "-sH"],
        check=False,
        timeout=10,
    )
    if result.returncode != 0:
        return "UNKNOWN"
    state = result.stdout.strip().upper()
    return state if state in ACTIVE_WAYDROID_STATES | {"STOPPED"} else "UNKNOWN"


def _stop_waydroid(info: dict[str, Any], *, timeout: float = 60.0) -> None:
    """Stop both the user session and LXC container, then wait for confirmed shutdown.

    `waydroid container stop` alone can leave the user's session manager reporting RUNNING.
    Commands are attempted independently because either layer may already be stopped.
    """
    # Stop the desktop/session side first so it releases its container attachment and mounts.
    run_command(["waydroid", "session", "stop"], check=False, timeout=120)
    run_command(["waydroid", "container", "stop"], check=False, timeout=120)

    deadline = time.monotonic() + timeout
    last_status: dict[str, str] = {}
    last_lxc = "UNKNOWN"
    while time.monotonic() < deadline:
        last_status = get_status()
        session_state = str(last_status.get("session", "UNKNOWN")).upper()
        container_state = str(last_status.get("container", "UNKNOWN")).upper()
        last_lxc = _lxc_status(info)

        waydroid_active = session_state in ACTIVE_WAYDROID_STATES or container_state in ACTIVE_WAYDROID_STATES
        lxc_active = last_lxc in ACTIVE_WAYDROID_STATES
        has_waydroid_state = session_state != "UNKNOWN" or container_state != "UNKNOWN"
        if not waydroid_active and not lxc_active and has_waydroid_state:
            return
        time.sleep(0.5)

    raise WCSError(
        "Waydroid não confirmou o desligamento após parar a sessão e o contêiner "
        f"(Session={last_status.get('session', 'UNKNOWN')}, "
        f"Container={last_status.get('container', 'UNKNOWN')}, LXC={last_lxc}). "
        "Nenhum arquivo foi modificado. Verifique `waydroid status` e `lxc-info -P /var/lib/waydroid/lxc -n waydroid -sH`."
    )


def _read_bootanim_from_system_image(info: dict[str, Any]) -> tuple[bytes, int]:
    """Read the stock bootanim.rc from system.img without changing the image.

    Waydroid's overlay directory is an additional lower layer, not a copy of the whole
    system image. Therefore a stock file commonly does not exist under overlay/ until
    an override is created. We mount system.img read-only to obtain its original bytes.
    """
    images_dir = Path(str(info.get("images_path", ""))).expanduser()
    image = images_dir / "system.img"
    if not image.is_file() or image.is_symlink():
        raise WCSError(f"system.img ausente ou inseguro; não foi possível obter bootanim.rc: {image}")
    ensure_no_symlink_path(Path("/"), image.as_posix().lstrip("/"))

    mount_dir = Path(tempfile.mkdtemp(prefix="wcs-system-image-"))
    mounted = False
    try:
        mount_dir.chmod(0o700)
        result = run_command(
            ["mount", "-o", "loop,ro,nosuid,nodev,noexec", str(image), str(mount_dir)],
            check=False,
            timeout=90,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "sem detalhes").strip()[-700:]
            raise WCSError(
                f"Não foi possível montar system.img somente para leitura para obter bootanim.rc: {detail}"
            )
        mounted = True

        candidates = (
            mount_dir / "system/etc/init/bootanim.rc",
            mount_dir / "etc/init/bootanim.rc",
        )
        for candidate in candidates:
            try:
                st = candidate.lstat()
            except FileNotFoundError:
                continue
            if not stat.S_ISREG(st.st_mode):
                raise WCSError(f"bootanim.rc dentro de system.img não é arquivo regular: {candidate}")
            return candidate.read_bytes(), stat.S_IMODE(st.st_mode)
        raise WCSError(
            "system.img foi montada, mas não contém system/etc/init/bootanim.rc nem "
            "etc/init/bootanim.rc. A estrutura desta imagem não corresponde ao adaptador WCS."
        )
    finally:
        if mounted:
            unmount = run_command(["umount", str(mount_dir)], check=False, timeout=60)
            if unmount.returncode != 0:
                raise WCSError(
                    f"Falha ao desmontar system.img de leitura: {(unmount.stderr or unmount.stdout).strip()[-500:]}"
                )
        shutil.rmtree(mount_dir, ignore_errors=True)


def _load_original_bootanim(overlay: Path, info: dict[str, Any]) -> tuple[bytes, int, str]:
    """Prefer an existing custom overlay override; otherwise read the stock image."""
    target = ensure_no_symlink_path(overlay, BOOTANIM_REL)
    if os.path.lexists(target):
        st = target.lstat()
        if not stat.S_ISREG(st.st_mode):
            raise WCSError(f"bootanim.rc no overlay não é arquivo regular: {target}")
        return target.read_bytes(), stat.S_IMODE(st.st_mode), "overlay"
    content, mode = _read_bootanim_from_system_image(info)
    return content, mode, "system.img"

def _check_upper_layer_conflicts(info: dict[str, Any]) -> None:
    """Do not add a lower-layer override if Waydroid's writable upper layer masks it."""
    upper_root = Path(str(info.get("overlay_rw", ""))) / "system"
    if not str(info.get("overlay_rw", "")).strip():
        raise WCSError("Caminho overlay_rw ausente; não é possível verificar conflitos com a camada superior do Waydroid.")
    for relative in (BOOTANIM_REL, MAGISK_REL):
        candidate = ensure_no_symlink_path(upper_root, relative)
        if os.path.lexists(candidate):
            raise WCSError(
                f"Já existe uma modificação na camada superior overlay_rw/system: {candidate}. "
                "O WCS não vai sobrescrever nem mascarar essa alteração. Investigue/remova o conflito manualmente primeiro."
            )


def install_magisk(*, confirm_stop: bool = False) -> dict[str, object]:
    """Install pinned Magisk v31.0 into Waydroid overlay; leave data partition untouched."""
    _ensure_state_dirs()
    info = inspect()
    if BASELINE.is_symlink() or BASELINE.exists():
        raise WCSError("Já existe um backup-base de root. Use `wcs root recover` para uma instalação interrompida ou `wcs root remove` para restaurar uma instalação registrada.")
    if INSTALLED_MARKER.is_symlink():
        raise WCSError("Registro de instalação Magisk é link simbólico; operação bloqueada.")
    if INSTALLED_MARKER.exists():
        raise WCSError("Já existe um registro de instalação Magisk do WCS. Consulte `wcs root status` ou remova a integração antes de instalar novamente.")
    if bool(info.get("running")):
        if not confirm_stop:
            raise WCSError("Waydroid está em execução. Execute novamente com --stop para permitir que o WCS pare o contêiner.")
        observed = dict(info)
        _stop_waydroid(info)
        stopped_info = inspect()
        for key in ("android", "sdk", "arch"):
            if str(stopped_info.get(key, "UNKNOWN")) in ("", "UNKNOWN"):
                stopped_info[key] = observed.get(key, stopped_info.get(key))
        info = stopped_info

    version = _version_from_running_info(info)
    sdk = str(info.get("sdk", "UNKNOWN"))
    if sdk == "UNKNOWN":
        version_to_sdk = {"11": "30", "12": "31", "12L": "32", "13": "33", "14": "34", "15": "35", "16": "36", "17": "37"}
        sdk = version_to_sdk.get(version, "UNKNOWN")
    try:
        api_level = int(sdk)
    except (TypeError, ValueError):
        api_level = 0
    # Official Waydroid OTA images currently cover Android 11 and 13; newer
    # compatible generations use the same overlay adapter, but remain unverified.
    if api_level < 30 or api_level > 37:
        raise WCSError(
            f"O adaptador Magisk WCS exige uma imagem Android API 30–37 identificada. "
            f"Detectado Android {version}, API {sdk}. Inicialize o Waydroid uma vez e tente novamente."
        )
    if version == "UNKNOWN":
        version = str(api_level)
    require_stopped(info)

    overlays = str(info.get("mount_overlays", "unknown")).lower()
    if overlays != "true":
        raise WCSError(
            "O WCS só modifica o overlay Waydroid quando mount_overlays=True. "
            "A configuração atual não confirma esse modo; nenhuma imagem será montada ou sobrescrita."
        )
    overlay = _checked_overlay_path(Path(str(info["overlay_dir"])))
    if not overlay.is_dir():
        raise WCSError(f"Diretório overlay ausente ou inseguro: {overlay}")
    _check_upper_layer_conflicts(info)
    bootanim = ensure_no_symlink_path(overlay, BOOTANIM_REL)
    original_bytes, original_mode, original_source = _load_original_bootanim(overlay, info)
    try:
        original_text = original_bytes.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise WCSError(f"bootanim.rc não é UTF-8 válido; instalação cancelada: {exc}") from exc
    if "service bootanim" not in original_text:
        raise WCSError(
            f"bootanim.rc obtido de {original_source} não contém a definição esperada "
            "de service bootanim; instalação cancelada."
        )
    if "# WCS BEGIN MAGISK" in original_text:
        raise WCSError("bootanim.rc já contém gatilhos WCS. Verifique root status antes de continuar.")
    magisk_dir = ensure_no_symlink_path(overlay, MAGISK_REL)
    if os.path.lexists(magisk_dir):
        raise WCSError(f"Já existe um diretório no destino {magisk_dir}; o WCS não vai sobrescrevê-lo.")

    fallback_arch = _arch_pair(info)
    arch, arch32 = _get_android_arch(info, fallback_arch)
    if arch not in PATCHES:
        raise WCSError(f"Arquitetura sem conjunto de patches Magisk 31.0: {arch}")

    # Obtain and validate the APK before touching the Waydroid overlay.
    apk = download_verified(MAGISK_URL, APK_CACHE, MAGISK_SHA256)
    stage_parent = STATE_DIR / "staging"
    stage_parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix="magisk-", dir=stage_parent)) / "magisk"
    stage.parent.mkdir(parents=True, exist_ok=True)
    try:
        _extract_magisk(apk, stage, arch, arch32)
        _chown_magisk_tree(stage)
        _snapshot_overlay(overlay)
        magisk_dir.parent.mkdir(parents=True, exist_ok=True)
        os.rename(stage, magisk_dir)
        # Create the overlay override from the immutable image's stock file when the
        # Waydroid overlay layer did not already contain one.
        if not os.path.lexists(bootanim):
            atomic_write(bootanim, original_bytes, original_mode)
            os.chown(bootanim, 0, 0)
        # Keep the pristine bootanim.rc alongside the modified file for Magisk update survival.
        gz_path = ensure_no_symlink_path(overlay, BOOTANIM_GZ_REL)
        with gz_path.open("wb") as handle:
            handle.write(gzip.compress(original_bytes, mtime=0))
        os.chown(gz_path, 0, 0)
        os.chmod(gz_path, 0o644)
        modified = original_text.rstrip() + "\n\n" + INIT_BLOCK
        temp_rc = bootanim.with_name(bootanim.name + f".wcs-new-{os.getpid()}")
        atomic_write(temp_rc, modified.encode("utf-8"), original_mode)
        os.chown(temp_rc, 0, 0)
        os.replace(temp_rc, bootanim)
        marker = {
            "format": 1,
            "installed": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "magisk_version": MAGISK_VERSION,
            "apk_sha256": MAGISK_SHA256,
            "android": version,
            "sdk": str(api_level),
            "abi": arch,
            "abi32": arch32,
            "overlay": str(overlay),
            "bootanim_source": original_source,
            "note": "Adaptador Waydroid baseado em bootanim.rc; ainda requer validação de boot e runtime nesta máquina.",
        }
        json_dump(INSTALLED_MARKER, marker)
        return {"version": MAGISK_VERSION, "android": version, "sdk": api_level, "abi": arch, "overlay": str(overlay), "status": "FILES_INSTALLED_RUNTIME_UNVERIFIED"}
    except Exception as original_error:
        # If the backup was created, roll back. Keep the baseline as an archived recovery point.
        if BASELINE.is_dir() and (BASELINE / "manifest.json").is_file():
            try:
                _restore_overlay(overlay)
                archive_root = STATE_DIR / "backups" / "root"
                archive_root.mkdir(parents=True, exist_ok=True)
                archive = archive_root / f"failed-install-{time.strftime('%Y%m%d-%H%M%S', time.gmtime())}-{os.getpid()}"
                os.rename(BASELINE, archive)
            except Exception as rollback_error:
                raise WCSError(f"Instalação falhou e o rollback também falhou: {rollback_error}") from original_error
        raise
    finally:
        shutil.rmtree(stage.parent, ignore_errors=True)


def remove_magisk() -> Path:
    _ensure_state_dirs()
    info = inspect()
    require_stopped(info)
    overlay = _checked_overlay_path(Path(str(info["overlay_dir"])))
    if not overlay.is_dir():
        raise WCSError(f"Overlay atual não é um diretório; remoção bloqueada: {overlay}")
    try:
        marker_stat = INSTALLED_MARKER.lstat()
    except FileNotFoundError:
        raise WCSError("Não há registro de instalação Magisk do WCS; remoção automática não é segura.")
    if not stat.S_ISREG(marker_stat.st_mode) or marker_stat.st_uid != 0:
        raise WCSError("Registro Magisk não é arquivo regular pertencente a root; remoção bloqueada.")
    try:
        marker = json.loads(INSTALLED_MARKER.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise WCSError(f"Registro da instalação inválido: {exc}") from exc
    if Path(str(marker.get("overlay", ""))) != overlay:
        raise WCSError("O overlay atual é diferente daquele usado na instalação. Recusando a remoção automática.")
    _restore_overlay(overlay)
    INSTALLED_MARKER.unlink(missing_ok=True)
    archive_root = STATE_DIR / "backups" / "root"
    for part in (STATE_DIR / "backups", archive_root):
        if part.is_symlink():
            raise WCSError(f"Diretório de recuperação é link simbólico: {part}")
    archive_root.mkdir(parents=True, exist_ok=True, mode=0o700)
    if archive_root.stat().st_uid != 0:
        raise WCSError(f"Diretório de recuperação não pertence a root: {archive_root}")
    archive = archive_root / f"baseline-{time.time_ns()}-{os.getpid()}"
    os.rename(BASELINE, archive)
    return archive


def recover_incomplete_install() -> Path:
    """Restore a baseline left by a power loss or interrupted WCS commit."""
    _ensure_state_dirs()
    info = inspect()
    from .detection import require_stopped
    require_stopped(info)
    overlay = _checked_overlay_path(Path(str(info["overlay_dir"])))
    if not overlay.is_dir():
        raise WCSError(f"Overlay atual não é um diretório; recuperação bloqueada: {overlay}")
    if not (BASELINE / "manifest.json").is_file():
        raise WCSError("Não existe backup-base para recuperar uma instalação interrompida.")
    if os.path.lexists(INSTALLED_MARKER):
        marker_stat = INSTALLED_MARKER.lstat()
        if not stat.S_ISREG(marker_stat.st_mode) or marker_stat.st_uid != 0:
            raise WCSError("Registro Magisk não é arquivo regular pertencente a root; recuperação bloqueada.")
        try:
            marker = json.loads(INSTALLED_MARKER.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise WCSError(f"Registro de instalação ilegível: {exc}") from exc
        if Path(str(marker.get("overlay", ""))) != overlay:
            raise WCSError("O backup-base pertence a outro overlay; recuperação bloqueada.")
    _restore_overlay(overlay)
    INSTALLED_MARKER.unlink(missing_ok=True)
    archive_root = STATE_DIR / "backups" / "root"
    for part in (STATE_DIR / "backups", archive_root):
        if part.is_symlink():
            raise WCSError(f"Diretório de recuperação é link simbólico: {part}")
    archive_root.mkdir(parents=True, exist_ok=True, mode=0o700)
    if archive_root.stat().st_uid != 0:
        raise WCSError(f"Diretório de recuperação não pertence a root: {archive_root}")
    archive = archive_root / f"recovered-{time.time_ns()}-{os.getpid()}"
    os.rename(BASELINE, archive)
    return archive


def root_install_state() -> dict[str, object]:
    overlay = _checked_overlay_path(Path(str(inspect()["overlay_dir"])))
    if not overlay.is_dir():
        raise WCSError(f"Overlay não é diretório; diagnóstico bloqueado: {overlay}")
    marker: dict[str, object] = {}
    if os.path.lexists(INSTALLED_MARKER):
        marker_stat = INSTALLED_MARKER.lstat()
        if not stat.S_ISREG(marker_stat.st_mode) or marker_stat.st_uid != 0:
            marker = {"record": "UNSAFE"}
        else:
            try:
                marker = json.loads(INSTALLED_MARKER.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                marker = {"record": "CORRUPT"}
    files_present = ensure_no_symlink_path(overlay, MAGISK_REL).is_dir()
    rc = ensure_no_symlink_path(overlay, BOOTANIM_REL)
    hook_present = rc.is_file() and "# WCS BEGIN MAGISK" in rc.read_text(encoding="utf-8", errors="replace")
    return {
        "registered": bool(marker) and marker.get("record") != "CORRUPT",
        "marker": marker,
        "files_present": files_present,
        "init_hook_present": hook_present,
        "baseline_present": (not BASELINE.is_symlink() and not (BASELINE / "manifest.json").is_symlink() and (BASELINE / "manifest.json").is_file()),
    }


def _adb_device() -> str | None:
    from .detection import get_status

    try:
        status = get_status()
        ip_address = status.get("ip_address", "").strip()
        allowed = {"127.0.0.1:5555", "localhost:5555"}
        if ip_address and ip_address.lower() not in ("unknown", "none", ""):
            allowed.add(f"{ip_address}:5555")
        result = run_command(["adb", "devices"], check=False, timeout=15)
    except WCSError:
        return None
    for line in result.stdout.splitlines()[1:]:
        fields = line.strip().split()
        if len(fields) >= 2 and fields[1] == "device":
            serial = fields[0]
            if "waydroid" in serial.lower() or serial in allowed:
                return serial
    return None


def runtime_probe() -> dict[str, object]:
    """Runtime probe through ADB; deliberately refuses to count a root LXC shell as proof."""
    serial = _adb_device()
    if not serial:
        return {"status": "NOT_VERIFIED", "reason": "Nenhum dispositivo Waydroid aparece como device no adb; a shell LXC pode ser root por si só e não serve como teste independente de MagiskSU."}
    def adb(*args: str):
        return run_command(["adb", "-s", serial, "shell", *args], check=False, timeout=30)
    caller = adb("id", "-u")
    caller_uid = caller.stdout.strip().splitlines()[-1] if caller.stdout.strip() else "UNKNOWN"
    magisk = adb("magisk", "-v")
    daemon = adb("pidof", "magiskd")
    if caller_uid == "0":
        return {"status": "NOT_VERIFIED", "serial": serial, "reason": "ADB já está como root; não é possível provar a elevação independente de MagiskSU."}
    if magisk.returncode != 0 or not daemon.stdout.strip():
        return {
            "status": "NOT_OPERATIONAL_OR_NOT_BOOTED",
            "serial": serial,
            "caller_uid": caller_uid,
            "magisk_daemon_version": magisk.stdout.strip() or "NOT RUNNING",
            "magiskd_pid": daemon.stdout.strip() or "NOT FOUND",
            "reason": "Magisk daemon não foi confirmado; o teste su não foi executado.",
        }
    su = adb("su", "-c", "id -u")
    su_uid = su.stdout.strip().splitlines()[-1] if su.stdout.strip() else ""
    operational = caller_uid != "UNKNOWN" and su.returncode == 0 and su_uid == "0" and magisk.returncode == 0 and bool(daemon.stdout.strip())
    return {
        "status": "OPERATIONAL" if operational else "NOT_OPERATIONAL_OR_DENIED",
        "serial": serial,
        "caller_uid": caller_uid,
        "su_uid": su_uid or "UNKNOWN",
        "magisk_daemon_version": magisk.stdout.strip() or "NOT RUNNING",
        "magiskd_pid": daemon.stdout.strip() or "NOT FOUND",
        "su_exit_code": su.returncode,
    }
