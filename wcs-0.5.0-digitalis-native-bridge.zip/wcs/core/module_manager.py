# SPDX-License-Identifier: GPL-3.0-or-later
"""Magisk-native module operations. WCS does not implement a parallel module loader."""
from __future__ import annotations

import os
import re
import shutil
import stat
import zipfile
from pathlib import Path
from typing import Any

from .common import WCSError, ensure_no_symlink_path, get_data_path, load_waydroid_config, run_command, sha256_file
from .detection import inspect, require_supported_android

MODULE_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,128}$")
REMOTE_MODULE_RE = re.compile(r"^wcs-module-[0-9a-f]{16}\.zip$")


def _module_roots() -> tuple[Path, Path]:
    cfg = load_waydroid_config()
    data = get_data_path(cfg)
    modules = ensure_no_symlink_path(data, "adb/modules")
    updates = ensure_no_symlink_path(data, "adb/modules_update")
    return modules, updates


def _read_prop(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    if path.is_symlink():
        return data
    try:
        if not path.is_file():
            return data
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return data
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        data[key.strip()] = value.strip()
    return data


def list_modules() -> list[dict[str, Any]]:
    roots = _module_roots()
    found: dict[str, dict[str, Any]] = {}
    for root in roots:
        if not root.is_dir():
            continue
        for folder in sorted(root.iterdir()):
            if not folder.is_dir() or folder.is_symlink():
                continue
            prop_path = folder / "module.prop"
            if prop_path.is_symlink() or not prop_path.is_file():
                continue
            prop = _read_prop(prop_path)
            module_id = prop.get("id", folder.name)
            if not MODULE_ID_RE.fullmatch(module_id) or module_id != folder.name:
                continue
            item = {
                "id": module_id,
                "name": prop.get("name", module_id),
                "version": prop.get("version", "unknown"),
                "versionCode": prop.get("versionCode", "unknown"),
                "author": prop.get("author", "unknown"),
                "description": prop.get("description", ""),
                "path": str(folder),
                "disabled": (folder / "disable").exists(),
                "pending_removal": (folder / "remove").exists(),
                "pending_update": root.name == "modules_update",
            }
            found[module_id] = item
    return sorted(found.values(), key=lambda x: str(x["id"]).lower())


def _validate_module_zip(archive_path: Path) -> tuple[str, dict[str, str]]:
    if not archive_path.is_file() or archive_path.is_symlink():
        raise WCSError(f"Arquivo ZIP não encontrado ou é link simbólico: {archive_path}")
    if archive_path.stat().st_size > 512 * 1024 * 1024:
        raise WCSError("ZIP de módulo excede o limite de 512 MiB.")
    try:
        with zipfile.ZipFile(archive_path) as archive:
            infos = archive.infolist()
            if len(infos) > 10000:
                raise WCSError("ZIP contém entradas demais para uma instalação segura.")
            names_seen: set[str] = set()
            total = 0
            for info in infos:
                name = info.filename.replace("\\", "/")
                if name in names_seen:
                    raise WCSError(f"ZIP contém entrada duplicada: {name}")
                names_seen.add(name)
                clean_name = name.rstrip("/")
                parts = clean_name.split("/")
                if (name.startswith("/") or re.match(r"^[A-Za-z]:", name)
                        or not clean_name or any(part in ("", ".", "..") for part in parts)):
                    raise WCSError(f"ZIP contém caminho inseguro: {info.filename}")
                mode = info.external_attr >> 16
                kind = mode & 0o170000
                if kind not in (0, 0o100000, 0o040000):
                    raise WCSError(f"ZIP contém tipo de arquivo especial: {info.filename}")
                total += info.file_size
                if total > 2 * 1024 * 1024 * 1024:
                    raise WCSError("Conteúdo descompactado do ZIP excede 2 GiB.")
            if archive.testzip() is not None:
                raise WCSError("ZIP de módulo falhou na verificação CRC.")
            prop_info = next((x for x in infos if x.filename == "module.prop"), None)
            if prop_info is None or prop_info.file_size > 64 * 1024:
                raise WCSError("ZIP não contém um module.prop válido na raiz.")
            prop = {}
            content = archive.read(prop_info).decode("utf-8", errors="replace")
            for line in content.splitlines():
                if "=" in line and not line.lstrip().startswith("#"):
                    key, value = line.split("=", 1)
                    prop[key.strip()] = value.strip()
            module_id = prop.get("id", "")
            if not MODULE_ID_RE.fullmatch(module_id):
                raise WCSError("module.prop não declara um id válido.")
            return module_id, prop
    except zipfile.BadZipFile as exc:
        raise WCSError(f"ZIP de módulo inválido: {exc}") from exc


def _require_running() -> dict[str, object]:
    info = inspect()
    if not info.get("running"):
        raise WCSError("Inicie o Waydroid antes de instalar ou executar ações de módulos Magisk.")
    require_supported_android(info, minimum_api=26, maximum_api=37)
    return info


def _build_magisk_install_stdin(remote_name: str) -> str:
    """Build the command consumed by the Android shell through stdin.

    Waydroid's host argparse consumes flags passed after ``waydroid shell``.
    Upstream issue waydroid/waydroid#2280 documents the supported workaround:
    pipe the command to ``waydroid shell``. The remote filename is restricted
    to a digest-derived basename so no shell metacharacters can enter here.
    """
    if not REMOTE_MODULE_RE.fullmatch(remote_name):
        raise WCSError("Nome de ZIP temporário WCS inválido.")
    remote_path = f"/data/local/tmp/{remote_name}"
    return (
        f"magisk --install-module '{remote_path}'\n"
        "_wcs_magisk_rc=$?\n"
        "printf 'WCS_MAGISK_INSTALL_EXIT=%s\\n' \"$_wcs_magisk_rc\"\n"
        "exit \"$_wcs_magisk_rc\"\n"
    )


def _run_magisk_install(remote_name: str):
    """Execute Magisk inside Android without passing its options to Waydroid."""
    script = _build_magisk_install_stdin(remote_name)
    return run_command(
        ["waydroid", "shell"],
        check=False,
        input_text=script,
        timeout=900,
    )


def _check_magisk_install_result(result) -> str:
    """Require both a successful Waydroid shell and an explicit guest Magisk status."""
    output = (result.stdout or "") + (result.stderr or "")
    matches = re.findall(r"(?:^|\n)WCS_MAGISK_INSTALL_EXIT=(\d+)(?:\r?\n|$)", output)
    if not matches:
        raise WCSError(
            "O Waydroid shell terminou sem confirmar a execução do instalador Magisk. "
            f"Código do Waydroid: {result.returncode}.\n{output[-3000:]}"
        )
    guest_code = int(matches[-1])
    if result.returncode != 0:
        raise WCSError(
            "O comando waydroid shell falhou ao executar o instalador dentro do Android. "
            f"Código Waydroid: {result.returncode}; código Magisk informado: {guest_code}.\n{output[-3000:]}"
        )
    if guest_code != 0:
        raise WCSError(
            "Magisk recusou o ZIP ou o script de instalação falhou. "
            f"Código Magisk: {guest_code}.\n{output[-3000:]}"
        )
    return output.strip()[-3000:]


def install_module(zip_path: Path) -> dict[str, object]:
    _require_running()
    module_id, prop = _validate_module_zip(zip_path)
    modules_dir, updates_dir = _module_roots()
    if not modules_dir.parent.is_dir():
        raise WCSError("Diretório /data/adb não foi localizado no data_path do Waydroid.")
    data_path = modules_dir.parent.parent
    temp_dir = ensure_no_symlink_path(data_path, "local/tmp")
    temp_dir.mkdir(parents=True, exist_ok=True)
    checksum = sha256_file(zip_path)
    remote_name = f"wcs-module-{checksum[:16]}.zip"
    staged_host = ensure_no_symlink_path(data_path, f"local/tmp/{remote_name}")
    if staged_host.exists():
        if staged_host.is_symlink() or not staged_host.is_file():
            raise WCSError(f"Arquivo temporário de módulo possui tipo inseguro: {staged_host}")
        staged_host.unlink()
    shutil.copyfile(zip_path, staged_host)
    os.chmod(staged_host, 0o644)
    try:
        result = _run_magisk_install(remote_name)
        output = _check_magisk_install_result(result)
    finally:
        staged_host.unlink(missing_ok=True)

    installed = modules_dir / module_id
    pending = updates_dir / module_id
    if not ((installed / "module.prop").is_file() or (pending / "module.prop").is_file()):
        raise WCSError(
            "Magisk informou sucesso, mas o módulo não apareceu em /data/adb/modules "
            "nem em /data/adb/modules_update. O WCS não marcará a instalação como concluída."
        )
    return {"id": module_id, "name": prop.get("name", module_id), "sha256": checksum, "output": output}


def _find_module(module_id: str) -> Path:
    if not MODULE_ID_RE.fullmatch(module_id):
        raise WCSError("ID de módulo inválido.")
    modules_dir, updates_dir = _module_roots()
    for root in (modules_dir, updates_dir):
        candidate = root / module_id
        prop_path = candidate / "module.prop"
        if candidate.is_dir() and not candidate.is_symlink() and prop_path.is_file() and not prop_path.is_symlink():
            return candidate
    raise WCSError(f"Módulo não encontrado: {module_id}")


def _validate_marker(path: Path) -> None:
    try:
        marker_stat = path.lstat()
    except FileNotFoundError:
        return
    if not stat.S_ISREG(marker_stat.st_mode):
        raise WCSError(f"Marcador de módulo não é arquivo regular: {path}")


def _remove_marker(path: Path) -> None:
    _validate_marker(path)
    if path.exists():
        path.unlink()


def _create_marker(path: Path) -> None:
    _validate_marker(path)
    if path.exists():
        return
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags, 0o644)
    os.close(fd)


def set_module_state(module_id: str, *, enabled: bool) -> Path:
    _require_running()
    folder = _find_module(module_id)
    disable = folder / "disable"
    remove = folder / "remove"
    _validate_marker(disable)
    _validate_marker(remove)
    if enabled:
        _remove_marker(disable)
        _remove_marker(remove)
    else:
        _create_marker(disable)
        _remove_marker(remove)
    return folder


def queue_module_removal(module_id: str) -> Path:
    _require_running()
    folder = _find_module(module_id)
    _validate_marker(folder / "disable")
    _validate_marker(folder / "remove")
    _create_marker(folder / "remove")
    _remove_marker(folder / "disable")
    return folder
