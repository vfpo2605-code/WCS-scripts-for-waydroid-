# SPDX-License-Identifier: GPL-3.0-or-later
"""Install/remove pinned ARM64-to-x86_64 Native Bridge payloads for Waydroid.

The legacy upstream payloads are published only for Android 11 and 13. libndk
and libhoudini are mutually exclusive active Native Bridge providers; WCS keeps
one selected provider in the overlay and restores the prior overlay/config on
switch or removal.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

from .common import STATE_DIR, WAYDROID_CONFIG, WCS_VERSION, WCSError, atomic_write, ensure_no_symlink_path, json_dump, load_waydroid_config, run_command
from .detection import inspect, require_stopped

# Pinned upstream archives and MD5 values are the exact version map used by
# casualsnek/waydroid_script. The upstream project exposes Android 11/13 only.
SOURCES: dict[str, dict[str, dict[str, str]]] = {
    "libndk": {
        "11": {
            "url": "https://github.com/supremegamers/vendor_google_proprietary_ndk_translation-prebuilt/archive/9324a8914b649b885dad6f2bfd14a67e5d1520bf.zip",
            "md5": "c9572672d1045594448068079b34c350",
            "archive_root": "vendor_google_proprietary_ndk_translation-prebuilt-9324a8914b649b885dad6f2bfd14a67e5d1520bf",
        },
        "13": {
            "url": "https://github.com/supremegamers/vendor_google_proprietary_ndk_translation-prebuilt/archive/68734c52556d3d7a6db34c603dd9276915c29f2f.zip",
            "md5": "0b2207c490fcb400aa5c87fcf0d52d38",
            "archive_root": "vendor_google_proprietary_ndk_translation-prebuilt-68734c52556d3d7a6db34c603dd9276915c29f2f",
        },
    },
    "libhoudini": {
        "11": {
            "url": "https://github.com/supremegamers/vendor_intel_proprietary_houdini/archive/81f2a51ef539a35aead396ab7fce2adf89f46e88.zip",
            "md5": "fbff756612b4144797fbc99eadcb6653",
            "archive_root": "vendor_intel_proprietary_houdini-81f2a51ef539a35aead396ab7fce2adf89f46e88",
        },
        "13": {
            "url": "https://github.com/supremegamers/vendor_intel_proprietary_houdini/archive/2f8f088671182e17e67321e098e8411a3972a628.zip",
            "md5": "37fe0899f1e4da7f9a724cca1c1ab1ea",
            "archive_root": "vendor_intel_proprietary_houdini-2f8f088671182e17e67321e098e8411a3972a628",
        },
    },
}

COMMON_PROPERTIES = {
    "ro.product.cpu.abilist": "x86_64,x86,arm64-v8a,armeabi-v7a,armeabi",
    "ro.product.cpu.abilist32": "x86,armeabi-v7a,armeabi",
    "ro.product.cpu.abilist64": "x86_64,arm64-v8a",
    "ro.enable.native.bridge.exec": "1",
    "ro.dalvik.vm.isa.arm": "x86",
    "ro.dalvik.vm.isa.arm64": "x86_64",
}
TRANSLATOR_PROPERTIES = {
    "libndk": {
        **COMMON_PROPERTIES,
        "ro.dalvik.vm.native.bridge": "libndk_translation.so",
        "ro.vendor.enable.native.bridge.exec": "1",
        "ro.vendor.enable.native.bridge.exec64": "1",
        "ro.ndk_translation.version": "0.2.3",
    },
    "libhoudini": {
        **COMMON_PROPERTIES,
        "ro.dalvik.vm.native.bridge": "libhoudini.so",
    },
}
REQUIRED_LIBRARY = {
    "libndk": "lib64/libndk_translation.so",
    "libhoudini": "lib64/libhoudini.so",
}
# The Houdini upstream archive provides executable files at bin/houdini and
# bin/houdini64. It does not provide bin/arm or bin/arm64 directories; requiring
# those nonexistent directories was the reported WCS 0.4.1 installation bug.
REQUIRED_TREES = (
    "etc/binfmt_misc",
    "lib/arm",
    "lib64/arm64",
)
REQUIRED_PAYLOAD = {
    "libndk": (
        "bin/ndk_translation_program_runner_binfmt_misc",
        "bin/ndk_translation_program_runner_binfmt_misc_arm64",
        "etc/ld.config.arm.txt",
        "etc/ld.config.arm64.txt",
        "etc/init/ndk_translation.rc",
    ),
    "libhoudini": (
        "bin/houdini",
        "bin/houdini64",
        "lib/libhoudini.so",
    ),
}

# The upstream Waydroid Script generates this file after copying the WSA
# prebuilts. The Houdini ZIP itself is not sufficient without these binfmt
# registrations, especially for 32-bit and 64-bit ARM ELF execution.
LIBHOUDINI_INIT_RC = r"""on early-init
    mount binfmt_misc binfmt_misc /proc/sys/fs/binfmt_misc
on property:ro.enable.native.bridge.exec=1
    exec -- /system/bin/sh -c "echo ':arm_exe:M::\\x7f\\x45\\x4c\\x46\\x01\\x01\\x01\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x02\\x00\\x28::/system/bin/houdini:P' > /proc/sys/fs/binfmt_misc/register"
    exec -- /system/bin/sh -c "echo ':arm_dyn:M::\\x7f\\x45\\x4c\\x46\\x01\\x01\\x01\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x03\\x00\\x28::/system/bin/houdini:P' >> /proc/sys/fs/binfmt_misc/register"
    exec -- /system/bin/sh -c "echo ':arm64_exe:M::\\x7f\\x45\\x4c\\x46\\x02\\x01\\x01\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x02\\x00\\xb7::/system/bin/houdini64:P' >> /proc/sys/fs/binfmt_misc/register"
    exec -- /system/bin/sh -c "echo ':arm64_dyn:M::\\x7f\\x45\\x4c\\x46\\x02\\x01\\x01\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x03\\x00\\xb7::/system/bin/houdini64:P' >> /proc/sys/fs/binfmt_misc/register"
"""
MAX_ARCHIVE_BYTES = 512 * 1024 * 1024
MAX_EXPANDED_BYTES = 1536 * 1024 * 1024
MAX_ARCHIVE_ENTRIES = 20000
STATE_ROOT = STATE_DIR / "arm-translation"
STATE_FILE = STATE_ROOT / "state.json"


def _safe_relative(raw: str) -> PurePosixPath:
    value = raw.replace("\\", "/")
    path = PurePosixPath(value)
    if not value or path.is_absolute() or any(part in ("", ".", "..") for part in path.parts):
        raise WCSError(f"Caminho inseguro no pacote do tradutor: {raw!r}")
    if re.match(r"^[A-Za-z]:", value):
        raise WCSError(f"Caminho Windows não permitido no pacote do tradutor: {raw!r}")
    return path


def _ensure_root_dir(path: Path) -> None:
    absolute = Path(os.path.abspath(os.fspath(path)))
    ensure_no_symlink_path(Path("/"), absolute.as_posix().lstrip("/"))
    absolute.mkdir(parents=True, exist_ok=True, mode=0o700)
    if absolute.is_symlink() or not absolute.is_dir() or absolute.stat().st_uid != 0:
        raise WCSError(f"Diretório de estado do tradutor inseguro ou não pertence a root: {absolute}")
    os.chmod(absolute, 0o700)


def _md5_file(path: Path) -> str:
    digest = hashlib.md5()  # pinned checksum published by the upstream installer
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _download_source(feature: str, android: str) -> Path:
    spec = SOURCES[feature][android]
    cache_dir = STATE_DIR / "cache" / "arm-translation"
    _ensure_root_dir(cache_dir)
    destination = cache_dir / f"{feature}-android{android}-{spec['md5']}.zip"
    if destination.is_symlink():
        raise WCSError(f"Cache do tradutor é link simbólico; download bloqueado: {destination}")
    if destination.is_file() and _md5_file(destination) == spec["md5"]:
        return destination
    if destination.exists():
        if not destination.is_file():
            raise WCSError(f"Cache do tradutor não é um arquivo regular: {destination}")
        destination.unlink()

    parsed = urllib.parse.urlparse(spec["url"])
    if parsed.scheme != "https" or parsed.hostname != "github.com":
        raise WCSError("URL de origem do tradutor não passou pela validação HTTPS/GitHub.")
    temp = destination.with_name(destination.name + f".part-{os.getpid()}")
    if temp.exists() or temp.is_symlink():
        raise WCSError(f"Download temporário já existe; não será sobrescrito: {temp}")
    digest = hashlib.md5()
    total = 0
    created = False
    fd: int | None = None
    try:
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
        created = True
        request = urllib.request.Request(spec["url"], headers={"User-Agent": f"Waydroid-Custom-Script/{WCS_VERSION}"})
        with urllib.request.urlopen(request, timeout=90) as response:
            final = urllib.parse.urlparse(response.geturl())
            if final.scheme != "https" or final.hostname not in {"github.com", "codeload.github.com"}:
                raise WCSError("O download do tradutor foi redirecionado para um host não autorizado.")
            output_file = os.fdopen(fd, "wb")
            fd = None
            with output_file as output:
                while True:
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    total += len(block)
                    if total > MAX_ARCHIVE_BYTES:
                        raise WCSError("O pacote do tradutor excedeu o limite de download de 512 MiB.")
                    digest.update(block)
                    output.write(block)
                output.flush()
                os.fsync(output.fileno())
        actual = digest.hexdigest()
        if actual.lower() != spec["md5"].lower():
            raise WCSError(f"MD5 do pacote {feature} incorreto. Esperado {spec['md5']}, recebido {actual}.")
        os.chmod(temp, 0o600)
        os.replace(temp, destination)
        created = False
        return destination
    except WCSError:
        raise
    except Exception as exc:
        raise WCSError(f"Falha ao baixar {feature} para Android {android}: {exc}") from exc
    finally:
        if fd is not None:
            os.close(fd)
        if created:
            try:
                temp.unlink()
            except FileNotFoundError:
                pass


def _extract_prebuilts(archive_path: Path, feature: str, android: str, destination: Path) -> tuple[list[str], list[str]]:
    spec = SOURCES[feature][android]
    prefix = spec["archive_root"] + "/prebuilts/"
    total_uncompressed = 0
    files: list[str] = []
    dirs: list[str] = []
    try:
        with zipfile.ZipFile(archive_path) as archive:
            infos = archive.infolist()
            if len(infos) > MAX_ARCHIVE_ENTRIES:
                raise WCSError("O pacote do tradutor contém entradas demais.")
            archive_uncompressed = sum(info.file_size for info in infos)
            if archive_uncompressed > MAX_EXPANDED_BYTES:
                raise WCSError("O conteúdo descompactado do pacote excede o limite de 1,5 GiB.")
            if archive.testzip() is not None:
                raise WCSError("O ZIP do tradutor falhou na verificação CRC.")
            found_root = False
            for info in infos:
                name = info.filename.replace("\\", "/")
                if name.rstrip("/") == spec["archive_root"] + "/prebuilts":
                    found_root = True
                    continue
                if not name.startswith(prefix):
                    continue
                found_root = True
                relative_raw = name[len(prefix):].rstrip("/")
                if not relative_raw:
                    continue
                relative = _safe_relative(relative_raw)
                target = destination.joinpath(*relative.parts)
                ensure_no_symlink_path(destination, relative.as_posix())
                mode = (info.external_attr >> 16) & 0xFFFF
                is_link = stat.S_ISLNK(mode)
                is_dir = info.is_dir() or stat.S_ISDIR(mode)
                if is_dir:
                    target.mkdir(parents=True, exist_ok=True)
                    dirs.append(relative.as_posix())
                    continue
                total_uncompressed += info.file_size
                if total_uncompressed > MAX_EXPANDED_BYTES:
                    raise WCSError("O pacote do tradutor excedeu o limite de extração de 1,5 GiB.")
                target.parent.mkdir(parents=True, exist_ok=True)
                if is_link:
                    link_text = archive.read(info).decode("utf-8", errors="strict")
                    link_path = PurePosixPath(link_text)
                    resolved = PurePosixPath(*relative.parent.parts, *link_path.parts)
                    depth = 0
                    for part in resolved.parts:
                        if part == "..":
                            depth -= 1
                        elif part not in ("", "."):
                            depth += 1
                        if depth < 0 or link_path.is_absolute():
                            raise WCSError(f"Link simbólico externo no pacote do tradutor: {relative} -> {link_text}")
                    os.symlink(link_text, target)
                else:
                    with archive.open(info) as source, target.open("xb") as output:
                        shutil.copyfileobj(source, output, length=1024 * 1024)
                    os.chmod(target, 0o600)
                files.append(relative.as_posix())
            if not found_root:
                raise WCSError(f"O ZIP não contém a árvore prebuilts esperada para {feature}.")
    except WCSError:
        raise
    except (zipfile.BadZipFile, OSError, UnicodeError, RuntimeError) as exc:
        raise WCSError(f"Não foi possível extrair com segurança o pacote {feature}: {exc}") from exc

    available = set(files) | set(dirs)
    required = (REQUIRED_LIBRARY[feature], *REQUIRED_PAYLOAD[feature])
    missing = [path for path in required if path not in available and not (destination / path).is_file()]
    if missing:
        raise WCSError(f"O pacote {feature} está incompleto; faltam: {', '.join(missing)}. Instalação cancelada.")
    missing_trees = [
        root for root in REQUIRED_TREES
        if not any(path == root or path.startswith(root + "/") for path in available)
    ]
    if missing_trees:
        raise WCSError(f"O pacote {feature} está incompleto; árvores ausentes: {', '.join(missing_trees)}.")
    return sorted(set(files)), sorted(set(dirs), key=lambda value: (value.count("/"), value))


def _read_section_values(config_path: Path, section: str, keys: list[str]) -> dict[str, str | None]:
    cfg = load_waydroid_config(config_path)
    source = cfg[section] if cfg.has_section(section) else {}
    return {key: source.get(key) for key in keys}


def _rewrite_config_section(config_path: Path, section: str, updates: dict[str, str | None]) -> None:
    """Update exactly one INI section while preserving unrelated lines and comments."""
    if config_path.is_symlink() or not config_path.is_file():
        raise WCSError(f"Configuração Waydroid ausente ou insegura: {config_path}")
    original = config_path.read_bytes()
    try:
        text = original.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise WCSError("waydroid.cfg não está em UTF-8 válido; propriedades não foram alteradas.") from exc
    newline = "\r\n" if "\r\n" in text else "\n"
    lines = text.splitlines(keepends=True)
    header_re = re.compile(r"^\s*\[([^\]]+)\]\s*(?:[;#].*)?(?:\r?\n)?$")
    option_re = re.compile(r"^\s*([^\s=:#]+)\s*[:=]")
    start = None
    end = len(lines)
    for index, line in enumerate(lines):
        match = header_re.match(line)
        if not match:
            continue
        name = match.group(1).strip().lower()
        if start is None and name == section.lower():
            start = index
        elif start is not None:
            end = index
            break

    if start is None:
        if not any(value is not None for value in updates.values()):
            return
        if text and not text.endswith(("\n", "\r")):
            text += newline
        if text and not text.endswith(newline * 2):
            text += newline
        text += f"[{section}]" + newline
        for key, value in updates.items():
            if value is not None:
                text += f"{key} = {value}{newline}"
    else:
        seen: set[str] = set()
        rebuilt = lines[:start + 1]
        for line in lines[start + 1:end]:
            match = option_re.match(line)
            key = match.group(1).lower() if match else None
            if key not in updates:
                rebuilt.append(line)
                continue
            if key in seen:
                continue
            seen.add(key)
            value = updates[key]
            if value is not None:
                rebuilt.append(f"{match.group(1)} = {value}{newline}")
        for key, value in updates.items():
            if key not in seen and value is not None:
                rebuilt.append(f"{key} = {value}{newline}")
        rebuilt.extend(lines[end:])
        text = "".join(rebuilt)

    mode = stat.S_IMODE(config_path.stat().st_mode)
    atomic_write(config_path, text.encode("utf-8"), mode)


def _prepare_waydroid_settings(data_path: Path, bridge_value: str, backup_root: Path) -> tuple[dict[str, Any], bool, str]:
    """Back up then set /data/misc/waydroid_settings like Waydroid/Refract expect."""
    data_path = Path(data_path)
    if not data_path.is_absolute() or data_path == Path("/") or data_path.is_symlink() or not data_path.is_dir():
        raise WCSError(f"data_path Waydroid ausente ou inseguro: {data_path}")
    ensure_no_symlink_path(Path("/"), data_path.as_posix().lstrip("/"))
    misc = data_path / "misc"
    if misc.is_symlink():
        raise WCSError(f"Diretório /data/misc é link simbólico; instalação bloqueada: {misc}")
    misc_created = not misc.exists()
    if misc_created:
        misc.mkdir(mode=0o1771)
        os.chown(misc, 1000, 9998)
        os.chmod(misc, 0o1771)
    elif not misc.is_dir():
        raise WCSError(f"/data/misc não é diretório: {misc}")
    settings = misc / "waydroid_settings"
    if settings.is_symlink():
        raise WCSError(f"waydroid_settings é link simbólico; instalação bloqueada: {settings}")
    if settings.exists():
        if not settings.is_file():
            raise WCSError(f"waydroid_settings não é arquivo regular: {settings}")
        original = _snapshot_original(settings, backup_root / "data/misc/waydroid_settings")
    else:
        original = {"kind": "missing"}
    if settings.exists():
        try:
            lines = settings.read_text(encoding="utf-8").splitlines()
        except UnicodeDecodeError as exc:
            raise WCSError("/data/misc/waydroid_settings não está em UTF-8; nenhuma alteração feita.") from exc
        lines = [line for line in lines if line.partition("=")[0].strip() != "ro.dalvik.vm.native.bridge"]
    else:
        lines = []
    lines.append(f"ro.dalvik.vm.native.bridge={bridge_value}")
    atomic_write(settings, ("\n".join(lines) + "\n").encode("utf-8"), 0o644)
    os.chmod(settings, 0o644)
    return ({"path": str(settings), "original": original}, misc_created, _sha256_file(settings))


def _restore_waydroid_settings(state: dict[str, Any], *, verify_current: bool = True) -> None:
    item = state.get("waydroid_settings")
    if not item:
        return
    path = Path(item.get("path", ""))
    if not path.is_absolute() or path.is_symlink():
        raise WCSError("Caminho original de waydroid_settings é inválido/inseguro.")
    ensure_no_symlink_path(Path("/"), path.as_posix().lstrip("/"))
    current = path
    if current.exists() and (current.is_symlink() or not current.is_file()):
        raise WCSError(f"waydroid_settings mudou de tipo; restauração interrompida: {current}")
    installed_hash = state.get("installed_settings_sha256")
    if verify_current and current.exists() and installed_hash and _sha256_file(current) != installed_hash:
        raise WCSError("/data/misc/waydroid_settings foi alterado depois da instalação; preservado para não apagar mudanças externas.")
    original = item.get("original", {})
    if original.get("kind") == "missing":
        current.unlink(missing_ok=True)
    elif original.get("kind") == "file":
        backup = STATE_ROOT / original.get("backup", "")
        if backup.is_symlink() or not backup.is_file():
            raise WCSError("Backup original de /data/misc/waydroid_settings não foi encontrado.")
        current.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(backup, current, follow_symlinks=False)
        _restore_metadata(current, original)
    else:
        raise WCSError("Tipo de backup de waydroid_settings não reconhecido.")
    if state.get("settings_misc_created"):
        try:
            current.parent.rmdir()
        except OSError:
            pass


def _read_properties(config_path: Path, keys: list[str]) -> dict[str, str | None]:
    cfg = load_waydroid_config(config_path)
    section = cfg["properties"] if cfg.has_section("properties") else {}
    return {key: section.get(key) for key in keys}


def _rewrite_properties(config_path: Path, updates: dict[str, str | None]) -> None:
    _rewrite_config_section(config_path, "properties", updates)


def _remove_path(path: Path) -> None:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return
    if stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode):
        raise WCSError(f"Um arquivo do tradutor virou diretório; remoção interrompida para preservar dados: {path}")
    path.unlink()


def _path_under(base: Path, relative: str) -> Path:
    rel = _safe_relative(relative)
    if rel.as_posix() == ".":
        raise WCSError("Caminho vazio no registro do tradutor.")
    parent = rel.parent.as_posix()
    if parent != ".":
        ensure_no_symlink_path(base, parent)
    else:
        ensure_no_symlink_path(Path("/"), base.as_posix().lstrip("/"))
    return base.joinpath(*rel.parts)


def _snapshot_original(path: Path, backup_path: Path) -> dict[str, Any]:
    info = path.lstat()
    common = {"mode": stat.S_IMODE(info.st_mode), "uid": info.st_uid, "gid": info.st_gid}
    if stat.S_ISLNK(info.st_mode):
        return {"kind": "symlink", "target": os.readlink(path), **common}
    if not stat.S_ISREG(info.st_mode):
        raise WCSError(f"Tipo de arquivo preexistente não suportado no overlay: {path}")
    backup_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    shutil.copy2(path, backup_path, follow_symlinks=False)
    return {"kind": "file", "backup": backup_path.relative_to(STATE_ROOT).as_posix(), **common}


def _restore_metadata(path: Path, item: dict[str, Any]) -> None:
    try:
        os.chown(path, int(item["uid"]), int(item["gid"]), follow_symlinks=False)
        if not path.is_symlink():
            os.chmod(path, int(item["mode"]))
    except (OSError, NotImplementedError):
        # Content restoration still proceeds; host filesystems may reject owner changes.
        pass


def _restore_state(*, verify_current: bool = True) -> str:
    if STATE_FILE.is_symlink() or not STATE_FILE.is_file():
        raise WCSError("Não existe um registro válido de instalação WCS dos tradutores.")
    try:
        state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception as exc:
        raise WCSError(f"Registro de instalação do tradutor ilegível: {exc}") from exc
    if not isinstance(state, dict) or state.get("schema") != 1 or state.get("manager") != "wcs-arm-translation":
        raise WCSError("Registro de instalação do tradutor tem formato desconhecido; nada foi removido.")
    overlay = Path(state.get("overlay", ""))
    if not overlay.is_absolute() or overlay.is_symlink():
        raise WCSError("Caminho de overlay registrado é inseguro.")
    system_root = overlay / "system"
    ensure_no_symlink_path(Path("/"), system_root.as_posix().lstrip("/"))

    initial_status = str(state.get("status", "installed"))
    # Check every current payload/config artifact before the first restore attempt.
    # A persisted "restoring" journal means a previous restore got part-way through;
    # the remaining steps are intentionally idempotent and must be safe to retry.
    verify_before_restore = verify_current and initial_status != "restoring" and initial_status == "installed"
    if verify_before_restore:
        config_path_check = Path(state.get("config_path", ""))
        if "installed_properties" in state:
            current_properties = _read_properties(config_path_check, list(state["installed_properties"]))
            if current_properties != state["installed_properties"]:
                raise WCSError("As propriedades [properties] do tradutor foram alteradas depois da instalação; restauração interrompida para preservar mudanças externas.")
        if "installed_waydroid_options" in state:
            current_waydroid = _read_section_values(config_path_check, "waydroid", list(state["installed_waydroid_options"]))
            if current_waydroid != state["installed_waydroid_options"]:
                raise WCSError("As opções [waydroid] do tradutor foram alteradas depois da instalação; restauração interrompida para preservar mudanças externas.")
        settings_item = state.get("waydroid_settings")
        if settings_item:
            settings_path = Path(settings_item.get("path", ""))
            if settings_path.exists():
                if settings_path.is_symlink() or not settings_path.is_file():
                    raise WCSError(f"waydroid_settings mudou de tipo: {settings_path}")
                if state.get("installed_settings_sha256") and _sha256_file(settings_path) != state["installed_settings_sha256"]:
                    raise WCSError("/data/misc/waydroid_settings foi alterado depois da instalação; nada foi restaurado.")
        for item in state.get("installed_files", []):
            rel = item.get("path")
            dest = _path_under(system_root, rel)
            if not (dest.exists() or dest.is_symlink()):
                continue
            if dest.is_symlink():
                if item.get("installed_kind") != "symlink" or os.readlink(dest) != item.get("installed_target"):
                    raise WCSError(f"Arquivo do tradutor foi alterado após a instalação; preservado: {dest}")
            elif dest.is_file():
                if item.get("installed_kind") != "file" or _sha256_file(dest) != item.get("installed_sha256"):
                    raise WCSError(f"Arquivo do tradutor foi alterado após a instalação; preservado: {dest}")
            else:
                raise WCSError(f"Destino do tradutor mudou de tipo após a instalação; preservado: {dest}")

    state["status"] = "restoring"
    json_dump(STATE_FILE, state)

    for item in sorted(state.get("installed_files", []), key=lambda entry: entry["path"].count("/"), reverse=True):
        dest = _path_under(system_root, item["path"])
        _remove_path(dest)

    # Remove only directories created by this installation, and only when empty.
    for relative in sorted(state.get("created_dirs", []), key=lambda value: value.count("/"), reverse=True):
        directory = _path_under(system_root, relative)
        try:
            directory.rmdir()
        except FileNotFoundError:
            pass
        except OSError:
            # Preserve unrelated files added to a directory after installation.
            pass

    for item in sorted(state.get("originals", []), key=lambda entry: entry["path"].count("/")):
        dest = _path_under(system_root, item["path"])
        dest.parent.mkdir(parents=True, exist_ok=True)
        if item["kind"] == "file":
            backup = STATE_ROOT / item["backup"]
            if backup.is_symlink() or not backup.is_file():
                raise WCSError(f"Backup original do tradutor ausente ou inseguro: {backup}")
            shutil.copy2(backup, dest, follow_symlinks=False)
            _restore_metadata(dest, item)
        elif item["kind"] == "symlink":
            os.symlink(item["target"], dest)
            _restore_metadata(dest, item)
        else:
            raise WCSError(f"Tipo de backup desconhecido para {item['path']}.")

    config_path = Path(state["config_path"])
    if "original_waydroid_options" in state:
        _rewrite_config_section(config_path, "waydroid", state.get("original_waydroid_options", {}))
    _rewrite_properties(config_path, state.get("original_properties", {}))
    _restore_waydroid_settings(state, verify_current=verify_before_restore)
    if state.get("refresh_waydroid_config"):
        result = run_command(["waydroid", "upgrade", "--offline"], check=False, timeout=900)
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "sem detalhes").strip()[-1200:]
            raise WCSError("Os arquivos foram restaurados, mas `waydroid upgrade --offline` não conseguiu regenerar a configuração. O registro/backup WCS foi preservado para nova tentativa.\n" + detail)
    shutil.rmtree(STATE_ROOT)
    return str(state.get("active", "tradutor"))


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _image_android_version(info: dict[str, Any]) -> str:
    android = str(info.get("android", "UNKNOWN")).strip()
    if android in {"11", "13"}:
        return android
    sdk = str(info.get("sdk", "UNKNOWN")).strip()
    mapped = {"30": "11", "33": "13"}.get(sdk)
    if mapped:
        return mapped

    # When Waydroid is stopped, official OTA URLs often do not encode the
    # Android generation. Read the SDK property from system.img without
    # modifying it instead of guessing from the image channel.
    image = Path(str(info.get("images_path", ""))).expanduser() / "system.img"
    if not image.is_file() or image.is_symlink():
        return "UNKNOWN"
    ensure_no_symlink_path(Path("/"), image.as_posix().lstrip("/"))
    mount_dir = Path(tempfile.mkdtemp(prefix="wcs-arm-translation-probe-"))
    mounted = False
    try:
        mount_dir.chmod(0o700)
        result = run_command(
            ["mount", "-o", "loop,ro,nosuid,nodev,noexec", str(image), str(mount_dir)],
            check=False, timeout=90,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "sem detalhes").strip()[-500:]
            raise WCSError(f"Não foi possível identificar a versão Android de system.img somente para leitura: {detail}")
        mounted = True
        candidates = (
            mount_dir / "build.prop",
            mount_dir / "system/build.prop",
            mount_dir / "system/system/build.prop",
        )
        for candidate in candidates:
            if not candidate.is_file() or candidate.is_symlink():
                continue
            match = re.search(r"(?m)^\s*ro\.build\.version\.sdk\s*=\s*(\d+)\s*$", candidate.read_text(errors="replace"))
            if match:
                return {"30": "11", "33": "13"}.get(match.group(1), "UNSUPPORTED")
        raise WCSError("system.img foi montada, mas não contém ro.build.version.sdk nos caminhos esperados.")
    finally:
        if mounted:
            unmount = run_command(["umount", str(mount_dir)], check=False, timeout=60)
            if unmount.returncode != 0:
                raise WCSError(f"Falha ao desmontar system.img após a detecção: {(unmount.stderr or unmount.stdout).strip()[-500:]}")
        shutil.rmtree(mount_dir, ignore_errors=True)


def install(feature: str) -> dict[str, Any]:
    if feature not in SOURCES:
        raise WCSError(f"Tradutor ARM desconhecido: {feature}")
    info = inspect()
    require_stopped(info)
    android = _image_android_version(info)
    if android not in SOURCES[feature]:
        raise WCSError(
            f"{feature} não tem pacote upstream fixado e validado para esta imagem "
            f"(Android {info.get('android', 'UNKNOWN')}, API {info.get('sdk', 'UNKNOWN')}). "
            "As fontes herdadas do Waydroid Script disponíveis para este instalador são Android 11 e 13. "
            "Nenhum arquivo foi alterado."
        )
    host_arch = str(info.get("host_arch", "")).lower()
    guest_arch = str(info.get("arch", "")).lower()
    if host_arch not in {"x86_64", "amd64"} or guest_arch not in {"x86_64", "amd64"}:
        raise WCSError(f"Os tradutores ARM64→x86_64 exigem host e guest x86_64; detectado host={host_arch}, guest={guest_arch}.")
    if str(info.get("mount_overlays", "")).lower() != "true":
        raise WCSError("O instalador só modifica o overlay quando mount_overlays=True. Nenhuma imagem será montada ou sobrescrita.")

    overlay = Path(str(info.get("overlay_dir", "")))
    if not overlay.is_absolute() or overlay == Path("/"):
        raise WCSError("Diretório overlay inválido; instalação cancelada.")
    ensure_no_symlink_path(Path("/"), overlay.as_posix().lstrip("/"))
    if overlay.is_symlink():
        raise WCSError("O diretório overlay é um link simbólico; instalação cancelada.")
    overlay.mkdir(parents=True, exist_ok=True)
    system_root = overlay / "system"
    system_root.mkdir(parents=True, exist_ok=True)
    ensure_no_symlink_path(Path("/"), system_root.as_posix().lstrip("/"))

    config_path = Path(str(info.get("config_path", WAYDROID_CONFIG)))
    load_waydroid_config(config_path)  # Validate the config before downloading or writing payloads.
    archive = _download_source(feature, android)
    with tempfile.TemporaryDirectory(prefix="wcs-arm-translation-") as temp_name:
        stage = Path(temp_name)
        files, dirs = _extract_prebuilts(archive, feature, android, stage)
        if feature == "libhoudini":
            # Match the upstream installer: always generate houdini.rc after
            # extracting the pinned WSA payload, even if the archive already
            # carries a file at that path.
            init_relative = "etc/init/houdini.rc"
            init_path = stage / init_relative
            ensure_no_symlink_path(stage, "etc/init")
            init_path.parent.mkdir(parents=True, exist_ok=True)
            if init_path.is_symlink():
                init_path.unlink()
            elif init_path.exists() and not init_path.is_file():
                raise WCSError(f"O payload traz um destino inválido para {init_relative}.")
            init_path.write_text(LIBHOUDINI_INIT_RC, encoding="utf-8")
            files = sorted(set(files) | {init_relative})
            dirs = sorted(set(dirs) | {"etc", "etc/init"}, key=lambda value: (value.count("/"), value))

        # Switching providers first restores the original image/overlay state.
        if STATE_ROOT.exists() or STATE_ROOT.is_symlink():
            if STATE_ROOT.is_symlink() or not STATE_ROOT.is_dir():
                raise WCSError(f"Estado do tradutor é inseguro: {STATE_ROOT}")
            if not STATE_FILE.is_file() or STATE_FILE.is_symlink():
                raise WCSError("Há estado de tradutor órfão em /var/lib/wcs; restauração manual necessária.")
            previous = _restore_state()
            print(f"Tradutor WCS anterior restaurado: {previous}")

        _ensure_root_dir(STATE_ROOT)
        originals_dir = STATE_ROOT / "originals"
        originals_dir.mkdir(mode=0o700)

        # Snapshot only exact colliding paths. Existing image/base properties
        # are not used as a skip condition: the selected WCS payload overrides
        # the corresponding property and files through the Waydroid overlay.
        original_paths: dict[str, dict[str, Any]] = {}
        created_dirs: set[str] = set()
        required_dirs = set(dirs)
        for relative in files:
            parts = PurePosixPath(relative).parts
            for index in range(1, len(parts)):
                required_dirs.add(PurePosixPath(*parts[:index]).as_posix())
        replaced_ancestors: set[str] = set()
        for relative in sorted(required_dirs, key=lambda value: (value.count("/"), value)):
            if any(relative == ancestor or relative.startswith(ancestor + "/") for ancestor in replaced_ancestors):
                continue
            destination = _path_under(system_root, relative)
            if destination.exists() or destination.is_symlink():
                if destination.is_dir() and not destination.is_symlink():
                    continue
                snap = _snapshot_original(destination, originals_dir / relative)
                original_paths[relative] = {"path": relative, **snap}
                replaced_ancestors.add(relative)
                created_dirs.add(relative)
            else:
                created_dirs.add(relative)

        installed_files: list[dict[str, Any]] = []
        for relative in files:
            if any(relative.startswith(ancestor + "/") for ancestor in replaced_ancestors):
                # A preexisting non-directory ancestor was snapshotted as a whole.
                installed_files.append({"path": relative, "installed_kind": "pending"})
                continue
            destination = _path_under(system_root, relative)
            if destination.exists() or destination.is_symlink():
                if destination.is_dir() and not destination.is_symlink():
                    raise WCSError(f"O pacote tenta colocar um arquivo sobre um diretório existente: {destination}")
                snap = _snapshot_original(destination, originals_dir / relative)
                original_paths[relative] = {"path": relative, **snap}
            else:
                original_paths[relative] = {"path": relative, "kind": "missing"}
            installed_files.append({"path": relative, "installed_kind": "pending"})

        props = TRANSLATOR_PROPERTIES[feature]
        original_properties = _read_properties(config_path, list(props))
        bridge_key = "ro.dalvik.vm.native.bridge"
        original_waydroid_options = _read_section_values(config_path, "waydroid", [bridge_key])
        data_settings_path = Path(str(info.get("data_path", "")))
        if not data_settings_path.is_absolute() or not data_settings_path.is_dir():
            raise WCSError("Não foi possível resolver o data_path real do Waydroid para persistir Native Bridge.")
        # Validate the /data/misc destination before creating the transaction state.
        misc_dir = data_settings_path / "misc"
        if misc_dir.is_symlink() or (misc_dir.exists() and not misc_dir.is_dir()):
            raise WCSError(f"Diretório /data/misc inválido: {misc_dir}")
        settings_path = misc_dir / "waydroid_settings"
        if settings_path.is_symlink() or (settings_path.exists() and not settings_path.is_file()):
            raise WCSError(f"/data/misc/waydroid_settings inválido: {settings_path}")
        if settings_path.exists():
            settings_original = _snapshot_original(settings_path, originals_dir / "data/misc/waydroid_settings")
        else:
            settings_original = {"kind": "missing"}
        state = {
            "schema": 1,
            "manager": "wcs-arm-translation",
            "active": feature,
            "android": android,
            "overlay": str(overlay),
            "config_path": str(config_path),
            "original_properties": original_properties,
            "original_waydroid_options": original_waydroid_options,
            "installed_properties": props,
            "installed_waydroid_options": {bridge_key: props[bridge_key]},
            "refresh_waydroid_config": True,
            "waydroid_settings": {"path": str(settings_path), "original": settings_original},
            "settings_misc_created": not misc_dir.exists(),
            "originals": [item for item in original_paths.values() if item["kind"] != "missing"],
            "missing_paths": [path for path, item in original_paths.items() if item["kind"] == "missing"],
            "installed_files": installed_files,
            "created_dirs": sorted(created_dirs, key=lambda value: (value.count("/"), value)),
            "archive_md5": SOURCES[feature][android]["md5"],
            "status": "installing",
        }
        json_dump(STATE_FILE, state)

        try:
            # Remove only collisions that have already been snapshotted.
            for relative in sorted(original_paths, key=lambda value: value.count("/"), reverse=True):
                destination = _path_under(system_root, relative)
                _remove_path(destination)
            for relative in sorted(required_dirs, key=lambda value: (value.count("/"), value)):
                destination = _path_under(system_root, relative)
                if destination.exists() and not destination.is_dir():
                    raise WCSError(f"Não foi possível preparar diretório do tradutor: {destination}")
                destination.mkdir(parents=True, exist_ok=True)
                if not destination.is_symlink():
                    gid = 2000 if "bin" in PurePosixPath(relative).parts else 0
                    os.chown(destination, 0, gid)
                    os.chmod(destination, 0o755)

            stage_files = {path: stage.joinpath(*PurePosixPath(path).parts) for path in files}
            installed_state: list[dict[str, Any]] = []
            for relative in files:
                source = stage_files[relative]
                destination = _path_under(system_root, relative)
                if source.is_symlink():
                    os.symlink(os.readlink(source), destination)
                    installed_state.append({
                        "path": relative, "installed_kind": "symlink",
                        "installed_target": os.readlink(source),
                    })
                else:
                    shutil.copyfile(source, destination)
                    gid = 2000 if "bin" in PurePosixPath(relative).parts else 0
                    os.chown(destination, 0, gid)
                    os.chmod(destination, 0o755 if gid == 2000 else 0o644)
                    installed_state.append({
                        "path": relative, "installed_kind": "file",
                        "installed_sha256": _sha256_file(destination),
                    })

            _rewrite_config_section(config_path, "waydroid", {bridge_key: props[bridge_key]})
            _rewrite_properties(config_path, props)
            settings_state, misc_created, settings_hash = _prepare_waydroid_settings(
                data_settings_path, props[bridge_key], originals_dir
            )
            state["waydroid_settings"] = settings_state
            state["settings_misc_created"] = misc_created
            state["installed_settings_sha256"] = settings_hash
            state["installed_files"] = installed_state
            json_dump(STATE_FILE, state)
            run_command(["waydroid", "upgrade", "--offline"], timeout=900)
            state["status"] = "installed"
            json_dump(STATE_FILE, state)
        except Exception as exc:
            try:
                # Use the original snapshot even if the copy stopped halfway.
                partial = json.loads(STATE_FILE.read_text(encoding="utf-8"))
                partial["installed_files"] = [
                    {"path": path, "installed_kind": "pending"} for path in files
                ]
                json_dump(STATE_FILE, partial)
                _restore_state(verify_current=False)
            except Exception as restore_exc:
                raise WCSError(
                    f"Instalação de {feature} falhou: {exc}. A restauração automática também falhou: {restore_exc}. "
                    f"O backup foi preservado em {STATE_ROOT}."
                ) from exc
            if isinstance(exc, WCSError):
                raise
            raise WCSError(f"Instalação de {feature} falhou e o overlay/configuração foram restaurados: {exc}") from exc

    return {
        "feature": feature,
        "android": android,
        "source": "casualsnek/waydroid_script pinned archive",
        "archive_md5": SOURCES[feature][android]["md5"],
        "files_installed": len(files),
        "overlay": str(overlay),
        "active_native_bridge": props["ro.dalvik.vm.native.bridge"],
        "replaces_image_bridge_override": True,
        "note": "Somente este tradutor fica ativo. libndk e libhoudini são alternativas; instalar o outro troca o ativo e mantém backup para restauração.",
    }


def remove(feature: str) -> str:
    if feature not in SOURCES:
        raise WCSError(f"Tradutor ARM desconhecido: {feature}")
    info = inspect()
    require_stopped(info)
    if STATE_ROOT.is_symlink() or not STATE_ROOT.is_dir() or STATE_FILE.is_symlink() or not STATE_FILE.is_file():
        raise WCSError(f"Não há instalação WCS registrada de {feature} para remover.")
    try:
        state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception as exc:
        raise WCSError(f"Registro de tradução corrompido: {exc}") from exc
    if state.get("active") != feature:
        raise WCSError(f"O tradutor ativo gerenciado pelo WCS é {state.get('active')}, não {feature}.")
    removed = _restore_state()
    return f"{removed} removido; overlay e propriedades originais restaurados."


def status() -> dict[str, Any]:
    if not STATE_FILE.is_file() or STATE_FILE.is_symlink():
        return {"managed": False, "active": None}
    try:
        state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"managed": False, "active": None, "error": str(exc)}
    if state.get("schema") != 1 or state.get("manager") != "wcs-arm-translation":
        return {"managed": False, "active": None, "error": "unknown state schema"}
    return {
        "managed": True,
        "active": state.get("active"),
        "android": state.get("android"),
        "status": state.get("status"),
        "archive_md5": state.get("archive_md5"),
        "overlay": state.get("overlay"),
    }
