# SPDX-License-Identifier: GPL-3.0-or-later
"""Official Waydroid and WayDroid-ATV catalogs plus local image inspection."""
from __future__ import annotations

import re
from pathlib import Path

from .common import WCSError, ensure_no_symlink_path, fetch_json, human_size, load_waydroid_config, sha256_file
from .detection import inspect, require_stopped

RELEASES_API = "https://api.github.com/repos/WayDroid-ATV/waydroid-builds/releases?per_page=100"
OFFICIAL_SYSTEM_BASE = "https://ota.waydro.id/system"
OFFICIAL_VENDOR_BASE = "https://ota.waydro.id/vendor"
OFFICIAL_ROM_TYPES = ("lineage", "bliss")
OFFICIAL_SYSTEM_TYPES = ("VANILLA", "FOSS", "GAPPS")
OFFICIAL_ARCHES = ("x86_64", "x86", "arm64", "arm", "arm64_only")


def _host_waydroid_arch() -> str:
    import platform
    machine = platform.machine().lower()
    mapping = {
        "x86_64": "x86_64", "amd64": "x86_64", "i386": "x86", "i686": "x86",
        "aarch64": "arm64", "arm64": "arm64", "armv7l": "arm", "armv8l": "arm",
    }
    return mapping.get(machine, machine)


def official_image_catalog(
    *, arch: str = "host", rom_type: str = "all", system_type: str = "all",
) -> list[dict[str, object]]:
    """Discover images from the same OTA manifest layout used by upstream Waydroid.

    By default this queries the host ABI and all official ROM/system variants. Use
    arch='all' for the four published CPU families plus the ARM64-only channel.
    Nonexistent manifest combinations (HTTP 404) are skipped, not treated as failures.
    """
    arches = OFFICIAL_ARCHES if arch == "all" else ((_host_waydroid_arch() if arch == "host" else arch),)
    roms = OFFICIAL_ROM_TYPES if rom_type == "all" else (rom_type.lower(),)
    systems = OFFICIAL_SYSTEM_TYPES if system_type == "all" else (system_type.upper(),)
    invalid = set(roms) - set(OFFICIAL_ROM_TYPES)
    if invalid:
        raise WCSError("ROM oficial inválida: " + ", ".join(sorted(invalid)))
    invalid = set(systems) - set(OFFICIAL_SYSTEM_TYPES)
    if invalid:
        raise WCSError("Tipo de sistema oficial inválido: " + ", ".join(sorted(invalid)))
    invalid = set(arches) - set(OFFICIAL_ARCHES)
    if invalid:
        raise WCSError("Arquitetura Waydroid inválida: " + ", ".join(sorted(invalid)))

    items: list[dict[str, object]] = []
    for guest_arch in arches:
        if guest_arch not in OFFICIAL_ARCHES:
            continue
        for rom in roms:
            for variant in systems:
                url = f"{OFFICIAL_SYSTEM_BASE}/{rom}/waydroid_{guest_arch}/{variant}.json"
                try:
                    manifest = fetch_json(url)
                except WCSError as exc:
                    if "HTTP 404" in str(exc):
                        continue
                    raise
                entries = manifest.get("response") if isinstance(manifest, dict) else None
                if not isinstance(entries, list) or not entries:
                    continue
                builds = []
                for entry in entries:
                    if not isinstance(entry, dict):
                        continue
                    try:
                        timestamp = int(entry.get("datetime"))
                        size = int(entry.get("size") or 0)
                    except (TypeError, ValueError):
                        continue
                    digest = str(entry.get("id", "")).lower()
                    builds.append({
                        "datetime": timestamp,
                        "filename": str(entry.get("filename", "")),
                        "version": str(entry.get("version", "UNKNOWN")),
                        "sha256": digest if re.fullmatch(r"[0-9a-f]{64}", digest) else "UNPUBLISHED_OR_INVALID",
                        "size": size,
                        "size_human": human_size(size) if size > 0 else "UNKNOWN",
                        "url": str(entry.get("url", "")),
                    })
                builds.sort(key=lambda row: int(row["datetime"]), reverse=True)
                if builds:
                    latest = builds[0]
                    items.append({
                        "source": "OFFICIAL_WAYDROID_OTA",
                        "rom_type": rom,
                        "system_type": variant,
                        "arch": guest_arch,
                        "manifest": url,
                        "build_count": len(builds),
                        "latest": latest,
                        "builds": builds[:5],
                    })
    return items


def release_catalog(android: str = "all") -> list[dict[str, object]]:
    releases = fetch_json(RELEASES_API)
    items: list[dict[str, object]] = []
    for release in releases:
        title = release.get("name") or release.get("tag_name", "")
        label = str(title)
        version = "17" if re.search(r"Android\s*17", label, re.I) else "16" if re.search(r"Android\s*16", label, re.I) else "other"
        if android != "all" and version != android:
            continue
        assets = []
        for asset in release.get("assets", []):
            name = asset.get("name", "")
            if not (name.endswith("-system.zip") or name.endswith("-vendor.zip")):
                continue
            assets.append({
                "name": name,
                "url": asset.get("browser_download_url", ""),
                "size": int(asset.get("size") or 0),
                "size_human": human_size(int(asset.get("size") or 0)),
                "sha256": str(asset.get("digest") or "UNPUBLISHED"),
            })
        items.append({
            "tag": release.get("tag_name", ""),
            "name": title,
            "published_at": release.get("published_at", ""),
            "html_url": release.get("html_url", ""),
            "android": version,
            "prerelease": bool(release.get("prerelease")),
            "assets": assets,
        })
    return items



def inspect_ota_channels() -> list[dict[str, object]]:
    """Read the real system/vendor OTA manifests saved by `waydroid init`.

    The OTA response's `id` is the SHA-256 Waydroid itself uses to validate the ZIP.
    This function is strictly read-only: it neither downloads nor applies an image.
    """
    cfg = load_waydroid_config()
    way = cfg["waydroid"]
    channels = (
        ("system", way.get("system_ota", "").strip(), way.get("system_datetime", "0")),
        ("vendor", way.get("vendor_ota", "").strip(), way.get("vendor_datetime", "0")),
    )
    output: list[dict[str, object]] = []
    for component, url, installed_datetime in channels:
        try:
            installed_timestamp = int(installed_datetime or 0)
        except (TypeError, ValueError):
            installed_timestamp = 0
        if not url:
            output.append({"component": component, "status": "NO_CHANNEL_CONFIGURED", "url": ""})
            continue
        if url.strip().lower() in {"none", "null"}:
            output.append({"component": component, "status": "PREINSTALLED_OR_NO_OTA", "url": url})
            continue
        manifest = fetch_json(url)
        entries = manifest.get("response") if isinstance(manifest, dict) else None
        if not isinstance(entries, list):
            raise WCSError(f"Manifest OTA {component} não contém uma lista 'response': {url}")
        builds: list[dict[str, object]] = []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            try:
                timestamp = int(entry.get("datetime"))
            except (TypeError, ValueError):
                continue
            digest = str(entry.get("id", "")).lower()
            if len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest):
                digest_status = "INVALID_OR_MISSING_SHA256"
            else:
                digest_status = "SHA256_PUBLISHED"
            try:
                size = int(entry.get("size") or 0)
            except (TypeError, ValueError):
                size = 0
            filename = str(entry.get("filename", ""))
            download_url = str(entry.get("url", ""))
            builds.append({
                "datetime": timestamp,
                "filename": filename,
                "size": size,
                "size_human": human_size(size) if size > 0 else "UNKNOWN",
                "sha256": digest if digest_status == "SHA256_PUBLISHED" else "UNPUBLISHED_OR_INVALID",
                "integrity_metadata": digest_status,
                "url": download_url,
                "newer_than_installed": timestamp > installed_timestamp,
            })
        builds.sort(key=lambda item: int(item["datetime"]), reverse=True)
        output.append({
            "component": component,
            "status": "OK" if builds else "NO_BUILDS_PUBLISHED",
            "url": url,
            "installed_datetime": str(installed_datetime or "0"),
            "builds": builds,
        })
    return output

def verify_local_images() -> list[dict[str, object]]:
    info = inspect()
    require_stopped(info)
    root = Path(str(info["images_path"]))
    ensure_no_symlink_path(Path("/"), root.absolute().as_posix().lstrip("/"))
    results: list[dict[str, object]] = []
    for name in ("system.img", "vendor.img"):
        path = root / name
        if path.is_symlink():
            results.append({"name": name, "status": "SYMLINK_BLOCKED", "path": str(path)})
            continue
        if not path.is_file():
            results.append({"name": name, "status": "MISSING", "path": str(path)})
            continue
        size = path.stat().st_size
        if size <= 0:
            results.append({"name": name, "status": "INVALID_EMPTY", "path": str(path)})
            continue
        results.append({
            "name": name,
            "status": "PRESENT_HASHED",
            "path": str(path),
            "size": size,
            "size_human": human_size(size),
            "sha256": sha256_file(path),
        })
    return results
