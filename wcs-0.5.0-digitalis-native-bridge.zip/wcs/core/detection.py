# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only inspection of official, ATV and custom Waydroid installations."""
from __future__ import annotations

import os
import re
import shutil
from pathlib import Path

from .common import WAYDROID_CONFIG, WCSError, host_arch, load_waydroid_config, run_command, waydroid_root

PROP_KEYS = (
    "ro.build.version.release",
    "ro.build.version.sdk",
    "ro.build.version.security_patch",
    "ro.build.version.incremental",
    "ro.build.version.codename",
    "ro.product.cpu.abi",
    "ro.product.cpu.abilist",
    "ro.vendor.build.version.sdk",
    "ro.build.type",
    "ro.build.flavor",
    "ro.build.display.id",
    "ro.product.device",
    "ro.product.model",
    "ro.lineage.version",
)

SDK_TO_ANDROID = {
    26: "8.0", 27: "8.1", 28: "9", 29: "10", 30: "11",
    31: "12", 32: "12L", 33: "13", 34: "14", 35: "15",
    36: "16", 37: "17",
}
ACTIVE_STATES = {"RUNNING", "STARTING", "STOPPING", "FROZEN", "FREEZING", "ABORTING"}


def get_status() -> dict[str, str]:
    result = run_command(["waydroid", "status"], check=False, timeout=20)
    output = (result.stdout or "") + "\n" + (result.stderr or "")
    values: dict[str, str] = {"raw": output.strip(), "session": "UNKNOWN", "container": "UNKNOWN"}
    for line in output.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().lower().replace(" ", "_")
        if key in ("session", "container", "vendor_type", "ip_address"):
            values[key] = value.strip()
    if result.returncode != 0 and values["session"] == "UNKNOWN":
        values["error"] = f"waydroid status saiu com código {result.returncode}"
    return values


def _read_android_prop(name: str) -> str:
    result = run_command(["waydroid", "shell", "getprop", name], check=False, timeout=20)
    return result.stdout.strip() if result.returncode == 0 else ""


def get_lxc_status(root: Path) -> str:
    """Read the container state directly instead of relying only on Waydroid's status text."""
    if shutil.which("lxc-info") is None:
        return "UNKNOWN"
    result = run_command(
        ["lxc-info", "-P", str(root / "lxc"), "-n", "waydroid", "-sH"],
        check=False, timeout=10,
    )
    if result.returncode != 0:
        return "UNKNOWN"
    state = result.stdout.strip().upper()
    valid = ACTIVE_STATES | {"STOPPED"}
    return state if state in valid else "UNKNOWN"


def android_from_sdk(sdk: str | int | None) -> str:
    try:
        return SDK_TO_ANDROID.get(int(str(sdk).strip()), "UNKNOWN")
    except (TypeError, ValueError):
        return "UNKNOWN"


def infer_android_version(system_ota: str, system_datetime: str = "") -> str:
    """Infer only versions encoded in a known OTA channel; never guess from a date."""
    text = f"{system_ota} {system_datetime}".lower()
    match = re.search(r"(?:a|android[-_]?)(11|12|13|14|15|16|17)(?:[-_/]|$)", text)
    if match:
        return match.group(1)
    if "20261017" in text:
        return "17"
    if "20260717" in text or "20260302" in text:
        return "16"
    # WayDroid-ATV release channels encode Android generation in their names.
    match = re.search(r"a(16|17)-qpr\d+", text)
    if match:
        return match.group(1)
    return "UNKNOWN"


def parse_system_channel(url: str) -> dict[str, str]:
    """Extract the Waydroid OTA coordinates when the config uses official OTA URLs."""
    value = (url or "").strip()
    result = {"channel_kind": "CUSTOM_OR_PREINSTALLED", "rom_type": "UNKNOWN", "system_type": "UNKNOWN", "image_arch": "UNKNOWN"}
    if not value or value.lower() in {"none", "null"}:
        result["channel_kind"] = "PREINSTALLED_OR_NO_OTA"
        return result
    official = re.search(r"https?://ota\.waydro\.id/system/([^/]+)/waydroid_([^/]+)/([^/?]+)\.json", value, re.I)
    if official:
        result.update(channel_kind="OFFICIAL_WAYDROID", rom_type=official.group(1).lower(), image_arch=official.group(2).lower(), system_type=official.group(3).upper())
        return result
    atv = re.search(r"waydroid-atv\.github\.io/ota/(a16-qpr\d+|a17-qpr\d+)", value, re.I)
    if atv:
        result.update(channel_kind="WAYDROID_ATV", rom_type="lineage", system_type="UNKNOWN")
        return result
    return result


def normalize_waydroid_arch(value: str) -> str:
    arch = (value or "").strip().lower()
    return {
        "amd64": "x86_64", "x86_64": "x86_64", "i386": "x86", "i686": "x86",
        "x86": "x86", "aarch64": "arm64", "arm64": "arm64",
        "arm64-v8a": "arm64", "armv7l": "arm", "armv8l": "arm", "armeabi-v7a": "arm",
    }.get(arch, arch or "UNKNOWN")


def inspect() -> dict[str, object]:
    cfg = load_waydroid_config()
    way = cfg["waydroid"]
    root = waydroid_root()
    status = get_status()
    lxc_state = get_lxc_status(root)
    running = (
        status.get("session", "").upper() in ACTIVE_STATES
        or status.get("container", "").upper() in ACTIVE_STATES
        or lxc_state in ACTIVE_STATES
    )
    props: dict[str, str] = {}
    if running:
        for key in PROP_KEYS:
            value = _read_android_prop(key)
            if value:
                props[key] = value

    system_ota = way.get("system_ota", "")
    vendor_ota = way.get("vendor_ota", "")
    system_datetime = way.get("system_datetime", "")
    sdk = props.get("ro.build.version.sdk", "")
    android = android_from_sdk(sdk) if sdk else infer_android_version(system_ota, system_datetime)

    channel = parse_system_channel(system_ota)
    vendor_match = re.search(r"https?://ota\.waydro\.id/vendor/waydroid_([^/]+)/([^/?]+)\.json", vendor_ota or "", re.I)
    vendor_type = vendor_match.group(2).upper() if vendor_match else way.get("vendor_type", "UNKNOWN")
    vendor_arch = vendor_match.group(1).lower() if vendor_match else "UNKNOWN"
    configured_arch = normalize_waydroid_arch(way.get("arch", ""))
    property_arch = props.get("ro.product.cpu.abi", "")
    host_guest_arch = normalize_waydroid_arch(host_arch())
    guest_arch = property_arch or (configured_arch if configured_arch != "UNKNOWN" else host_guest_arch)
    abi_list = props.get("ro.product.cpu.abilist", "")

    images_path = Path(way.get("images_path", "/var/lib/waydroid/images")).expanduser()
    overlay_dir = root / "overlay"
    overlay_rw = root / "overlay_rw"
    data_path = Path(way.get("data_path", "")).expanduser() if way.get("data_path", "").strip() else None
    if data_path is None or not data_path.is_dir():
        try:
            import pwd
            username = os.environ.get("SUDO_USER")
            home = Path(pwd.getpwnam(username).pw_dir) if username else Path(os.environ.get("HOME", str(Path.home())))
        except (ImportError, KeyError):
            home = Path(os.environ.get("HOME", str(Path.home())))
        fallback = home / ".local/share/waydroid/data"
        data_path = fallback if fallback.is_dir() else root / "data"

    image_files = {
        "system": (images_path / "system.img").is_file(),
        "vendor": (images_path / "vendor.img").is_file(),
    }
    overlays_setting = way.get("mount_overlays", "True").strip().lower()
    return {
        "config_path": str(WAYDROID_CONFIG), "waydroid_root": str(root),
        "status": status, "lxc_state": lxc_state, "running": running,
        "android": android, "sdk": sdk or "UNKNOWN", "arch": guest_arch,
        "abi_list": abi_list or "UNKNOWN", "props": props,
        "system_ota": system_ota or "UNKNOWN", "vendor_ota": vendor_ota or "UNKNOWN",
        "system_datetime": system_datetime or "UNKNOWN", "vendor_datetime": way.get("vendor_datetime", "UNKNOWN"),
        **channel, "vendor_type": vendor_type, "vendor_arch": vendor_arch,
        "image_source": channel["channel_kind"],
        "images_path": str(images_path), "images": image_files,
        "overlay_dir": str(overlay_dir), "overlay_rw": str(overlay_rw),
        "mount_overlays": overlays_setting, "overlay_exists": overlay_dir.is_dir(),
        "data_path": str(data_path), "data_exists": data_path.is_dir(),
        "host_arch": host_arch(), "waydroid_bin": shutil.which("waydroid") or "NOT FOUND",
    }


def require_stopped(info: dict[str, object]) -> None:
    status = info.get("status", {})
    states = []
    if isinstance(status, dict):
        states = [str(status.get("session", "UNKNOWN")).upper(), str(status.get("container", "UNKNOWN")).upper()]
    states.append(str(info.get("lxc_state", "UNKNOWN")).upper())
    if bool(info.get("running")) or any(value in ACTIVE_STATES for value in states):
        raise WCSError("O contêiner Waydroid está ativo. Pare-o antes desta operação para evitar alterações em arquivos montados.")
    if not states or all(value == "UNKNOWN" for value in states):
        raise WCSError("Não foi possível confirmar que o Waydroid está parado; operação de escrita bloqueada por segurança.")


def require_supported_android(info: dict[str, object], *, minimum_api: int = 26, maximum_api: int = 37) -> str:
    """Accept all Waydroid image generations with an identifiable, supported Android API."""
    sdk = str(info.get("sdk", "UNKNOWN"))
    try:
        api = int(sdk)
    except (TypeError, ValueError):
        android = str(info.get("android", "UNKNOWN"))
        if android not in {"8.0", "8.1", "9", "10", "11", "12", "12L", "13", "14", "15", "16", "17"}:
            raise WCSError(
                f"Não foi possível identificar a versão Android desta imagem (API={sdk}, Android={android}). "
                "Inicie o Waydroid uma vez para o WCS ler as propriedades reais."
            )
        return android
    if not minimum_api <= api <= maximum_api:
        raise WCSError(
            f"API Android {api} fora da faixa suportada pelo WCS ({minimum_api}–{maximum_api}). "
            "Nenhuma alteração foi feita."
        )
    return SDK_TO_ANDROID.get(api, f"API {api}")


def require_android_16_or_17(info: dict[str, object]) -> str:
    """Backward-compatible guard retained for callers that still need ATV 16/17."""
    version = str(info.get("android", "UNKNOWN"))
    if version not in ("16", "17"):
        raise WCSError(f"Esta operação específica exige Android 16 ou 17 (detectado: {version}).")
    return version
