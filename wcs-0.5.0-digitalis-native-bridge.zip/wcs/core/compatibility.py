# SPDX-License-Identifier: GPL-3.0-or-later
"""Evidence-based compatibility status across official Waydroid Android generations."""
from __future__ import annotations

from typing import Any

ANDROID_API = {"11": 30, "12": 31, "12L": 32, "13": 33, "14": 34, "15": 35, "16": 36, "17": 37}

COMPONENTS = [
    {
        "name": "Official Waydroid image channels",
        "version": "ota.waydro.id",
        "status": "SUPPORTED_CHANNEL_SCHEMA",
        "note": "WCS lê canais oficiais LineageOS/Bliss e variantes VANILLA/FOSS/GAPPS; arquitetura e vendor type são resolvidos pelo waydroid init upstream.",
    },
    {
        "name": "Magisk WCS adapter",
        "version": "Magisk 31.0, binary patches pinned by SHA-256",
        "status": "EXPERIMENTAL_NOT_RUNTIME_VERIFIED",
        "note": "O adaptador aceita API 30–37 e ABIs com patch conhecido (x86, x86_64, armeabi-v7a, arm64-v8a). Isso não comprova boot, su ou Zygisk em cada imagem.",
    },
    {
        "name": "Magisk module manager",
        "version": "Native Magisk CLI and module markers",
        "status": "API_26_TO_37_IF_MAGISK_PRESENT",
        "note": "Opera sobre /data/adb e delega a instalação ao Magisk. A compatibilidade concreta também depende do próprio ZIP de módulo.",
    },
    {
        "name": "microG DresOS module",
        "version": "Upstream Android 8–16 (API 26–36)",
        "status": "UPSTREAM_API_DECLARED_NOT_WAYDROID_RUNTIME_VERIFIED",
        "note": "Exige VANILLA, Magisk e suporte à assinatura falsa fornecido pela ROM. API 37 permanece bloqueada pelo WCS até declaração upstream.",
    },
    {
        "name": "Zygisk integrado ao Magisk",
        "version": "via Magisk 31.0",
        "status": "NOT_RUNTIME_VERIFIED",
        "note": "O WCS exige prova de execução e não interpreta a opção da interface Magisk como prova de injeção.",
    },
    {
        "name": "Zygisk Next",
        "version": "1.5.3 (referência histórica do projeto)",
        "status": "UNVALIDATED",
        "note": "A compatibilidade deve ser conferida com a versão exata do Android/ROM e do módulo; WCS não instala automaticamente.",
    },
    {
        "name": "LSPosed / Vector",
        "version": "LSPosed 1.9.2; JingMatrix Vector 2.x",
        "status": "NOT_INSTALLED_OR_RUNTIME_VERIFIED_BY_WCS",
        "note": "O WCS não instala o framework automaticamente. Manager, daemon e injeção ART precisam ser diagnosticados separadamente.",
    },
    {
        "name": "KernelSU",
        "version": "fora do escopo do root de contêiner",
        "status": "NOT_IMPLEMENTED",
        "note": "Waydroid compartilha o kernel Linux do host; KernelSU não é um segundo root Android instalável dentro do contêiner como um módulo Magisk comum.",
    },
]


def report(android: str = "UNKNOWN") -> list[dict[str, Any]]:
    api = ANDROID_API.get(str(android))
    result: list[dict[str, Any]] = []
    for item in COMPONENTS:
        record = dict(item)
        record["android"] = android
        record["api"] = api if api is not None else "UNKNOWN"
        if api is not None and item["name"] == "microG DresOS module" and api > 36:
            record["status"] = "BLOCKED_API_37_UNDECLARED"
        if api is not None and item["name"] == "Magisk WCS adapter" and not 30 <= api <= 37:
            record["status"] = "OUTSIDE_ADAPTER_API_RANGE"
        result.append(record)
    return result
