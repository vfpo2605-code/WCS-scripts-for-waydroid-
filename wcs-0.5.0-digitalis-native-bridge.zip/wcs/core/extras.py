# SPDX-License-Identifier: GPL-3.0-or-later
"""Safe Waydroid extras: APK lifecycle and runtime capability inspection.

The original waydroid_script edits Android system/vendor images. WCS deliberately
keeps the first compatibility layer non-destructive: APKs are installed through
Waydroid's supported CLI, while image-level features are detected rather than
blindly overlaid onto arbitrary Waydroid Android image generations.
"""
from __future__ import annotations

import re
import stat
import zipfile
from pathlib import Path
from typing import Any

from .common import WCSError, run_command
from .detection import inspect
PACKAGE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)+$")
ANDROID_ID_RE = re.compile(r"^\d{1,20}$")
MAX_APK_SIZE = 512 * 1024 * 1024

# The official microG packages deliberately use the Google-compatible package
# namespace.  Their names therefore overlap with real GApps and are evidence
# only, not proof that microG is installed.  The org.microg.* names cover older
# and development builds without changing the legacy output field below.
MICROG_PACKAGE_HINTS = frozenset({
    "com.google.android.gms",
    "com.google.android.gsf",
    "org.microg.gms",
    "org.microg.gms.ui",
    "org.microg.gms.droidguard",
})
MICROG_UNAMBIGUOUS_HINTS = frozenset({
    "org.microg.gms",
    "org.microg.gms.ui",
    "org.microg.gms.droidguard",
})
WEBVIEW_PACKAGE_HINTS = frozenset({
    "com.android.webview",
    "com.google.android.webview",
    "com.android.chrome",
    "com.google.android.apps.chrome",
})

# This probe is intentionally read-only.  It collects command-level clues but
# never changes package state, permissions, SELinux policy, or Magisk modules.
# In particular, it cannot replace microG Settings > Self-Check, which is the
# authoritative test for signature spoofing according to the upstream module.
MICROG_PROBE = r"""
printf '%s\n' WCS_PROBE_BEGIN
_enabled="$(pm list packages -e 2>/dev/null || true)"
for _p in com.google.android.gms com.google.android.gsf org.microg.gms org.microg.gms.ui org.microg.gms.droidguard; do
    _path="$(pm path "$_p" 2>/dev/null || true)"
    if [ -n "$_path" ]; then
        printf 'WCS_PATH=%s\n' "$_p"
        case "$_path" in
            */priv-app/*) printf 'WCS_PRIV=%s\n' "$_p" ;;
        esac
    fi
    printf '%s\n' "$_enabled" | grep -Fxq "package:$_p" && printf 'WCS_ENABLED=%s\n' "$_p" || true
    dumpsys package "$_p" 2>/dev/null | grep -Eiq 'FAKE_PACKAGE_SIGNATURE.*granted=true' && printf 'WCS_SPOOF_INDICATOR=%s\n' "$_p" || true
done
for _f in /system/etc/permissions/*.xml /system_ext/etc/permissions/*.xml /product/etc/permissions/*.xml /vendor/etc/permissions/*.xml; do
    [ -f "$_f" ] || continue
    grep -Eiq 'com[.]google[.]android[.](gms|gsf)|org[.]microg' "$_f" 2>/dev/null && printf 'WCS_ALLOWLIST=%s\n' "$_f" || true
done
_webview_dump="$(dumpsys webviewupdate 2>/dev/null || true)"
if [ -n "$_webview_dump" ]; then
    printf '%s\n' WCS_WEBVIEW_QUERY_OK
    for _p in com.android.webview com.google.android.webview com.android.chrome com.google.android.apps.chrome; do
        printf '%s\n' "$_webview_dump" | grep -Fq "$_p" && printf 'WCS_WEBVIEW_CURRENT=%s\n' "$_p" || true
    done
fi
_custom_tabs="$(cmd package query-services -a android.support.customtabs.action.CustomTabsService 2>/dev/null || true)"
if cmd package query-services -a android.support.customtabs.action.CustomTabsService >/dev/null 2>&1; then
    printf '%s\n' WCS_CUSTOM_TABS_QUERY_OK
    printf '%s\n' "$_custom_tabs" | grep -Eiq 'com[.]|CustomTabsService' && printf '%s\n' WCS_CUSTOM_TABS_SERVICE || true
else
    printf '%s\n' WCS_CUSTOM_TABS_QUERY_UNKNOWN
fi
_db_found=0
for _db in /data/user/0/com.google.android.gsf/databases/gservices.db /data/data/com.google.android.gsf/databases/gservices.db; do
    if [ -f "$_db" ]; then
        printf '%s\n' WCS_GSERVICES_DB_PRESENT
        _db_found=1
        if command -v sqlite3 >/dev/null 2>&1; then
            _android_id="$(sqlite3 "$_db" "select value from main where name='android_id' limit 1;" 2>/dev/null | head -n 1 || true)"
            case "$_android_id" in
                ''|*[!0-9]*) printf '%s\n' WCS_ANDROID_ID_NOT_INITIALIZED ;;
                *) printf '%s\n' WCS_ANDROID_ID_PRESENT ;;
            esac
        else
            printf '%s\n' WCS_SQLITE3_MISSING
        fi
        break
    fi
done
[ "$_db_found" -eq 0 ] && printf '%s\n' WCS_GSERVICES_DB_NOT_FOUND || true
printf '%s\n' WCS_PROBE_END
exit 0
"""


_MARKER_LINE_RE = re.compile(r"^(WCS_[A-Z0-9_]+)(?:=(.*))?$")


def _probe_values(lines: list[str], marker: str) -> list[str]:
    values: set[str] = set()
    for line in lines:
        match = _MARKER_LINE_RE.fullmatch(line)
        if match and match.group(1) == marker and match.group(2) is not None:
            values.add(match.group(2))
    return sorted(values)


def _probe_has(lines: list[str], marker: str) -> bool:
    return any(line == marker for line in lines)


def parse_microg_probe(
    output: str, *, returncode: int = 0, error: str = ""
) -> dict[str, Any]:
    """Parse the marker-only output of the read-only Android microG probe.

    Package names, privileged paths, allowlists and permission-dump matches are
    deliberately reported as evidence, never as a claim that authentication or
    signature spoofing works.  ``microG Settings > Self-Check`` remains the
    authoritative runtime check.
    """
    lines = str(output or "").splitlines()
    complete = _probe_has(lines, "WCS_PROBE_BEGIN") and _probe_has(lines, "WCS_PROBE_END")
    if returncode:
        status = "PROBE_FAILED"
    elif not complete:
        status = "INCOMPLETE"
    else:
        status = "PROBED"

    package_paths = [value for value in _probe_values(lines, "WCS_PATH") if value in MICROG_PACKAGE_HINTS]
    enabled = [value for value in _probe_values(lines, "WCS_ENABLED") if value in MICROG_PACKAGE_HINTS]
    privileged = [value for value in _probe_values(lines, "WCS_PRIV") if value in MICROG_PACKAGE_HINTS]
    spoof_indicators = [value for value in _probe_values(lines, "WCS_SPOOF_INDICATOR") if value in MICROG_PACKAGE_HINTS]
    allowlist_files = sorted({
        value for value in _probe_values(lines, "WCS_ALLOWLIST")
        if value.startswith("/") and "\x00" not in value
    })
    webview_current = [value for value in _probe_values(lines, "WCS_WEBVIEW_CURRENT") if value in WEBVIEW_PACKAGE_HINTS]

    if _probe_has(lines, "WCS_GSERVICES_DB_PRESENT"):
        database = "PRESENT"
    elif _probe_has(lines, "WCS_GSERVICES_DB_NOT_FOUND"):
        database = "NOT_FOUND"
    else:
        database = "UNKNOWN"
    if _probe_has(lines, "WCS_ANDROID_ID_PRESENT"):
        android_id = "PRESENT"
    elif _probe_has(lines, "WCS_ANDROID_ID_NOT_INITIALIZED"):
        android_id = "NOT_INITIALIZED"
    elif _probe_has(lines, "WCS_SQLITE3_MISSING"):
        android_id = "SQLITE3_MISSING"
    else:
        android_id = "UNKNOWN"

    result: dict[str, Any] = {
        "status": status,
        "complete": complete and returncode == 0,
        "command_returncode": int(returncode),
        "packages": {
            "path_observed": package_paths,
            "enabled": enabled,
            "privileged_path_observed": privileged,
            "unambiguous_org_microg_hints": sorted(set(package_paths) & MICROG_UNAMBIGUOUS_HINTS),
            "note": "com.google.android.* também pode ser GApps; nomes de pacote são apenas pistas.",
        },
        "privileged_allowlist_files": allowlist_files,
        "signature_spoofing": {
            "status": "RUNTIME_REQUIRED",
            "advisory_indicators": spoof_indicators,
            "authoritative_check": "microG Settings > Self-Check: System spoofs signature",
            "note": "Um indicador em dumpsys/allowlist não prova que a verificação de assinatura ou o login funciona.",
        },
        "webview": {
            "query": "OK" if _probe_has(lines, "WCS_WEBVIEW_QUERY_OK") else "UNKNOWN",
            "current_packages": webview_current,
        },
        "custom_tabs": {
            "query": "OK" if _probe_has(lines, "WCS_CUSTOM_TABS_QUERY_OK") else "UNKNOWN",
            "service_observed": _probe_has(lines, "WCS_CUSTOM_TABS_SERVICE"),
        },
        "gservices": {
            "database": database,
            "android_id": android_id,
        },
        "authentication": {
            "status": "RUNTIME_REQUIRED",
            "note": "Registro do dispositivo, botão de login, sincronização e Play Store/Aurora exigem teste real; este probe não os executa.",
        },
        "note": "Diagnóstico somente leitura. A ausência de evidência pode ser limitação da imagem, permissões ou do comando disponível.",
    }
    if returncode or not complete:
        detail = str(error or "").strip()
        result["error"] = detail[-1200:] if detail else (
            f"waydroid shell terminou com código {returncode}" if returncode else "marcadores de início/fim ausentes"
        )
    return result


def _run_microg_probe() -> dict[str, Any]:
    result = run_command(
        ["waydroid", "shell", "--", "sh", "-c", MICROG_PROBE],
        check=False,
        timeout=60,
    )
    return parse_microg_probe(
        result.stdout or "",
        returncode=result.returncode,
        error=result.stderr or "",
    )


def _require_running() -> dict[str, Any]:
    info = inspect()
    if not info.get("running"):
        raise WCSError("Inicie o Waydroid antes de executar esta operação.")
    return info


def inspect_microg() -> dict[str, Any]:
    """Collect read-only microG/authentication evidence from the Android guest."""
    _require_running()
    return _run_microg_probe()


def validate_apk(path: Path) -> Path:
    path = Path(path).expanduser()
    try:
        st = path.lstat()
    except FileNotFoundError as exc:
        raise WCSError(f"APK não encontrado: {path}") from exc
    if not stat.S_ISREG(st.st_mode):
        raise WCSError("O APK precisa ser um arquivo regular, não um link simbólico ou diretório.")
    if st.st_size == 0 or st.st_size > MAX_APK_SIZE:
        raise WCSError(f"Tamanho de APK inválido (limite: {MAX_APK_SIZE // (1024 * 1024)} MiB).")
    try:
        with zipfile.ZipFile(path) as archive:
            names = set(archive.namelist())
            if "AndroidManifest.xml" not in names:
                raise WCSError("O ZIP não contém AndroidManifest.xml; não parece ser um APK válido.")
            if archive.testzip() is not None:
                raise WCSError("O APK está corrompido (falha na verificação CRC).")
    except zipfile.BadZipFile as exc:
        raise WCSError("O arquivo não é um APK/ZIP válido.") from exc
    return path.resolve(strict=True)


def install_apk(path: Path) -> dict[str, Any]:
    _require_running()
    apk = validate_apk(path)
    result = run_command(["waydroid", "app", "install", str(apk)], check=False, timeout=600)
    if result.returncode:
        detail = (result.stderr or result.stdout or "sem detalhes").strip()[-2500:]
        raise WCSError(f"Waydroid não conseguiu instalar o APK.\n{detail}")
    return {"path": str(apk), "output": (result.stdout or "").strip()[-2500:]}


def validate_package_name(package: str) -> str:
    if not PACKAGE_RE.fullmatch(package):
        raise WCSError(f"Nome de pacote Android inválido: {package!r}")
    return package


def remove_app(package: str) -> str:
    _require_running()
    package = validate_package_name(package)
    result = run_command(["waydroid", "app", "remove", package], check=False, timeout=180)
    if result.returncode:
        detail = (result.stderr or result.stdout or "sem detalhes").strip()[-2000:]
        raise WCSError(f"Waydroid não conseguiu remover {package}.\n{detail}")
    return (result.stdout or "").strip()


def list_apps() -> list[str]:
    _require_running()
    result = run_command(["waydroid", "app", "list"], check=False, timeout=60)
    if result.returncode:
        raise WCSError(f"Não foi possível listar aplicativos: {(result.stderr or result.stdout)[-2000:]}")
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def get_android_id() -> str:
    _require_running()
    # The two paths cover Android's user-0 and legacy package-data layouts.
    shell_script = (
        "for db in /data/user/0/com.google.android.gsf/databases/gservices.db "
        "/data/data/com.google.android.gsf/databases/gservices.db; do "
        "if [ -f \"$db\" ]; then "
        "sqlite3 \"$db\" \"select value from main where name='android_id' limit 1;\" "
        "&& exit 0; fi; done; exit 4"
    )
    result = run_command(["waydroid", "shell", "--", "sh", "-c", shell_script], check=False, timeout=45)
    if result.returncode:
        detail = (result.stderr or result.stdout or "sem detalhes").strip()[-1500:]
        raise WCSError(
            "Não foi possível ler o Android ID. Confirme que o Google Services Framework "
            "está instalado e inicializado e que sqlite3 está disponível na imagem.\n" + detail
        )
    values = [line.strip() for line in result.stdout.splitlines() if ANDROID_ID_RE.fullmatch(line.strip())]
    if not values:
        raise WCSError("A consulta terminou, mas não retornou um Android ID numérico válido.")
    return values[-1]


def _shell_value(command: str) -> str:
    result = run_command(["waydroid", "shell", "--", "sh", "-c", command], check=False, timeout=30)
    return result.stdout.strip() if result.returncode == 0 else ""


def inspect_extras() -> dict[str, Any]:
    info = _require_running()
    packages = _shell_value("pm list packages")
    package_set = set(re.findall(r"^package:([^\s]+)$", packages, re.MULTILINE))
    bridge = _shell_value("getprop ro.dalvik.vm.native.bridge")
    widevine = _shell_value(
        "for f in /system/lib*/libwvdrmengine.so /vendor/lib*/libwvdrmengine.so "
        "/system/lib*/libwvdrmengine.so /apex/*/lib*/libwvdrmengine.so; do "
        "[ -f \"$f\" ] && echo \"$f\"; done"
    )
    microg_diagnostics = _run_microg_probe()
    return {
        "android": info.get("android", "UNKNOWN"),
        "abi": info.get("arch", "UNKNOWN"),
        "google_services_framework": "com.google.android.gsf" in package_set,
        "google_play_services": "com.google.android.gms" in package_set,
        "google_play_store": "com.android.vending" in package_set,
        "microg_related_packages": sorted(
            package for package in package_set
            if package.startswith("org.microg.") or package == "org.microg.gms.droidguard"
        ),
        "microg_diagnostics": microg_diagnostics,
        "native_bridge_property": bridge or "(vazia)",
        "widevine_library_paths": [line for line in widevine.splitlines() if line.startswith("/")],
        "note": "Detecção por runtime; presença de pacote/biblioteca não garante funcionamento ou certificação.",
    }
