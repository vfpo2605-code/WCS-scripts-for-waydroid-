# Magisk integration

The host-side Magisk adapter is implemented in `core/root_manager.py`. This directory is reserved for future WCS-owned Android-side setup assets. No prebuilt APK or binary is bundled here.
