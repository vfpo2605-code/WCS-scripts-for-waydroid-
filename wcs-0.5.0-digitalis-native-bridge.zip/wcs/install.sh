#!/usr/bin/env bash
set -euo pipefail

SRC="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PREFIX="${PREFIX:-/usr/local}"
DEST="$PREFIX/lib/wcs"

if [[ $EUID -ne 0 ]]; then
  echo "Execute com sudo: sudo bash install.sh" >&2
  exit 1
fi
if [[ "$PREFIX" != /* || "$PREFIX" == *"/../"* || "$PREFIX" == */.. ]]; then
  echo "PREFIX deve ser um caminho absoluto sem componentes '..'." >&2
  exit 1
fi

check_no_symlink_components() {
  local path="$1" current="/" part
  local -a parts=()
  IFS='/' read -r -a parts <<< "${path#/}"
  for part in "${parts[@]}"; do
    [[ -n "$part" ]] || continue
    current="${current%/}/$part"
    if [[ -L "$current" ]]; then
      echo "Caminho de instalação contém link simbólico: $current" >&2
      exit 1
    fi
  done
}

for path in "$PREFIX" "$PREFIX/lib" "$DEST" "$PREFIX/bin"; do
  check_no_symlink_components "$path"
done
for path in "$PREFIX" "$PREFIX/lib" "$PREFIX/bin"; do
  if [[ -e "$path" && ! -d "$path" ]]; then
    echo "O destino existe e não é diretório: $path" >&2
    exit 1
  fi
done
if [[ -e "$PREFIX/bin/wcs" || -L "$PREFIX/bin/wcs" ]]; then
  if [[ ! -L "$PREFIX/bin/wcs" || "$(readlink -- "$PREFIX/bin/wcs")" != "$DEST/wcs" ]]; then
    echo "Não vou substituir um arquivo/comando preexistente em $PREFIX/bin/wcs." >&2
    exit 1
  fi
fi

if [[ -L "$DEST/wcs" ]]; then
  echo "O executável de destino é um link simbólico; instalação bloqueada: $DEST/wcs" >&2
  exit 1
fi
install -d -m 0755 "$DEST"
rm -rf -- "$DEST/core" "$DEST/config" "$DEST/docs" "$DEST/tests" "$DEST/root" "$DEST/modules" "$DEST/utils"
cp -a "$SRC/core" "$SRC/config" "$SRC/docs" "$SRC/tests" "$SRC/root" "$SRC/modules" "$SRC/utils" "$DEST/"
install -m 0644 "$SRC/README.md" "$SRC/LICENSE" "$SRC/THIRD_PARTY_NOTICES.md" "$SRC/CHANGELOG.md" "$DEST/"
install -m 0755 "$SRC/wcs" "$DEST/wcs"
install -m 0755 "$SRC/uninstall.sh" "$DEST/uninstall.sh"
install -d -m 0755 "$PREFIX/bin"
ln -sfn "$DEST/wcs" "$PREFIX/bin/wcs"

echo "WCS instalado em $DEST"
echo "Execute: wcs --help"
