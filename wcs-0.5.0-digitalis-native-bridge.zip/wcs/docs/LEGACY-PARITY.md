# Reconstrução dos recursos do Waydroid Script

## Catálogo WCS 0.5.0

O menu interativo e os comandos `wcs features`, `wcs install <componente>` e `wcs remove <componente>` preservam os nomes dos onze recursos encontrados no `casualsnek/waydroid_script`:

| Componente original | Implementação WCS 0.5.0 | Limite atual |
|---|---|---|
| GApps / OpenGApps / MindTheGapps | Troca para as imagens oficiais `GAPPS`, `VANILLA` ou `FOSS`, em `lineage` ou `bliss` | Depende da existência de manifesto para a arquitetura/variante pedida; backup não inclui `/data` |
| microG / Aurora | Módulo Magisk systemless DresOS, baixado pela API de releases e validado por SHA-256 | API 26–36, VANILLA, Magisk e ROM com signature spoofing; login Google precisa ser verificado no Android real |
| libndk | Instalador overlay com pacotes upstream fixados para Android 11/13 x86_64 | Não habilitado para Android 16/17 sem payload da mesma geração; exclusivo com libhoudini |
| libhoudini | Instalador overlay com pacotes WSA upstream fixados para Android 11/13 x86_64 e `houdini.rc` gerado | Não habilitado para Android 16/17 sem payload da mesma geração; exclusivo com libndk |
| Magisk | Adaptador WCS baseado em Magisk 31.0 | API 30–37; patches fixados por hash e ABI; experimental |
| Widevine L3 | Detecção de arquivos e bibliotecas | Sem instalador universal verificado para todos os canais/ABIs |
| Smart Dock | APK atual obtido do F-Droid e instalado como app normal | Não força permissões privilegiadas |
| F-Droid Privileged Extension | ZIP oficial convertido em módulo Magisk | Experimental, requer boot e teste de instalação privilegiada |
| Certificado CA MITM | Módulo Magisk para a trust store Conscrypt APEX | Experimental, requer confirmação pós-boot |
| nodataperm | Recurso listado | Bloqueado; patch de `services.jar` depende de frameworks específicos |
| hidestatusbar | Recurso listado | Bloqueado; overlay antigo sem matriz atual de compatibilidade |
| Digitalis/Berberis | Novo provider experimental integrado a partir do bundle Refract para WayDroid-ATV LineageOS 23.2 / Android 16 QPR2 | 74 artefatos verificados; estritamente QPR2/host+guest x86_64; não é baseado nem combinado a libndk/Houdini |
| Android ID / certificação | `wcs certified` | Requer GSF e banco acessíveis |

## Native Bridge adicional Digitalis/Berberis

O WCS 0.5.0 acrescenta `digitalis` como um provider separado. Ele não tenta fundir os binários proprietários libndk e Houdini: ART seleciona um único Native Bridge por `ro.dalvik.vm.native.bridge`. Digitalis é baseado no backend Berberis do AOSP e usa um bundle precompilado da Refract, preparado para Android 16 QPR2. WCS baixa esse bundle no momento da instalação, valida manifesto e SHA-256, salva os arquivos de overlay e os valores em `[waydroid]`, `[properties]` e `/data/misc/waydroid_settings`. A remoção ou troca restaura o estado anterior. Android 17 e imagens que não comprovam o mesmo QPR2 são bloqueados.

## Imagens oficiais Waydroid

O WCS 0.5.0 não está limitado ao WayDroid-ATV. Ele reconhece o layout OTA oficial para `lineage` e `bliss`, tipos `VANILLA`, `FOSS` e `GAPPS`, além de arquiteturas `x86_64`, `x86`, `arm64`, `arm` e o alvo especial `arm64_only` quando publicado. O catálogo consulta os manifestos reais e não apresenta uma combinação inexistente como disponível.

A troca automática de imagem chama o inicializador do próprio Waydroid com `--system_channel`, `--vendor_channel`, `--rom_type`, `--system_type` e o `--images_path` configurado. Waydroid seleciona a arquitetura do host e o vendor adequado, valida os hashes dos ZIPs do OTA e extrai o par. Releases WayDroid-ATV permanecem em catálogo separado.

Comandos:

```bash
# Catálogo da arquitetura atual
wcs images catalog

# Todos os alvos publicados
wcs images catalog --arch all --rom all --type all

# Filtrar um alvo específico
wcs images catalog --arch x86_64 --rom lineage --type GAPPS

# Troca oficial; cria backup de system.img e vendor.img
sudo wcs images switch --rom lineage --type VANILLA
sudo wcs images switch --rom bliss --type FOSS --yes

# Releases customizadas WayDroid-ATV
wcs images atv-catalog --android all
```

A troca não é executada se o diretório em uso for uma das pastas oficiais de imagens pré-instaladas (`/etc/waydroid-extra/images` ou `/usr/share/waydroid-extra/images`), porque Waydroid dá prioridade a esse conteúdo e ignora os canais OTA. Também é bloqueada se a integração Magisk do WCS estiver instalada, pois a inicialização forçada limpa a camada writable de overlay.

## Por que nem todos os módulos antigos foram transplantados

O projeto original modificava diretamente a partição de sistema e possuía payloads explícitos para Android 11/13. O WCS adapta esses dois payloads ao overlay do Waydroid, com hashes fixados, validação da árvore de arquivos, backup dos caminhos sobrepostos e restauração antes de remover ou trocar o tradutor. As imagens Android 14–17 não recebem esses pacotes antigos: o WCS exige um payload correspondente à geração detectada e aborta antes de escrever se ele não existir. A presença de uma Native Bridge na imagem não impede a instalação de um dos dois payloads compatíveis, mas apenas um provedor pode ficar ativo por vez.

## Limites conhecidos

- O módulo microG incluído declara Android 8–16 (API 26–36). O WCS bloqueia API 37 enquanto o próprio módulo não declarar suporte. O login Google não é considerado corrigido só pela versão do GmsCore: confira a assinatura falsa e o Self-Check no Android.
- F-Droid Privileged e o módulo CA são experimentais; a criação do ZIP não comprova que o módulo sobreviva ao boot.
- Detectar Native Bridge ou Widevine não comprova que aplicativos ARM ou DRM estejam funcionais.
- `nodataperm` e `hidestatusbar` permanecem bloqueados para todas as imagens sem port específico validado.
- Zygisk, Zygisk Next, LSPosed e Vector não são instalados automaticamente; presença do módulo não comprova injeção no Zygote/ART.

## Princípios

1. Consultar canais/manifestos reais e preferir o inicializador oficial do Waydroid.
2. Não inventar uma combinação de imagem se o manifesto OTA não existe.
3. Detectar SDK, ABI, ROM, tipo de sistema e origem da imagem antes de alterar arquivos.
4. Fazer backup e confirmar operações que substituem imagens.
5. Não remover `/data` automaticamente.
6. Separar testes automatizados host de validação real de boot/runtime.
