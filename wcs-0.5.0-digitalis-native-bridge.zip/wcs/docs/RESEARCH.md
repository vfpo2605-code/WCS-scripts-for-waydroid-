# Research notes and engineering decisions

Research snapshot: 2026-11-12.

## WayDroid-ATV image releases

The official `WayDroid-ATV/waydroid-builds` release page currently lists:

- `20261017`: LineageOS 24.0, Android 17 QPR0.
- `20260717`: LineageOS 23.2, Android 16 QPR2.
- `20260302`: LineageOS 23.2, Android 16 QPR2.

Source: https://github.com/WayDroid-ATV/waydroid-builds/releases

The WCS catalog reads the GitHub Releases API at runtime. It does not hardcode image ZIP filenames,
asset URLs, or a guessed checksum. If GitHub publishes an asset digest, WCS displays it. A missing
`digest` is reported as `UNPUBLISHED`, not silently treated as verified.

The Android 17 `20261017` release notes state that ARM64 images are not available for that release.
The same release notes mention fixes for Magisk/KernelSU and keystore-hooking compatibility. This
is image-level evidence only; it does not prove the WCS root adapter or every root module works.

## Waydroid OTA configuration

Waydroid's official initializer builds system and vendor OTA manifest URLs from the configured
channel, ROM type, ABI, system type, and vendor codename/vendor type. The WCS therefore reads the
actual `system_ota` and `vendor_ota` values from `waydroid.cfg`, queries those manifests, and reports
the published build date, filename, size and SHA-256 rather than constructing a URL from an assumed
filename. Android 16/17 channel identifiers are used only for inference when they are present in
that real config. The v0.1.x command is read-only and does not download or apply updates.

The WayDroid-ATV release instructions use the channel endpoints with `/system` and `/vendor`
paths. The top-level channel URL supplied in a project brief is not itself a downloadable image.

## Old Waydroid Script

The repository `casualsnek/waydroid_script` is still publicly accessible; it must not be described
as deleted merely because WaydroidSU is unavailable. Its Magisk integration identifies itself as
Magisk Delta, extracts libraries from an APK, places them under `/system/etc/init/magisk`, and
modifies `/system/etc/init/bootanim.rc` to start Magisk during Android init. Its generic installer
uses the Waydroid overlay when overlay mounting is enabled and a temporary image tree otherwise.

The WCS adapter is based on the overlay path only. It refuses to run when the effective Waydroid
`mount_overlays` value is false, and it refuses to patch a non-matching Magisk binary. Upstream
Waydroid's current config default is `True` when the key is omitted.

Source files inspected:

- https://github.com/casualsnek/waydroid_script/blob/main/stuff/magisk.py
- https://github.com/casualsnek/waydroid_script/blob/main/stuff/general.py
- https://github.com/casualsnek/waydroid_script/blob/main/tools/images.py
- https://github.com/casualsnek/waydroid_script/blob/main/tools/container.py

## WaydroidSU

Several public repositories/forks named `WaydroidSU` were found, but this research pass could not
establish which one is the canonical original or verify provenance against the discontinued
service described in the project brief. WCS therefore does not copy code from those similarly
named forks. The related `nitanmarcel/waydroid-magisk` project is an archived Kitsune Mask manager;
its own README describes Canary-only behavior for Magisk modules and Zygisk. It is not treated as
an up-to-date specification for current official Magisk.

## Magisk

The Magisk releases page lists v31.1 as the latest release at the research date. v31.1 changes
superuser authorization and removes the old prompt/stub behavior. The WCS overlay adapter pins
v31.0 because the Waydroid binary-patch offsets it uses are tied to the exact v31.0 APK and SHA-256.
WCS does not substitute v31.1 or any future release into that patch set.

Official release notes: https://github.com/topjohnwu/Magisk/releases
Official Magisk tools reference: https://topjohnwu.github.io/Magisk/tools

## Android 16/17 and components

- Magisk v31.0 release notes explicitly include Zygisk support for Android 17 API 37.
- Zygisk Next v1.5.3 explicitly lists Android 17 QPR3 support and 16 KB page-size fixes. Its
  repository was archived on 2026-11-08. These facts do not prove Android 17 QPR0 compatibility.
- LSPosed v1.9.2 is the latest release shown by its upstream release page; its changelog contains
  fixes for Android 14. There is no basis in that release note to label it compatible with Android
  16 or Android 17.
- KernelSU depends on kernel-level integration. Waydroid shares the Linux kernel of its host, so
  WCS does not pretend a Magisk-style container module can install KernelSU in the guest.

## Root adaptation design

The v0.1.1 adapter is limited to:

- Official Magisk v31.0, downloaded from the official release URL and checked against a fixed SHA-256.
- 64-bit guest ABIs for which the exact adaptation patch set is available: x86_64 and arm64-v8a.
- Android 16 API 36 and Android 17 API 37, inferred from running properties or the actual OTA URL.
- Waydroid's writable overlay, with `mount_overlays=True` confirmed in configuration.

It does not patch `boot.img`. It extracts the pinned Magisk libraries and init scripts, applies the
known byte patches only when the original bytes match, preserves the prior `bootanim.rc`, and adds
init triggers. It creates a baseline snapshot before modifying the overlay and rolls back if any
commit step fails. In an untouched Waydroid overlay, `bootanim.rc` commonly is not present because
the overlay directory is only an additional lower layer, not a complete copy of the system image.
WCS 0.1.1 therefore reads the stock file from the configured `system.img` with a temporary
read-only loop mount, then creates the corresponding override in the overlay. It stops both the
Waydroid session and container and waits for LXC shutdown before writes. The safety gate checks `lxc-info` directly as well as `waydroid status`, so a stale session status cannot authorize an image write.

No Magisk APK is bundled in the source tree. No root component is marked operational merely because files were installed. Runtime verification requires an ADB-visible Waydroid device whose ADB shell is not already UID 0; only then can WCS test the Magisk daemon and `su` escalation independently.

## microG DresOS e autenticação

The upstream DresOS microG module README says that the module installs privileged official microG components (GmsCore, Companion and GsfProxy) and regenerates privileged-permission allowlists. Its Google-compatible package names overlap with GApps, so package presence is not an identity or authentication proof. The README also states that the module does not contain Zygisk/Xposed signature-spoofing payloads and requires ROM/framework-level signature spoofing.

WCS therefore treats `wcs microg` as a read-only evidence collector. It records package paths, enabled/privileged hints, allowlist files, an advisory `FAKE_PACKAGE_SIGNATURE` dump indicator, WebView/Custom Tabs queries and GServices database/Android-ID readiness. The authoritative signature test remains microG Settings → Self-Check, especially “System spoofs signature”; device registration, Google login, synchronization and Play Store/Aurora still require a real boot and are never inferred from a module ZIP.

Primary source inspected: https://github.com/The-DresOS-Foundation/DresOS-Magisk-Modules/tree/main/microg

## Canais oficiais Waydroid (WCS 0.4.0)

A partir de 0.4.0, o WCS separa os canais OTA oficiais da coleção adicional WayDroid-ATV. A documentação atual do Waydroid lista `lineage` e `bliss` como ROM types e `VANILLA`, `FOSS`, `GAPPS` como system types. O inicializador recebe as bases de system/vendor OTA, tipo de ROM, tipo de sistema e caminho de imagens. O inicializador oficial deriva a arquitetura do host, resolve o tipo de vendor e baixa os ZIPs correspondentes aos manifestos.

O WCS consulta os caminhos de manifesto no padrão `system/<rom>/waydroid_<arch>/<system_type>.json`. A lista de arquiteturas também inclui `arm64_only`, que é um alvo especial de compilação documentado upstream; ele só aparece como imagem disponível se existir manifesto. Combinações sem manifesto (404) são ignoradas pelo catálogo.

O código upstream do inicializador chama o método de obtenção de imagens durante `waydroid init`; esse método consulta manifestos, compara datas, baixa ZIPs, verifica SHA-256 e extrai system/vendor. Portanto, WCS não chama `waydroid upgrade` depois de `waydroid init -f`, evitando uma segunda atualização redundante.

O inicializador upstream também reconhece diretórios pré-instalados em `/etc/waydroid-extra/images` e `/usr/share/waydroid-extra/images`. Se os dois arquivos já existem ali, marca os canais OTA como `None` e usa aquelas imagens. WCS reporta essa origem como pré-instalada e bloqueia a troca OTA automática para evitar que a escolha pedida seja ignorada silenciosamente.

Fontes primárias:

- https://github.com/waydroid/docs/blob/master/usage/waydroid-command-line-options.md
- https://github.com/waydroid/docs/blob/master/faq/using-custom-waydroid-images.md
- https://github.com/waydroid/waydroid/blob/main/tools/actions/initializer.py
- https://github.com/waydroid/waydroid/blob/main/tools/helpers/images.py
- https://github.com/waydroid/docs/blob/master/development/compile-waydroid-lineage-os-based-images.md
