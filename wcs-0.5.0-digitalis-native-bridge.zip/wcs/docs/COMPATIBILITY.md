# Matriz de compatibilidade WCS 0.5.0

## Imagens oficiais Waydroid

| Dimensão | Cobertura do WCS | Evidência / limite |
|---|---|---|
| ROM LineageOS | Suporte ao formato de canal OTA | `lineage` é reconhecido pelo inicializador oficial |
| ROM Bliss | Suporte ao formato de canal OTA | `bliss` é reconhecido pelo inicializador oficial; manifestos ausentes são omitidos do catálogo |
| VANILLA | Catálogo e seleção por `waydroid init` | Manifesto real consultado antes da seleção |
| FOSS | Catálogo e seleção por `waydroid init` | Só aparece para combinações publicadas |
| GAPPS | Catálogo e seleção por `waydroid init` | Só aparece para combinações publicadas |
| x86_64 / x86 / arm64 / arm | Catálogo e identificação | A seleção automática usa a arquitetura resolvida pelo Waydroid no host |
| arm64_only | Catálogo, quando publicado | Alvo especial de build; não é forçado no inicializador host |
| Imagens pré-instaladas/customizadas | Detecção, inspeção local, hash e backup | Canais `None`/ausentes são identificados; seleção OTA automática bloqueada para diretórios preinstalled padrão |
| WayDroid-ATV | Catálogo separado | Nunca é confundido com o OTA oficial do Waydroid |

O catálogo consulta os manifestos que seguem o layout upstream:
`<system OTA>/<rom>/waydroid_<arch>/<VANILLA|FOSS|GAPPS>.json`.

O inicializador upstream recebe system/vendor OTA base, ROM, tipo de sistema e `images_path`; resolve a arquitetura do host e procura o vendor/codename compatível. A troca de imagem é feita pelo próprio `waydroid init -f`, que baixa e valida os ZIPs pelo SHA-256 registrado nos manifestos. WCS não baixa um ZIP de imagem sem passar pela validação oficial.

## Android detectável

| Android | API | Detecção do WCS |
|---|---:|---|
| 8.0 | 26 | Mapeada |
| 8.1 | 27 | Mapeada |
| 9 | 28 | Mapeada |
| 10 | 29 | Mapeada |
| 11 | 30 | Mapeada |
| 12 | 31 | Mapeada |
| 12L | 32 | Mapeada |
| 13 | 33 | Mapeada |
| 14 | 34 | Mapeada |
| 15 | 35 | Mapeada |
| 16 | 36 | Mapeada |
| 17 | 37 | Mapeada |

A versão é obtida do `ro.build.version.sdk` quando o Android está ativo. Um canal OTA oficial pode identificar ROM, tipo e ABI, mas não necessariamente a versão Android enquanto o contêiner está parado; nesses casos o WCS não inventa uma versão.

## Recursos e restrições

| Componente | Faixa/estado | O que o WCS realmente garante |
|---|---|---|
| Detecção de imagem | SDK 26–37 | Mapeamento API, canal, ROM, tipo, imagem e arquitetura |
| Catálogo de OTA | Manifestos consultados ao vivo | Lista somente combinações que retornam manifestos válidos |
| Troca oficial de imagem | `lineage`/`bliss`, `VANILLA`/`FOSS`/`GAPPS` | Faz backup da dupla system/vendor, confere pré-condições e delega download/verificação ao Waydroid |
| Backup/restauração de imagens | system.img + vendor.img | SHA-256 local e substituição validada; `/data` excluído |
| Adaptador Magisk WCS 31.0 | API 30–37; x86_64, x86, arm64-v8a, armeabi-v7a conforme patch | Experimental; patches aplicados apenas se bytes esperados coincidirem; boot/root ainda não provados por imagem |
| Gerenciador de módulos Magisk | API 26–37, com Magisk ativo | Delega instalação ao CLI Magisk e gerencia marcadores de módulo; não certifica módulos de terceiros |
| microG DresOS | API 26–36, VANILLA, Magisk | Versão/API upstream verificada e GApps bloqueado; `wcs microg` coleta evidências somente leitura, mas login, signature spoofing e Android real não são certificados pelo teste host |
| Smart Dock | API 26–37 | APK normal instalado via `waydroid app`; comportamento visual em cada imagem não testado |
| F-Droid Privileged | Experimental, depende de Magisk | ZIP gerado e validado estruturalmente; permissões privilegiadas precisam de boot real |
| Certificado CA | Experimental, depende de Conscrypt APEX e Magisk | Módulo systemless gerado; confiança após boot ainda precisa de teste |
| libndk / libhoudini | Instalável pelo WCS em Android 11/13, host+guest x86_64 e overlay ativo | Pacotes upstream com hash fixado; só um Native Bridge ativo; Android fora das gerações 11/13 (incluindo 14–17) bloqueado por ausência de payload correspondente validado; boot e execução ART ainda não testados aqui |
| Digitalis / Berberis | Experimental: WayDroid-ATV LineageOS 23.2 Android 16 QPR2 release 20260717, host+guest x86_64 | Bundle QPR2 de 74 arquivos, manifest Git fixado e SHA-256 por artefato; Android 16 genérico/QPR0, Android 17 e outras ROMs bloqueados; boot e execução ART não testados neste ambiente |
| Widevine | Detecção | Presença de arquivos não prova DRM L3/licenciamento |
| nodataperm / hidestatusbar | Bloqueados | Patches antigos não são aplicados indiscriminadamente em imagens diferentes |
| Zygisk / Zygisk Next / LSPosed / Vector | Não certificados | O WCS lista módulos e pode coletar diagnóstico; não declara injeção funcional sem teste ART real |

### Native Bridge ARM64 → x86_64

Os comandos `wcs install libndk` e `wcs install libhoudini` instalam payloads distintos da coleção upstream `casualsnek/waydroid_script`. O WCS não considera a simples presença de `ro.dalvik.vm.native.bridge` uma razão para pular a instalação: ele substitui os arquivos correspondentes na camada `overlay/system` e define a propriedade para o tradutor escolhido. Antes disso, registra os arquivos que serão sobrepostos e os valores anteriores das propriedades. `wcs remove <tradutor>` restaura esse estado; instalar o outro tradutor primeiro restaura o estado-base e só depois aplica o novo.

Os pacotes upstream fixados nesta versão existem somente para Android 11 e 13. O WCS detecta a versão na imagem e bloqueia qualquer outra geração em vez de reutilizar binários antigos. O host e o guest precisam ser x86_64 e `mount_overlays=True`. A imagem precisa estar parada durante a operação. O instalador de Houdini também gera o `system/etc/init/houdini.rc` com os registros `binfmt_misc` usados pelo upstream.

`libndk` e `libhoudini` não podem ser usados simultaneamente como provedores ativos da propriedade única `ro.dalvik.vm.native.bridge`. Para experimentar o outro, use `wcs install` do segundo; o WCS restaura a sobreposição anterior antes de aplicar o novo. Essa troca é diferente de manter os dois ativos ao mesmo tempo. A inicialização Android, a execução de APKs ARM/ARM64 e a compatibilidade dos jogos continuam exigindo teste real em cada imagem e CPU.

### Digitalis/Berberis ARM64 → x86_64

`wcs install digitalis` integra o bundle `digitalis-qpr2` do projeto Refract, que contém o Native Bridge x86-64 `libberberis_arm64.so`, o runner/binfmt, o linker e `app_process64` ARM64, a Bionic ARM64 convidada, proxies de bibliotecas Android, `ld.config.arm64.txt` e o init hook `berberis.rc`. São 74 artefatos fixados em um commit upstream; WCS verifica o Git blob do manifesto e o SHA-256 de cada arquivo antes de qualquer escrita.

O bundle foi preparado especificamente para WayDroid-ATV LineageOS 23.2 / Android 16 QPR2 (release 20260717). Digitalis usa estruturas internas da Bionic ARM64 que mudaram entre QPR0 e QPR2; trocar esses bundles causa crash de processos ARM64. Por isso WCS exige o canal `a16-qpr2` ou a identificação exata da release preinstalled 20260717, Android 16, host/guest x86_64 e `mount_overlays=True`. Não aplica esse bundle a Android 16 genérico, Android 17 ou outras ROMs.

A integração substitui o provider ativo no overlay, cria `system/etc/init/ndk_translation.rc` vazio para mascarar o registro de binfmt concorrente da imagem, e define `ro.dalvik.vm.native.bridge=libberberis_arm64.so`, `ro.dalvik.vm.isa.arm64=x86_64`, `ro.enable.native.bridge.exec=1` e as ABI lists. O seletor é persistido em `[waydroid]`, `[properties]` e `/data/misc/waydroid_settings`; `waydroid upgrade --offline` regenera a configuração efetiva. Os arquivos/valores anteriores ficam no estado WCS para restauração por `wcs remove digitalis` ou antes de trocar para outro provider.

Digitalis traduz instruções ARM64; não fornece aceleração gráfica nem substitui Mesa, Vulkan, ANGLE ou o driver do host. O carregamento do engine, a inicialização de Zygote/ART e a execução de cada APK ainda exigem validação no Android real. A suíte host testa manifestos, hashes, arquitetura ELF, gate de imagem, instalação simulada no overlay, persistência dos três seletores e rollback, mas não executa o engine dentro de Waydroid.

## Diagnóstico microG e autenticação

`wcs microg` e o campo `microg_diagnostics` de `wcs extras` executam somente consultas dentro do guest. Eles podem registrar pacotes, caminhos `priv-app`, arquivos de allowlist, um indicador de permissão `FAKE_PACKAGE_SIGNATURE`, WebView/Custom Tabs e o estado do `gservices.db`. Esses resultados são pistas: os nomes `com.google.android.gms` e `com.google.android.gsf` também são usados por GApps.

O módulo DresOS coloca componentes oficiais do microG em locais privilegiados e regenera allowlists, mas não inclui Zygisk/Xposed para spoofing. A verificação autoritativa é microG Settings → Self-Check, em particular “System spoofs signature”. Mesmo com essa linha aprovada, é necessário testar registro do dispositivo, login real, sincronização e Play Store/Aurora. O WCS mantém esses estados como `RUNTIME_REQUIRED` e nunca transforma a presença do ZIP ou dos pacotes em sucesso de autenticação.

## Limitações importantes

1. “Suporte a todas as imagens oficiais” nesta versão significa detectar os formatos e canais oficiais, consultar seus manifestos e usar o inicializador oficial para selecionar a imagem compatível com o host. Não significa que todo tipo/arquitetura tenha necessariamente um manifesto publicado hoje.
2. O inicializador oficial limpa a camada writable do overlay ao atualizar imagens. O WCS bloqueia a troca quando encontra o hook da integração Magisk WCS. Outros módulos Magisk podem precisar ser reavaliados depois da troca.
3. A troca cria backup somente de `system.img` e `vendor.img`; não inclui `/data`, configuração de aplicativos nem dados pessoais Android.
4. Testes host não simulam init Android, daemon Magisk, Zygote, ART, assinatura falsa, login Google, DRM ou drivers. Essas partes exigem integração real.
5. Imagens customizadas sem canais OTA permanecem gerenciáveis para inspeção, hashes, backup e recursos compatíveis com runtime; não são tratadas como imagem oficial OTA.
