# Plano de testes WCS 0.5.0

## Testes automatizados no host

Executar:

```bash
python3 -m unittest discover -s tests -v
```

A suíte cobre mapeamento SDK, leitura dos canais oficiais, detecção de imagens pré-instaladas, consulta de manifestos por arquitetura/ROM/tipo, tratamento de variantes não publicadas, seleção de imagem usando os parâmetros do Waydroid upstream, bloqueios para overlay Magisk e imagens customizadas, validação de SHA/ZIP, segurança de caminhos, backup/restauração e ciclo de vida de módulos. Os testes de Native Bridge verificam que libndk/libhoudini substituem uma Native Bridge pré-existente no overlay, que a alternância restaura o estado-base, que `houdini.rc` é gerado/restaurado, que payloads incompletos e caminhos ZIP maliciosos são recusados e que Android fora das gerações 11/13 não recebe binários antigos. Os testes Digitalis verificam o Git blob pin do manifesto de 74 entradas, paths sem traversal, bloqueio Android 17/Android 16 genérico, máquinas ELF x86-64/AArch64, gravação das três fontes de propriedade (dois trechos INI e `waydroid_settings`), rollback e preservação de arquivos preexistentes no overlay.

Esses testes são host-side. Não executam Android dentro do ambiente de testes e não provam comportamento em Fedora com SELinux Enforcing.

## Matriz de integração Android real

| Família / caso | Arquitetura | Teste necessário | Estado |
|---|---|---|---|
| Waydroid oficial Lineage VANILLA | x86_64 | init, boot, apps, overlay, OTA | Não executado aqui |
| Waydroid oficial Lineage FOSS | x86_64 | init, boot, pré-instalados e permissões | Não executado aqui |
| Waydroid oficial Lineage GAPPS | x86_64 | Play Services, Play Store, Android ID | Não executado aqui |
| Waydroid oficial Bliss | Cada arquitetura com manifesto publicado | init, boot, props, vendor e overlays | Não executado aqui |
| Waydroid oficial x86 | x86 | ABI guest e inicializador | Não executado aqui |
| Waydroid oficial ARM / ARM64 | ARM/ARM64 | ABI, vendor, Native Bridge e aceleração | Não executado aqui |
| Imagens preinstalled/custom | Host suportado | `images_path`, channels `None`, hashes, backup | Não executado aqui |
| WayDroid-ATV Android 16/17 | x86_64/ARM64 quando publicados | boot, root e módulos específicos ATV | Não executado aqui |
| Waydroid Android 11 x86_64 + libndk | x86_64 | boot, `ro.dalvik.vm.native.bridge`, binfmt e APK ARM/ARM64 real | Não executado aqui |
| Waydroid Android 11 x86_64 + libhoudini | x86_64 | boot, houdini.rc, binfmt e APK ARM/ARM64 real | Não executado aqui |
| Waydroid Android 13 x86_64 + libndk/libhoudini | x86_64 | repetir instalação/remoção e execução de APKs em cada tradutor separadamente | Não executado aqui |
| Waydroid Android fora das gerações 11/13 + tradutores herdados | x86_64 | confirmar bloqueio antes de qualquer escrita | Coberto por testes host para Android 17; sem integração real |
| WayDroid-ATV LineageOS 23.2 Android 16 QPR2 + Digitalis | x86_64 | boot, Native Bridge `libberberis_arm64.so`, linker ARM64, binfmt, ART e APK ARM64 real | Integrador/rollback cobertos por testes host; Android real não executado aqui |
| Android 16 genérico/QPR0 ou Android 17 + bundle Digitalis QPR2 | x86_64 | bloqueio antes de download/escrita | Coberto por testes host |

## Evidências requeridas por operação

- **Seleção OTA:** registrar saída de `waydroid init -h`, manifesto escolhido, tipo de sistema, ROM e arquitetura resolvida.
- **Download:** conferir SHA-256 pelo manifesto oficial, `system.img` e `vendor.img` após extração.
- **Boot:** `ro.build.version.release`, `ro.build.version.sdk`, `sys.boot_completed=1`, logs do container e `waydroid status`.
- **Fedora/SELinux:** registrar `getenforce` (deve permanecer `Enforcing`), `ausearch -m avc -ts recent`, journal do Waydroid/LXC e qualquer falha de transição; não usar permissive como workaround.
- **Overlay:** confirmar que as personalizações esperadas sobreviveram ou foram explicitamente removidas pela operação de troca.
- **Native Bridge:** após boot, confirmar `getprop ro.dalvik.vm.native.bridge`, `getprop ro.product.cpu.abilist`, presença de binfmt e carregamento de bibliotecas; executar APKs ARM e ARM64 conhecidos. Repetir libndk/Houdini separadamente. Para Digitalis, verificar o linker ARM64, `app_process64`, runner/binfmt e logs de ART antes de declarar um APK funcional. A instalação dos arquivos não prova execução funcional.
- **Magisk:** `magisk -v`, daemon `magiskd`, `su -c id -u`; não usar somente a presença de arquivos como prova.
- **Zygisk/LSPosed/Vector:** estado do serviço e teste mínimo de injeção ART, não apenas a interface Manager.
- **microG:** executar `wcs microg`/`wcs extras` para guardar as pistas somente leitura; depois confirmar no Self-Check completo, inclusive “System spoofs signature”, registrar o dispositivo, fazer login Google incluindo o botão “Concordo”, sincronizar e testar Play Store/Aurora. O probe nunca substitui essas etapas.
- **Widevine:** reprodução/licenciamento real; presença de biblioteca não conta como sucesso.
- **F-Droid Privileged/CA:** permissão/instalação silenciosa ou confiança CA após reinício.

## Critério de aceitação

Um teste só fica `PASSED` quando a evidência acima é capturada na imagem e ABI alvo. `NOT EXECUTED` não é sucesso. Um manifesto oficial consultável confirma apenas a disponibilidade do pacote OTA, não o boot funcional de cada variante.
