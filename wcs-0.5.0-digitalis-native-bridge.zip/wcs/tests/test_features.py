# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations

import io
import subprocess
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

from core import feature_manager
from core.common import WCSError


class FeatureCatalogTests(unittest.TestCase):
    def test_catalog_contains_every_original_waydroid_script_option(self):
        ids = {item["id"] for item in feature_manager.catalog()}
        self.assertEqual(ids, {
            "gapps", "microg", "libndk", "libhoudini", "magisk", "widevine",
            "smartdock", "fdroidpriv", "mitm", "nodataperm", "hidestatusbar", "digitalis",
        })

    def test_smartdock_parser_selects_highest_versioned_fdroid_apk(self):
        page = (
            b'<a href="/repo/cu.axel.smartdock_1142.apk">old</a>'
            b'<a href="/repo/cu.axel.smartdock_1150.apk">new</a>'
        )
        url, version = feature_manager._parse_smartdock_page(page)
        self.assertEqual(version, 1150)
        self.assertEqual(url, "https://f-droid.org/repo/cu.axel.smartdock_1150.apk")

    def test_smartdock_parser_refuses_unknown_page_layout(self):
        with self.assertRaises(WCSError):
            feature_manager._parse_smartdock_page(b"<html>no apk link</html>")

    def test_microg_release_requires_published_sha256(self):
        release = [{
            "tag_name": "microg-v3.1.8", "draft": False, "prerelease": False,
            "assets": [{"name": "DresOS-microG-v3_1_8.zip", "browser_download_url": "https://example.invalid/file.zip"}],
        }]
        with mock.patch.object(feature_manager, "fetch_json", return_value=release):
            with self.assertRaisesRegex(WCSError, "não publicou SHA-256"):
                feature_manager._microg_asset()

    def test_microg_release_returns_sha256_from_github_metadata(self):
        digest = "a" * 64
        release = [{
            "tag_name": "microg-v3.1.8", "draft": False, "prerelease": False,
            "assets": [{
                "name": "DresOS-microG-v3_1_8.zip",
                "browser_download_url": "https://example.invalid/file.zip",
                "digest": "sha256:" + digest,
            }],
        }]
        with mock.patch.object(feature_manager, "fetch_json", return_value=release):
            self.assertEqual(
                feature_manager._microg_asset(),
                ("https://example.invalid/file.zip", digest, "microg-v3.1.8"),
            )

    def test_android_17_microg_install_is_blocked_before_download(self):
        info = {"running": True, "android": "17"}
        with mock.patch.object(feature_manager, "inspect", return_value=info), \
             mock.patch.object(feature_manager, "_microg_asset") as asset:
            with self.assertRaisesRegex(WCSError, "Android 17"):
                feature_manager.install_microg()
            asset.assert_not_called()

    def test_microg_refuses_to_install_on_a_gapps_image(self):
        info = {"running": True, "android": "16"}
        with mock.patch.object(feature_manager, "inspect", return_value=info), \
             mock.patch.object(feature_manager.module_manager, "list_modules", return_value=[]), \
             mock.patch.object(feature_manager.extras, "inspect_extras", return_value={
                 "google_services_framework": True,
                 "google_play_services": True,
                 "google_play_store": True,
             }), \
             mock.patch.object(feature_manager, "_microg_asset") as asset:
            with self.assertRaisesRegex(WCSError, "NÃO instalará microG sobre essa imagem"):
                feature_manager.install_microg()
            asset.assert_not_called()

    def test_android_11_only_hack_refuses_android_16_without_writing(self):
        info = {"running": True, "android": "16"}
        with mock.patch.object(feature_manager, "inspect", return_value=info):
            with self.assertRaisesRegex(WCSError, "services.jar"):
                feature_manager.install_feature("nodataperm")

    def test_gapps_variant_uses_official_waydroid_atv_channel_after_backup(self):
        info = {"running": False, "android": "16"}
        backup_path = Path("/tmp/wcs-test-backup")
        completed = subprocess.CompletedProcess(args=["waydroid"], returncode=0, stdout="ok", stderr="")
        with mock.patch.object(feature_manager, "require_root"), \
             mock.patch.object(feature_manager, "inspect", return_value=info), \
             mock.patch.object(feature_manager, "require_stopped"), \
             mock.patch.object(feature_manager.backup, "create_backup", return_value=backup_path), \
             mock.patch.object(feature_manager, "run_command", return_value=completed) as run:
            result = feature_manager.set_gapps_variant("GAPPS")
        first = run.call_args_list[0].args[0]
        self.assertIn("https://waydroid-atv.github.io/ota/a16-qpr2/system", first)
        self.assertEqual(first[-1], "GAPPS")
        self.assertIn("/tmp/wcs-test-backup", result["backup"])
        self.assertEqual(run.call_count, 2)

    def test_official_image_switch_uses_upstream_initializer_once_after_backup(self):
        info = {
            "running": False, "images": {"system": True, "vendor": True},
            "images_path": "/var/lib/waydroid/images", "overlay_dir": "/tmp/wcs-test-overlay",
        }
        backup_path = Path("/tmp/wcs-official-image-backup")
        help_result = subprocess.CompletedProcess(
            args=["waydroid", "init", "--help"], returncode=0,
            stdout="-i --images_path -c --system_channel -v --vendor_channel -r --rom_type -s --system_type", stderr="",
        )
        init_result = subprocess.CompletedProcess(
            args=["waydroid", "init"], returncode=0, stdout="downloaded and validated", stderr="",
        )
        with mock.patch.object(feature_manager, "require_root"), \
             mock.patch.object(feature_manager, "inspect", return_value=info), \
             mock.patch.object(feature_manager, "require_stopped"), \
             mock.patch.object(feature_manager.root_manager, "INSTALLED_MARKER", Path("/tmp/wcs-no-magisk-marker")), \
             mock.patch.object(feature_manager.backup, "create_backup", return_value=backup_path) as make_backup, \
             mock.patch.object(feature_manager, "run_command", side_effect=[help_result, init_result]) as run:
            result = feature_manager.set_system_image_type("FOSS", rom_type="bliss")
        make_backup.assert_called_once_with()
        self.assertEqual(run.call_count, 2)
        init_args = run.call_args_list[1].args[0]
        self.assertEqual(init_args, [
            "waydroid", "init", "-f", "-i", "/var/lib/waydroid/images", "-c", "https://ota.waydro.id/system",
            "-v", "https://ota.waydro.id/vendor", "-r", "bliss", "-s", "FOSS",
        ])
        self.assertEqual(result["source"], "OFFICIAL_WAYDROID_OTA")
        self.assertIn("downloaded and validated", result["init_output"])

    def test_official_image_switch_refuses_missing_waydroid_cli_options(self):
        info = {
            "running": False, "images": {"system": True, "vendor": True},
            "images_path": "/var/lib/waydroid/images", "overlay_dir": "/tmp/wcs-test-overlay",
        }
        help_result = subprocess.CompletedProcess(args=["waydroid"], returncode=0, stdout="init [-f]", stderr="")
        with mock.patch.object(feature_manager, "require_root"), \
             mock.patch.object(feature_manager, "inspect", return_value=info), \
             mock.patch.object(feature_manager, "require_stopped"), \
             mock.patch.object(feature_manager, "run_command", return_value=help_result), \
             mock.patch.object(feature_manager.backup, "create_backup") as make_backup:
            with self.assertRaisesRegex(WCSError, "não expõe todos os parâmetros"):
                feature_manager.set_system_image_type("GAPPS")
        make_backup.assert_not_called()

    def test_official_image_switch_refuses_wcs_magisk_overlay(self):
        info = {
            "running": False, "images": {"system": True, "vendor": True},
            "images_path": "/var/lib/waydroid/images", "overlay_dir": "/tmp/wcs-test-overlay",
        }
        with tempfile.TemporaryDirectory() as tmp:
            marker = Path(tmp) / "installed.json"
            marker.write_text("{}", encoding="utf-8")
            with mock.patch.object(feature_manager, "require_root"), \
                 mock.patch.object(feature_manager, "inspect", return_value=info), \
                 mock.patch.object(feature_manager, "require_stopped"), \
                 mock.patch.object(feature_manager.root_manager, "INSTALLED_MARKER", marker), \
                 mock.patch.object(feature_manager, "run_command", return_value=subprocess.CompletedProcess(
                     args=["waydroid", "init", "--help"], returncode=0,
                     stdout="--images_path --system_channel --vendor_channel --rom_type --system_type", stderr="")), \
                 mock.patch.object(feature_manager.backup, "create_backup") as make_backup:
                with self.assertRaisesRegex(WCSError, "integração Magisk do WCS"):
                    feature_manager.set_system_image_type("GAPPS")
            make_backup.assert_not_called()

    def test_official_image_switch_refuses_preinstalled_image_directory(self):
        info = {
            "running": False, "images": {"system": True, "vendor": True},
            "images_path": "/etc/waydroid-extra/images", "overlay_dir": "/tmp/wcs-test-overlay",
        }
        help_result = subprocess.CompletedProcess(
            args=["waydroid", "init", "--help"], returncode=0,
            stdout="--images_path --system_channel --vendor_channel --rom_type --system_type", stderr="",
        )
        with mock.patch.object(feature_manager, "require_root"), \
             mock.patch.object(feature_manager, "inspect", return_value=info), \
             mock.patch.object(feature_manager, "require_stopped"), \
             mock.patch.object(feature_manager.root_manager, "INSTALLED_MARKER", Path("/tmp/wcs-no-magisk-marker")), \
             mock.patch.object(feature_manager, "run_command", return_value=help_result), \
             mock.patch.object(feature_manager.backup, "create_backup") as make_backup:
            with self.assertRaisesRegex(WCSError, "imagens pré-instaladas"):
                feature_manager.set_system_image_type("GAPPS")
        make_backup.assert_not_called()

    def test_gapps_variant_rejects_invalid_variant(self):
        with mock.patch.object(feature_manager, "require_root"):
            with self.assertRaises(WCSError):
                feature_manager.set_gapps_variant("UNKNOWN")

    def test_fdroid_ota_is_converted_to_valid_magisk_module(self):
        apk_buffer = io.BytesIO()
        with zipfile.ZipFile(apk_buffer, "w") as apk:
            apk.writestr("AndroidManifest.xml", b"fake-manifest")
        apk_data = apk_buffer.getvalue()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ota = root / "ota.zip"
            with zipfile.ZipFile(ota, "w") as archive:
                archive.writestr("F-Droid.apk", apk_data)
                archive.writestr("F-DroidPrivilegedExtension.apk", apk_data)
                archive.writestr("permissions_org.fdroid.fdroid.privileged.xml", b"<permissions/>")
            captured: dict[str, object] = {}

            def fake_install(path: Path):
                captured["path"] = path
                captured["module"] = feature_manager.module_manager._validate_module_zip(path)
                return {"id": "wcsfdroidpriv", "name": "WCS F-Droid", "sha256": "0" * 64, "output": ""}

            with mock.patch.object(feature_manager, "_running_info", return_value={"running": True}), \
                 mock.patch.object(feature_manager, "_download", return_value=ota), \
                 mock.patch.object(feature_manager, "_download_dir", return_value=root), \
                 mock.patch.object(feature_manager.module_manager, "install_module", side_effect=fake_install):
                result = feature_manager.install_fdroid_privileged()
            self.assertEqual(result["id"], "wcsfdroidpriv")
            self.assertEqual(captured["module"][0], "wcsfdroidpriv")
            module_zip = Path(captured["path"])
            with zipfile.ZipFile(module_zip) as module:
                self.assertIn("system/priv-app/F-DroidPrivilegedExtension/F-DroidPrivilegedExtension.apk", module.namelist())
                self.assertIn("system/app/F-Droid/F-Droid.apk", module.namelist())

    def test_ca_module_contains_conscrypt_apex_mount_script_and_certificate(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cert = root / "ca.pem"
            cert.write_text("synthetic test certificate", encoding="utf-8")
            with mock.patch.object(feature_manager, "_download_dir", return_value=root), \
                 mock.patch.object(feature_manager, "_ca_hash", return_value="a1b2c3d4"), \
                 mock.patch.object(feature_manager, "run_command", return_value=subprocess.CompletedProcess(args=["openssl"], returncode=0, stdout="-----BEGIN CERTIFICATE-----\nTEST\n-----END CERTIFICATE-----\n", stderr="")):
                module = feature_manager._build_ca_module(cert, 2)
            self.assertTrue(module.is_file())
            with zipfile.ZipFile(module) as archive:
                self.assertIn("certificates/a1b2c3d4.2", archive.namelist())
                script = archive.read("post-fs-data.sh").decode()
                self.assertIn("/apex/com.android.conscrypt/cacerts", script)
                self.assertIn("system_security_cacerts_file", script)
                self.assertIn("-----BEGIN CERTIFICATE-----", archive.read("certificates/a1b2c3d4.2").decode())
                script_info = archive.getinfo("post-fs-data.sh")
                self.assertEqual((script_info.external_attr >> 16) & 0o777, 0o755)

    def test_ota_archive_path_traversal_is_rejected(self):
        with tempfile.TemporaryFile() as handle:
            with zipfile.ZipFile(handle, "w") as archive:
                archive.writestr("../escape", b"bad")
            handle.seek(0)
            with zipfile.ZipFile(handle) as archive:
                with self.assertRaisesRegex(WCSError, "caminho inseguro"):
                    feature_manager._safe_zip_members(archive)


if __name__ == "__main__":
    unittest.main()
