# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations

import hashlib
import json
import struct
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from core import arm_translation, digitalis_translation, feature_manager
from core.common import WCSError


class DigitalisTranslationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.overlay = self.root / "overlay"
        self.system = self.overlay / "system"
        self.system.mkdir(parents=True)
        self.config = self.root / "waydroid.cfg"
        self.config.write_text(
            "[waydroid]\narch = x86_64\nmount_overlays = True\n"
            "system_ota = https://waydroid-atv.github.io/ota/a16-qpr2/system\n\n"
            "[properties]\n# preserve this comment\n"
            "ro.dalvik.vm.native.bridge = libndk_translation.so\n"
            "ro.product.cpu.abilist = x86_64,x86\n"
            "persist.waydroid.multi_windows = true\n",
            encoding="utf-8",
        )
        self.data = self.root / "waydroid-data"
        misc = self.data / "misc"
        misc.mkdir(parents=True)
        self.settings = misc / "waydroid_settings"
        self.settings.write_text("persist.waydroid.foo=bar\nro.dalvik.vm.native.bridge=libndk_translation.so\n", encoding="utf-8")

        self.state_dir = self.root / "wcs-state"
        self.state_root = self.state_dir / "arm-translation"
        self.state_file = self.state_root / "state.json"
        self.cache = self.root / "cache-digitalis"
        self.cache.mkdir()

        self.info = {
            "running": False,
            "android": "16",
            "sdk": "36",
            "arch": "x86_64",
            "host_arch": "x86_64",
            "mount_overlays": "true",
            "overlay_dir": str(self.overlay),
            "config_path": str(self.config),
            "data_path": str(self.data),
            "system_ota": "https://waydroid-atv.github.io/ota/a16-qpr2/system",
            "system_datetime": "20260717",
            "rom_type": "lineage",
            "images": {"system": True, "vendor": True},
            "status": {"session": "STOPPED", "container": "STOPPED"},
            "lxc_state": "STOPPED",
        }
        self.patches = [
            mock.patch.object(digitalis_translation, "inspect", return_value=self.info),
            mock.patch.object(digitalis_translation, "require_stopped"),
            mock.patch.object(digitalis_translation, "STATE_ROOT", self.state_root),
            mock.patch.object(digitalis_translation, "STATE_FILE", self.state_file),
            mock.patch.object(digitalis_translation, "CACHE_ROOT", self.cache),
            mock.patch.object(arm_translation, "STATE_ROOT", self.state_root),
            mock.patch.object(arm_translation, "STATE_FILE", self.state_file),
            mock.patch.object(arm_translation, "STATE_DIR", self.state_dir),
            mock.patch.object(arm_translation, "require_stopped"),
            mock.patch.object(arm_translation, "run_command", return_value=__import__("subprocess").CompletedProcess(["waydroid"], 0, "ok", "")),
        ]
        for patcher in self.patches:
            patcher.start()
        self.addCleanup(lambda: [patcher.stop() for patcher in reversed(self.patches)])

    @staticmethod
    def _elf(machine: int) -> bytes:
        header = bytearray(64)
        header[:4] = b"\x7fELF"
        header[4] = 2  # ELFCLASS64
        header[5] = 1  # little-endian
        header[6] = 1  # ELF version
        struct.pack_into("<H", header, 18, machine)
        return bytes(header)

    def _bundle(self):
        entries = {}
        files = {}
        for index, relative in enumerate(sorted(digitalis_translation.REQUIRED_FILES)):
            digest = hashlib.sha256(f"digitalis-fixture-{relative}".encode()).hexdigest()
            entries[relative] = digest
            path = self.cache / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            if relative in {
                "system/lib64/libberberis_arm64.so",
                "system/bin/berberis_program_runner_arm64",
                "system/bin/berberis_program_runner_binfmt_misc_arm64",
            }:
                path.write_bytes(self._elf(62))
            elif relative in {
                "system/bin/arm64/linker64",
                "system/bin/arm64/app_process64",
                "system/lib64/arm64/libc.so",
            }:
                path.write_bytes(self._elf(183))
            else:
                path.write_bytes(f"payload:{relative}".encode())
            # Use the actual fixture bytes' hash for bundle verification.
            entries[relative] = arm_translation._sha256_file(path)
            files[relative] = path
        # Add deterministic filler paths so manifest parsing can test the pinned 74-entry count.
        for index in range(74 - len(entries)):
            relative = f"system/test/filler-{index:02d}.bin"
            path = self.cache / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(f"filler-{index}".encode())
            entries[relative] = arm_translation._sha256_file(path)
            files[relative] = path
        return entries, files

    def _install(self):
        entries, files = self._bundle()
        with mock.patch.object(digitalis_translation, "_load_bundle", return_value=(entries, files)), \
             mock.patch.object(arm_translation, "_ensure_root_dir", side_effect=lambda p: Path(p).mkdir(parents=True, exist_ok=True)):
            return digitalis_translation.install()

    def test_manifest_parser_checks_git_blob_pin_and_74_sha256_entries(self):
        entries, _ = self._bundle()
        manifest = "".join(f"{digest}  {path}\n" for path, digest in sorted(entries.items())).encode("ascii")
        parsed = digitalis_translation._parse_manifest(
            manifest,
            expected_count=74,
            expected_git_blob_sha1=digitalis_translation._git_blob_sha1(manifest),
        )
        self.assertEqual(len(parsed), 74)
        with self.assertRaisesRegex(WCSError, "objeto Git fixado"):
            digitalis_translation._parse_manifest(manifest, expected_count=74)

    def test_bundle_elf_architectures_are_checked_before_install(self):
        entries, _ = self._bundle()
        digitalis_translation._validate_bundle(self.cache, entries)
        bad = self.cache / "system/lib64/libberberis_arm64.so"
        bad.write_bytes(self._elf(183))  # AArch64 guest ELF is wrong for the x86-64 NativeBridge.
        with self.assertRaisesRegex(WCSError, "ELF inesperada"):
            digitalis_translation._validate_bundle(self.cache, entries)

    def test_manifest_parser_rejects_path_traversal(self):
        entries, _ = self._bundle()
        entries["system/../../outside"] = "a" * 64
        manifest = "".join(f"{digest}  {path}\n" for path, digest in sorted(entries.items())).encode("ascii")
        with self.assertRaisesRegex(WCSError, "Caminho inseguro"):
            digitalis_translation._parse_manifest(
                manifest,
                expected_count=74,
                expected_git_blob_sha1=digitalis_translation._git_blob_sha1(manifest),
            )

    def test_qpr2_url_must_use_exact_upstream_host_and_path(self):
        for url in (
            "https://evil-waydroid-atv.github.io/ota/a16-qpr2/system",
            "https://waydroid-atv.github.io.attacker.example/ota/a16-qpr2/system",
            "http://waydroid-atv.github.io/ota/a16-qpr2/system",
        ):
            info = dict(self.info)
            info["system_ota"] = url
            info["channel_kind"] = "WAYDROID_ATV"
            info["system_datetime"] = "UNKNOWN"
            with self.subTest(url=url), self.assertRaisesRegex(WCSError, "não prova essa correspondência"):
                digitalis_translation._compatible_image(info)

    def test_preinstalled_qpr2_requires_preinstalled_channel_kind_and_release_date(self):
        info = dict(self.info)
        info["system_ota"] = "None"
        info["channel_kind"] = "PREINSTALLED_OR_NO_OTA"
        info["system_datetime"] = "20260717"
        self.assertEqual(digitalis_translation._compatible_image(info), "preinstalled-20260717-qpr2")
        info["channel_kind"] = "OFFICIAL_WAYDROID"
        with self.assertRaises(WCSError):
            digitalis_translation._compatible_image(info)

    def test_android_17_and_generic_android_16_images_are_blocked(self):
        for changed in (
            {"android": "17", "sdk": "37", "system_ota": "https://waydroid-atv.github.io/ota/a17-qpr0/system"},
            {"android": "16", "sdk": "36", "system_ota": "https://ota.waydro.id/system/lineage/waydroid_x86_64/VANILLA.json", "system_datetime": "UNKNOWN"},
        ):
            test_info = dict(self.info)
            test_info.update(changed)
            with self.subTest(changed=changed), self.assertRaises(WCSError):
                digitalis_translation._compatible_image(test_info)

    def test_real_digitalis_bundle_layout_is_verified_and_installed_transactionally(self):
        old_bridge = self.system / "lib64/libberberis_arm64.so"
        old_bridge.parent.mkdir(parents=True)
        old_bridge.write_bytes(b"image-builtin-bridge")
        old_mask = self.system / digitalis_translation.NDK_MASK_PATH
        old_mask.parent.mkdir(parents=True)
        old_mask.write_text("# image-owned ndk init hook\n")
        original_config = self.config.read_text()
        original_settings = self.settings.read_text()

        result = self._install()
        self.assertEqual(result["feature"], "digitalis")
        self.assertEqual(result["artifacts_verified"], 74)
        self.assertEqual(old_bridge.read_bytes(), self.cache.joinpath("system/lib64/libberberis_arm64.so").read_bytes())
        self.assertEqual(old_mask.read_bytes(), b"")
        self.assertIn("ro.dalvik.vm.native.bridge = libberberis_arm64.so", self.config.read_text())
        self.assertIn("ro.dalvik.vm.native.bridge=libberberis_arm64.so", self.settings.read_text())
        self.assertIn("ro.product.cpu.abilist = x86_64,x86,arm64-v8a", self.config.read_text())
        self.assertTrue(self.state_file.is_file())

        removed = digitalis_translation.remove()
        self.assertIn("digitalis removido", removed.lower())
        self.assertEqual(old_bridge.read_bytes(), b"image-builtin-bridge")
        self.assertEqual(old_mask.read_text(), "# image-owned ndk init hook\n")
        self.assertEqual(self.config.read_text(), original_config)
        self.assertEqual(self.settings.read_text(), original_settings)
        self.assertFalse(self.state_root.exists())

    def test_failed_waydroid_config_refresh_rolls_back_overlay_and_selectors(self):
        old_bridge = self.system / "lib64/libberberis_arm64.so"
        old_bridge.parent.mkdir(parents=True)
        old_bridge.write_bytes(b"image-default")
        original_config = self.config.read_text()
        original_settings = self.settings.read_text()
        entries, files = self._bundle()

        def refresh(argv, *, check=True, timeout=180, **kwargs):
            if argv[:3] == ["waydroid", "upgrade", "--offline"] and refresh.calls == 0:
                refresh.calls += 1
                raise WCSError("forced test failure")
            refresh.calls += 1
            return __import__("subprocess").CompletedProcess(argv, 0, "ok", "")
        refresh.calls = 0

        with mock.patch.object(digitalis_translation, "_load_bundle", return_value=(entries, files)), \
             mock.patch.object(arm_translation, "_ensure_root_dir", side_effect=lambda path: Path(path).mkdir(parents=True, exist_ok=True)), \
             mock.patch.object(arm_translation, "run_command", side_effect=refresh):
            with self.assertRaisesRegex(WCSError, "forced test failure"):
                digitalis_translation.install()

        self.assertEqual(old_bridge.read_bytes(), b"image-default")
        self.assertEqual(self.config.read_text(), original_config)
        self.assertEqual(self.settings.read_text(), original_settings)
        self.assertFalse(self.state_root.exists())
        self.assertGreaterEqual(refresh.calls, 2)  # failed refresh followed by rollback refresh

    def test_interrupted_remove_is_idempotently_recoverable(self):
        old_bridge = self.system / "lib64/libberberis_arm64.so"
        old_bridge.parent.mkdir(parents=True)
        old_bridge.write_bytes(b"image-default")
        original_config = self.config.read_text()
        original_settings = self.settings.read_text()
        self._install()

        failed = __import__("subprocess").CompletedProcess(
            ["waydroid", "upgrade", "--offline"], 1, "", "forced refresh failure"
        )
        with mock.patch.object(arm_translation, "run_command", return_value=failed):
            with self.assertRaisesRegex(WCSError, "registro/backup WCS foi preservado"):
                digitalis_translation.remove()

        self.assertTrue(self.state_file.is_file())
        state = json.loads(self.state_file.read_text())
        self.assertEqual(state["status"], "restoring")
        self.assertEqual(old_bridge.read_bytes(), b"image-default")
        self.assertEqual(self.config.read_text(), original_config)
        self.assertEqual(self.settings.read_text(), original_settings)

        with mock.patch.object(arm_translation, "run_command", return_value=__import__("subprocess").CompletedProcess(["waydroid"], 0, "ok", "")):
            digitalis_translation.remove()
        self.assertFalse(self.state_root.exists())

    def test_digitalis_rejects_modified_installed_config_instead_of_claiming_ok(self):
        self._install()
        text = self.config.read_text().replace(
            "ro.dalvik.vm.native.bridge = libberberis_arm64.so",
            "ro.dalvik.vm.native.bridge = libndk_translation.so",
        )
        self.config.write_text(text)
        with self.assertRaisesRegex(WCSError, "[properties].*alteradas"):
            digitalis_translation._already_installed(self.info)

    def test_feature_catalog_exposes_digitalis_as_distinct_experimental_provider(self):
        catalog = {item["id"]: item for item in feature_manager.catalog()}
        self.assertIn("digitalis", catalog)
        self.assertIn("ANDROID16_QPR2", catalog["digitalis"]["status"])
        self.assertIn("Berberis", catalog["digitalis"]["description"])


if __name__ == "__main__":
    unittest.main()
