# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations

import hashlib
import subprocess
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

from core import module_manager
from core.common import WCSError


class WaydroidMagiskTransportTests(unittest.TestCase):
    def test_stdin_script_invokes_magisk_inside_android_shell(self):
        script = module_manager._build_magisk_install_stdin(
            "wcs-module-0123456789abcdef.zip"
        )
        self.assertEqual(
            script,
            "magisk --install-module '/data/local/tmp/wcs-module-0123456789abcdef.zip'\n"
            "_wcs_magisk_rc=$?\n"
            "printf 'WCS_MAGISK_INSTALL_EXIT=%s\\n' \"$_wcs_magisk_rc\"\n"
            "exit \"$_wcs_magisk_rc\"\n",
        )
        # Validate the actual shell program rather than just checking substrings.
        subprocess.run(["/bin/sh", "-n"], input=script, text=True, check=True)

    def test_remote_name_rejects_path_and_shell_injection(self):
        invalid = (
            "../module.zip",
            "/tmp/module.zip",
            "wcs-module-bad.zip",
            "wcs-module-0123456789abcdef.zip;id",
            "wcs-module-0123456789abcdef.zip\nwhoami",
        )
        for name in invalid:
            with self.subTest(name=name), self.assertRaises(WCSError):
                module_manager._build_magisk_install_stdin(name)

    def test_waydroid_receives_no_magisk_options_in_argv(self):
        remote_name = "wcs-module-0123456789abcdef.zip"
        script = module_manager._build_magisk_install_stdin(remote_name)
        result = subprocess.CompletedProcess(
            args=["waydroid", "shell"],
            returncode=0,
            stdout="Installing module\nWCS_MAGISK_INSTALL_EXIT=0\n",
            stderr="",
        )
        with mock.patch.object(module_manager, "run_command", return_value=result) as run:
            actual = module_manager._run_magisk_install(remote_name)
        self.assertIs(actual, result)
        run.assert_called_once_with(
            ["waydroid", "shell"],
            check=False,
            input_text=script,
            timeout=900,
        )
        argv = run.call_args.args[0]
        self.assertNotIn("--install-module", argv)

    def test_success_requires_explicit_guest_status_marker(self):
        result = subprocess.CompletedProcess(
            args=["waydroid", "shell"], returncode=0,
            stdout="WCS_MAGISK_INSTALL_EXIT=0\n", stderr="",
        )
        self.assertIn("WCS_MAGISK_INSTALL_EXIT=0", module_manager._check_magisk_install_result(result))

    def test_missing_guest_status_marker_is_not_treated_as_success(self):
        result = subprocess.CompletedProcess(
            args=["waydroid", "shell"], returncode=0, stdout="", stderr="",
        )
        with self.assertRaisesRegex(WCSError, "sem confirmar a execução"):
            module_manager._check_magisk_install_result(result)

    def test_guest_magisk_failure_is_reported_even_if_waydroid_shell_exits_zero(self):
        result = subprocess.CompletedProcess(
            args=["waydroid", "shell"], returncode=0,
            stdout="installation failed\nWCS_MAGISK_INSTALL_EXIT=2\n", stderr="",
        )
        with self.assertRaisesRegex(WCSError, "Código Magisk: 2"):
            module_manager._check_magisk_install_result(result)

    def test_waydroid_shell_failure_is_reported_even_if_guest_marker_is_zero(self):
        result = subprocess.CompletedProcess(
            args=["waydroid", "shell"], returncode=1,
            stdout="WCS_MAGISK_INSTALL_EXIT=0\n", stderr="lxc-attach failed",
        )
        with self.assertRaisesRegex(WCSError, "Código Waydroid: 1"):
            module_manager._check_magisk_install_result(result)

    def test_install_module_stages_zip_and_checks_magisk_result(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data_path = root / "data"
            modules = data_path / "adb/modules"
            updates = data_path / "adb/modules_update"
            modules.mkdir(parents=True)
            updates.mkdir(parents=True)
            module_zip = root / "test-module.zip"
            with zipfile.ZipFile(module_zip, "w") as archive:
                archive.writestr("module.prop", "id=sample\nname=Sample Module\nversion=1.0\n")
                archive.writestr("service.sh", "#!/system/bin/sh\n")
            checksum = hashlib.sha256(module_zip.read_bytes()).hexdigest()
            remote_name = f"wcs-module-{checksum[:16]}.zip"
            observed: dict[str, object] = {}

            def fake_install(name: str):
                observed["name"] = name
                staged = data_path / "local/tmp" / name
                observed["staged_exists"] = staged.is_file()
                observed["staged_sha256"] = hashlib.sha256(staged.read_bytes()).hexdigest()
                target = modules / "sample"
                target.mkdir()
                (target / "module.prop").write_text(
                    "id=sample\nname=Sample Module\n", encoding="utf-8"
                )
                return subprocess.CompletedProcess(
                    args=["waydroid", "shell"], returncode=0,
                    stdout="WCS_MAGISK_INSTALL_EXIT=0\n", stderr="",
                )

            with mock.patch.object(module_manager, "_require_running", return_value={}), \
                 mock.patch.object(module_manager, "_module_roots", return_value=(modules, updates)), \
                 mock.patch.object(module_manager, "_run_magisk_install", side_effect=fake_install):
                result = module_manager.install_module(module_zip)

            self.assertEqual(observed["name"], remote_name)
            self.assertTrue(observed["staged_exists"])
            self.assertEqual(observed["staged_sha256"], checksum)
            self.assertFalse((data_path / "local/tmp" / remote_name).exists())
            self.assertEqual(result["id"], "sample")
            self.assertEqual(result["sha256"], checksum)

    def test_staged_zip_is_removed_when_magisk_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data_path = root / "data"
            modules = data_path / "adb/modules"
            updates = data_path / "adb/modules_update"
            modules.mkdir(parents=True)
            updates.mkdir(parents=True)
            module_zip = root / "test-module.zip"
            with zipfile.ZipFile(module_zip, "w") as archive:
                archive.writestr("module.prop", "id=sample\nname=Sample Module\n")
            checksum = hashlib.sha256(module_zip.read_bytes()).hexdigest()
            remote_name = f"wcs-module-{checksum[:16]}.zip"

            def failed_install(name: str):
                staged = data_path / "local/tmp" / name
                self.assertTrue(staged.is_file())
                return subprocess.CompletedProcess(
                    args=["waydroid", "shell"], returncode=0,
                    stdout="WCS_MAGISK_INSTALL_EXIT=2\n", stderr="module rejected",
                )

            with mock.patch.object(module_manager, "_require_running", return_value={}), \
                 mock.patch.object(module_manager, "_module_roots", return_value=(modules, updates)), \
                 mock.patch.object(module_manager, "_run_magisk_install", side_effect=failed_install):
                with self.assertRaisesRegex(WCSError, "Código Magisk: 2"):
                    module_manager.install_module(module_zip)

            self.assertFalse((data_path / "local/tmp" / remote_name).exists())


if __name__ == "__main__":
    unittest.main()
