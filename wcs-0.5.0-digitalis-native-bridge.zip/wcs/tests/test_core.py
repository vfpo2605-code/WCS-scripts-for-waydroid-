# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations

import json
import os
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

from core import backup, detection, image_manager, module_manager, root_manager
from core.common import WCSError, ensure_no_symlink_path, sha256_file


class DetectionTests(unittest.TestCase):
    def test_infer_android_channel_versions(self):
        self.assertEqual(detection.infer_android_version("https://host/ota/a16-qpr2/system"), "16")
        self.assertEqual(detection.infer_android_version("https://host/ota/a17-qpr0/vendor"), "17")
        self.assertEqual(detection.infer_android_version("", "20260717"), "16")
        self.assertEqual(detection.infer_android_version("", "20261017"), "17")
        self.assertEqual(detection.infer_android_version("https://host/a14"), "UNKNOWN")

    def test_android_sdk_mapping_covers_official_waydroid_generations(self):
        self.assertEqual(detection.android_from_sdk("30"), "11")
        self.assertEqual(detection.android_from_sdk("33"), "13")
        self.assertEqual(detection.android_from_sdk("36"), "16")
        self.assertEqual(detection.android_from_sdk("37"), "17")
        self.assertEqual(detection.android_from_sdk("999"), "UNKNOWN")

    def test_official_waydroid_channel_detects_rom_type_arch_and_system_type(self):
        parsed = detection.parse_system_channel(
            "https://ota.waydro.id/system/bliss/waydroid_arm64/GAPPS.json"
        )
        self.assertEqual(parsed["channel_kind"], "OFFICIAL_WAYDROID")
        self.assertEqual(parsed["rom_type"], "bliss")
        self.assertEqual(parsed["image_arch"], "arm64")
        self.assertEqual(parsed["system_type"], "GAPPS")

    def test_preinstalled_image_source_is_distinguished_from_ota(self):
        parsed = detection.parse_system_channel("None")
        self.assertEqual(parsed["channel_kind"], "PREINSTALLED_OR_NO_OTA")

    def test_arm64_waydroid_alias_maps_to_arm64_guest_abis(self):
        self.assertEqual(root_manager._arch_pair({"arch": "arm64"}), ("arm64-v8a", "armeabi-v7a"))

    def test_frozen_container_is_not_considered_stopped(self):
        with self.assertRaises(WCSError):
            detection.require_stopped({"running": True, "status": {"session": "STOPPED", "container": "FROZEN"}})

    def test_direct_lxc_running_state_blocks_write_even_if_waydroid_status_says_stopped(self):
        with self.assertRaises(WCSError):
            detection.require_stopped({
                "running": True,
                "status": {"session": "STOPPED", "container": "STOPPED"},
                "lxc_state": "RUNNING",
            })


class PathSafetyTests(unittest.TestCase):
    def test_safe_path_is_beneath_base(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            path = ensure_no_symlink_path(base, "alpha/beta")
            self.assertEqual(path, base.absolute() / "alpha/beta")

    def test_verified_download_refuses_symlink_destination(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            outside = root / "outside.apk"
            outside.write_bytes(b"trusted")
            destination = root / "cache.apk"
            destination.symlink_to(outside)
            with self.assertRaises(WCSError):
                from core.common import download_verified
                download_verified("https://example.invalid/file", destination, sha256_file(outside))
            self.assertEqual(outside.read_bytes(), b"trusted")

    def test_reject_parent_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(WCSError):
                ensure_no_symlink_path(Path(temp), "../outside")

    def test_reject_symlink_component(self):
        with tempfile.TemporaryDirectory() as temp, tempfile.TemporaryDirectory() as outside:
            base = Path(temp)
            (base / "link").symlink_to(outside, target_is_directory=True)
            with self.assertRaises(WCSError):
                ensure_no_symlink_path(base, "link/file")

    def test_reject_symlinked_base(self):
        with tempfile.TemporaryDirectory() as outside, tempfile.TemporaryDirectory() as temp:
            link = Path(temp) / "base-link"
            link.symlink_to(outside, target_is_directory=True)
            with self.assertRaises(WCSError):
                ensure_no_symlink_path(link, "file")


class PatchTests(unittest.TestCase):
    def test_patch_changes_only_expected_bytes(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "magisk"
            path.write_bytes(b"\x00" * 16 + bytes.fromhex("aabbccdd") + b"\x00" * 16)
            root_manager._apply_patch(path, 16, "aabbccdd", "11223344")
            self.assertEqual(path.read_bytes()[16:20], bytes.fromhex("11223344"))

    def test_patch_refuses_unexpected_binary(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "magisk"
            path.write_bytes(b"\x00" * 64)
            with self.assertRaises(WCSError):
                root_manager._apply_patch(path, 16, "aabbccdd", "11223344")

    def test_patch_rejects_unequal_sizes(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "magisk"
            path.write_bytes(b"\x00" * 64)
            with self.assertRaises(WCSError):
                root_manager._apply_patch(path, 16, "aabb", "112233")

    def test_extract_magisk_fixture_validates_exact_patch_set(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            apk = temp_path / "fake-magisk.apk"
            stage = temp_path / "stage"
            magisk64 = bytearray(b"\x00" * (0x3B232 + 8))
            magisk64[0x27B2D:0x27B2D + 13] = bytes.fromhex("e84e0d0000837c2410008844240f")
            magisk64[0x3B232:0x3B232 + 2] = bytes.fromhex("7514")
            magisk32 = bytearray(b"\x00" * (0x3E66F + 8))
            magisk32[0x3E66F:0x3E66F + 2] = bytes.fromhex("7512")
            with zipfile.ZipFile(apk, "w", zipfile.ZIP_DEFLATED) as archive:
                archive.writestr("lib/x86_64/libmagisk.so", magisk64)
                archive.writestr("lib/x86_64/libmagiskpolicy.so", b"policy")
                archive.writestr("lib/x86_64/libbusybox.so", b"busybox")
                archive.writestr("lib/x86/libmagisk.so", magisk32)
                archive.writestr("assets/addon.d.sh", "#!/system/bin/sh\n")
            root_manager._extract_magisk(apk, stage, "x86_64", "x86")
            out64 = (stage / "magisk").read_bytes()
            out32 = (stage / "magisk32").read_bytes()
            self.assertEqual(out64[0x3B232:0x3B234], bytes.fromhex("9090"))
            self.assertEqual(out32[0x3E66F:0x3E671], bytes.fromhex("9090"))
            self.assertTrue((stage / "setup.sh").is_file())
            self.assertTrue((stage / "stub.apk").is_file())


class ModuleZipTests(unittest.TestCase):
    def _zip(self, path: Path, prop: str = "id=example\nname=Example\nversion=1.0\n"):
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("module.prop", prop)
            archive.writestr("service.sh", "#!/system/bin/sh\n")

    def test_valid_module_zip(self):
        with tempfile.TemporaryDirectory() as temp:
            zip_path = Path(temp) / "module.zip"
            self._zip(zip_path)
            module_id, prop = module_manager._validate_module_zip(zip_path)
            self.assertEqual(module_id, "example")
            self.assertEqual(prop["name"], "Example")

    def test_module_requires_root_module_prop(self):
        with tempfile.TemporaryDirectory() as temp:
            zip_path = Path(temp) / "module.zip"
            with zipfile.ZipFile(zip_path, "w") as archive:
                archive.writestr("nested/module.prop", "id=example\n")
            with self.assertRaises(WCSError):
                module_manager._validate_module_zip(zip_path)

    def test_module_rejects_path_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            zip_path = Path(temp) / "module.zip"
            with zipfile.ZipFile(zip_path, "w") as archive:
                archive.writestr("module.prop", "id=example\n")
                archive.writestr("../escape", "not safe")
            with self.assertRaises(WCSError):
                module_manager._validate_module_zip(zip_path)

    def test_module_rejects_windows_drive_and_dot_paths(self):
        for unsafe in ("C:/escape", "./module.prop"):
            with self.subTest(path=unsafe), tempfile.TemporaryDirectory() as temp:
                zip_path = Path(temp) / "module.zip"
                with zipfile.ZipFile(zip_path, "w") as archive:
                    archive.writestr("module.prop", "id=example\n")
                    archive.writestr(unsafe, "not safe")
                with self.assertRaises(WCSError):
                    module_manager._validate_module_zip(zip_path)

    def test_module_id_must_be_safe(self):
        with tempfile.TemporaryDirectory() as temp:
            zip_path = Path(temp) / "module.zip"
            self._zip(zip_path, "id=../escape\n")
            with self.assertRaises(WCSError):
                module_manager._validate_module_zip(zip_path)


class BackupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.images = self.root / "images"
        self.images.mkdir()
        (self.images / "system.img").write_bytes(b"system-original")
        (self.images / "vendor.img").write_bytes(b"vendor-original")
        self.backup_dir = self.root / "backups"
        self._backup_dir = backup.BACKUP_DIR
        backup.BACKUP_DIR = self.backup_dir
        self.info = {
            "running": False,
            "status": {"session": "STOPPED", "container": "STOPPED"},
            "images_path": str(self.images),
        }
        self.inspect_patch = mock.patch("core.backup.inspect", return_value=self.info)
        self.stop_patch = mock.patch("core.backup.require_stopped", return_value=None)
        self.inspect_patch.start()
        self.stop_patch.start()

    def tearDown(self):
        self.inspect_patch.stop()
        self.stop_patch.stop()
        backup.BACKUP_DIR = self._backup_dir
        self.temp.cleanup()

    def test_create_and_restore_pair(self):
        path = backup.create_backup()
        manifest = json.loads((path / "manifest.json").read_text())
        self.assertEqual(set(manifest["files"]), {"system.img", "vendor.img"})
        (self.images / "system.img").write_bytes(b"new-system")
        (self.images / "vendor.img").write_bytes(b"new-vendor")
        before = backup.restore_backup(path.name)
        self.assertEqual((self.images / "system.img").read_bytes(), b"system-original")
        self.assertEqual((self.images / "vendor.img").read_bytes(), b"vendor-original")
        self.assertTrue((before / "manifest.json").is_file())

    def test_restore_refuses_corrupt_backup(self):
        path = backup.create_backup()
        (path / "system.img").write_bytes(b"tampered")
        with self.assertRaises(WCSError):
            backup.restore_backup(path.name)

    def test_restore_rejects_non_object_manifest_without_traceback(self):
        path = backup.create_backup()
        (path / "manifest.json").write_text("[]")
        with self.assertRaises(WCSError):
            backup.restore_backup(path.name)

    def test_backup_root_symlink_is_rejected(self):
        outside = self.root / "outside"
        outside.mkdir()
        link = self.root / "linked-backups"
        link.symlink_to(outside, target_is_directory=True)
        backup.BACKUP_DIR = link / "images"
        with self.assertRaises(WCSError):
            backup.list_backups()


class OfficialImageCatalogTests(unittest.TestCase):
    def test_catalog_queries_official_manifest_and_reads_latest_sha256(self):
        digest = "b" * 64
        manifest_url = "https://ota.waydro.id/system/lineage/waydroid_x86_64/VANILLA.json"
        manifest = {"response": [{
            "datetime": 1790539062,
            "filename": "lineage-20.0-20260927-VANILLA-waydroid_x86_64-system.zip",
            "id": digest,
            "size": 1024,
            "url": "https://sourceforge.net/example.zip",
            "version": "20.0",
        }]}
        with mock.patch("core.image_manager.fetch_json", return_value=manifest) as fetch:
            result = image_manager.official_image_catalog(
                arch="x86_64", rom_type="lineage", system_type="VANILLA"
            )
        fetch.assert_called_once_with(manifest_url)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["source"], "OFFICIAL_WAYDROID_OTA")
        self.assertEqual(result[0]["latest"]["sha256"], digest)
        self.assertEqual(result[0]["latest"]["version"], "20.0")

    def test_catalog_skips_combinations_not_published_upstream(self):
        manifest = {"response": [{
            "datetime": 10, "filename": "x.zip", "id": "c" * 64,
            "size": 10, "url": "https://sourceforge.net/x.zip", "version": "20.0",
        }]}
        def lookup(url):
            if "/lineage/" in url and url.endswith("/VANILLA.json"):
                return manifest
            raise WCSError("Servidor respondeu HTTP 404: " + url)
        with mock.patch("core.image_manager.fetch_json", side_effect=lookup):
            result = image_manager.official_image_catalog(arch="x86_64")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["system_type"], "VANILLA")
        self.assertEqual(result[0]["rom_type"], "lineage")

    def test_catalog_rejects_unknown_architecture(self):
        with self.assertRaisesRegex(WCSError, "Arquitetura Waydroid inválida"):
            image_manager.official_image_catalog(arch="mips64")


class OtaManifestTests(unittest.TestCase):
    def setUp(self):
        import configparser
        self.cfg = configparser.ConfigParser(interpolation=None)
        self.cfg["waydroid"] = {
            "system_ota": "https://ota.example/a16/system",
            "vendor_ota": "https://ota.example/a16/vendor",
            "system_datetime": "10",
            "vendor_datetime": "15",
        }

    def test_reads_configured_system_and_vendor_manifest(self):
        digest = "a" * 64
        manifests = {
            "https://ota.example/a16/system": {
                "response": [
                    {"datetime": 11, "id": digest, "filename": "system-new.zip", "size": 1024, "url": "https://cdn.example/system.zip"},
                    {"datetime": 9, "id": digest, "filename": "system-old.zip", "size": 512, "url": "https://cdn.example/old.zip"},
                ]
            },
            "https://ota.example/a16/vendor": {
                "response": [{"datetime": 14, "id": digest, "filename": "vendor.zip", "size": 2048, "url": "https://cdn.example/vendor.zip"}]
            },
        }
        with mock.patch("core.image_manager.load_waydroid_config", return_value=self.cfg), mock.patch(
            "core.image_manager.fetch_json", side_effect=lambda url: manifests[url]
        ):
            result = image_manager.inspect_ota_channels()
        self.assertEqual([item["component"] for item in result], ["system", "vendor"])
        self.assertTrue(result[0]["builds"][0]["newer_than_installed"])
        self.assertFalse(result[1]["builds"][0]["newer_than_installed"])
        self.assertEqual(result[0]["builds"][0]["sha256"], digest)

    def test_rejects_manifest_without_response_list(self):
        with mock.patch("core.image_manager.load_waydroid_config", return_value=self.cfg), mock.patch(
            "core.image_manager.fetch_json", return_value={"not_response": []}
        ):
            with self.assertRaises(WCSError):
                image_manager.inspect_ota_channels()

    def test_unconfigured_channel_is_not_guessed(self):
        self.cfg["waydroid"]["vendor_ota"] = ""
        with mock.patch("core.image_manager.load_waydroid_config", return_value=self.cfg), mock.patch(
            "core.image_manager.fetch_json", return_value={"response": []}
        ) as fetch:
            result = image_manager.inspect_ota_channels()
        self.assertEqual(result[1]["status"], "NO_CHANNEL_CONFIGURED")
        self.assertEqual(fetch.call_count, 1)




class WaydroidShutdownTests(unittest.TestCase):
    def test_stop_requests_session_before_container_and_waits_for_stopped_state(self):
        running = {"session": "RUNNING", "container": "RUNNING", "raw": "Session: RUNNING\nContainer: RUNNING"}
        stopping = {"session": "STOPPED", "container": "STOPPING", "raw": "Session: STOPPED\nContainer: STOPPING"}
        stopped = {"session": "STOPPED", "container": "STOPPED", "raw": "Session: STOPPED\nContainer: STOPPED"}
        with mock.patch("core.root_manager.run_command") as run, mock.patch(
            "core.root_manager.get_status", side_effect=[stopping, stopped]
        ), mock.patch("core.root_manager._lxc_status", side_effect=["RUNNING", "STOPPED"]), mock.patch(
            "core.root_manager.time.sleep"
        ) as sleep:
            root_manager._stop_waydroid({"waydroid_root": "/var/lib/waydroid", "status": running})
        self.assertEqual(run.call_args_list[0].args[0], ["waydroid", "session", "stop"])
        self.assertEqual(run.call_args_list[1].args[0], ["waydroid", "container", "stop"])
        sleep.assert_called_once_with(0.5)

    def test_stop_times_out_when_either_layer_stays_active(self):
        running = {"session": "STOPPED", "container": "RUNNING", "raw": "Container: RUNNING"}
        with mock.patch("core.root_manager.run_command"), mock.patch(
            "core.root_manager.get_status", return_value=running
        ), mock.patch("core.root_manager._lxc_status", return_value="RUNNING"), mock.patch(
            "core.root_manager.time.monotonic", side_effect=[0.0, 0.1, 2.0]
        ), mock.patch("core.root_manager.time.sleep"):
            with self.assertRaises(WCSError):
                root_manager._stop_waydroid({"waydroid_root": "/var/lib/waydroid"}, timeout=1.0)


class BootanimSourceTests(unittest.TestCase):
    def test_reads_existing_overlay_override_first(self):
        with tempfile.TemporaryDirectory() as temp:
            overlay = Path(temp) / "overlay"
            path = overlay / "system/etc/init/bootanim.rc"
            path.parent.mkdir(parents=True)
            path.write_text("service bootanim /system/bin/bootanimation\n")
            with mock.patch("core.root_manager._read_bootanim_from_system_image") as image_read:
                content, mode, source = root_manager._load_original_bootanim(overlay, {"images_path": temp})
            self.assertIn(b"service bootanim", content)
            self.assertEqual(source, "overlay")
            image_read.assert_not_called()

    def test_reads_from_system_image_when_overlay_is_only_an_empty_layer(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            overlay = root / "overlay"
            overlay.mkdir()
            image = root / "images"
            image.mkdir()
            (image / "system.img").write_bytes(b"image-placeholder")
            expected = b"service bootanim /system/bin/bootanimation\n"

            def fake_command(argv, **kwargs):
                if argv[0] == "mount":
                    mountpoint = Path(argv[-1])
                    target = mountpoint / "system/etc/init/bootanim.rc"
                    target.parent.mkdir(parents=True)
                    target.write_bytes(expected)
                return type("Result", (), {"returncode": 0, "stdout": "", "stderr": ""})()

            with mock.patch("core.root_manager.run_command", side_effect=fake_command) as command:
                content, mode = root_manager._read_bootanim_from_system_image({"images_path": str(image)})
            self.assertEqual(content, expected)
            self.assertTrue(any(call.args[0][0] == "mount" for call in command.call_args_list))
            self.assertTrue(any(call.args[0][0] == "umount" for call in command.call_args_list))

    def test_missing_overlay_file_is_not_backed_up_as_existing(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            overlay = root / "overlay"
            overlay.mkdir()
            old_state_dir = root_manager.STATE_DIR
            old_root_state = root_manager.ROOT_STATE
            old_baseline = root_manager.BASELINE
            root_manager.STATE_DIR = root / "state"
            root_manager.ROOT_STATE = root_manager.STATE_DIR / "root-state"
            root_manager.BASELINE = root_manager.ROOT_STATE / "baseline"
            try:
                root_manager._snapshot_overlay(overlay)
                manifest = json.loads((root_manager.BASELINE / "manifest.json").read_text())
                self.assertFalse(manifest["paths"][root_manager.BOOTANIM_REL]["exists"])
            finally:
                root_manager.STATE_DIR = old_state_dir
                root_manager.ROOT_STATE = old_root_state
                root_manager.BASELINE = old_baseline

    def test_refuses_bootanim_override_in_waydroid_upper_layer(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            upper = root / "overlay_rw/system/system/etc/init/bootanim.rc"
            upper.parent.mkdir(parents=True)
            upper.write_text("custom user override\n")
            with self.assertRaises(WCSError):
                root_manager._check_upper_layer_conflicts({"overlay_rw": str(root / "overlay_rw")})
            self.assertEqual(upper.read_text(), "custom user override\n")


class RootSnapshotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.overlay = self.root / "overlay"
        self.init_dir = self.overlay / "system/etc/init"
        self.init_dir.mkdir(parents=True)
        self.bootanim = self.init_dir / "bootanim.rc"
        self.bootanim.write_text("service bootanim /system/bin/bootanimation\n    class core animation\n")
        self.old_state_dir = root_manager.STATE_DIR
        self.old_root_state = root_manager.ROOT_STATE
        self.old_baseline = root_manager.BASELINE
        root_manager.STATE_DIR = self.root / "wcs-state"
        root_manager.ROOT_STATE = root_manager.STATE_DIR / "root-state"
        root_manager.BASELINE = root_manager.ROOT_STATE / "baseline"

    def tearDown(self):
        root_manager.STATE_DIR = self.old_state_dir
        root_manager.ROOT_STATE = self.old_root_state
        root_manager.BASELINE = self.old_baseline
        self.temp.cleanup()

    def test_snapshot_and_restore_original_overlay(self):
        original = self.bootanim.read_bytes()
        root_manager._snapshot_overlay(self.overlay)
        (self.init_dir / "bootanim.rc").write_text("modified\n")
        (self.init_dir / "magisk").mkdir()
        (self.init_dir / "magisk/tool").write_text("installed")
        root_manager._restore_overlay(self.overlay)
        self.assertEqual(self.bootanim.read_bytes(), original)
        self.assertFalse((self.init_dir / "magisk").exists())
        self.assertTrue((root_manager.BASELINE / "manifest.json").is_file())

    def test_snapshot_refuses_symlink_in_owned_tree(self):
        (self.init_dir / "magisk").mkdir()
        (self.init_dir / "magisk/link").symlink_to(self.root, target_is_directory=True)
        with self.assertRaises(WCSError):
            root_manager._snapshot_overlay(self.overlay)

    def test_restore_validates_entire_snapshot_before_mutating_overlay(self):
        root_manager._snapshot_overlay(self.overlay)
        saved_system = root_manager.BASELINE / "files/system"
        moved = root_manager.BASELINE / "files/system.saved"
        saved_system.rename(moved)
        saved_system.symlink_to(self.root, target_is_directory=True)
        original_live = self.bootanim.read_bytes()
        self.bootanim.write_text("changed after snapshot\n")
        with self.assertRaises(WCSError):
            root_manager._restore_overlay(self.overlay)
        self.assertEqual(self.bootanim.read_text(), "changed after snapshot\n")
        self.assertNotEqual(self.bootanim.read_bytes(), original_live)

    def test_restore_rejects_symlinked_manifest(self):
        root_manager._snapshot_overlay(self.overlay)
        manifest = root_manager.BASELINE / "manifest.json"
        outside = self.root / "other-manifest.json"
        outside.write_text(manifest.read_text())
        manifest.unlink()
        manifest.symlink_to(outside)
        changed = self.init_dir / "bootanim.rc"
        changed.write_text("do not overwrite\n")
        with self.assertRaises(WCSError):
            root_manager._restore_overlay(self.overlay)
        self.assertEqual(changed.read_text(), "do not overwrite\n")


class ModuleFilesystemTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.modules = self.root / "data/adb/modules"
        self.updates = self.root / "data/adb/modules_update"
        self.modules.mkdir(parents=True)
        self.updates.mkdir(parents=True)
        self.module = self.modules / "example"
        self.module.mkdir()
        (self.module / "module.prop").write_text("id=example\nname=Example\n")
        self.roots_patch = mock.patch("core.module_manager._module_roots", return_value=(self.modules, self.updates))
        self.roots_patch.start()

    def tearDown(self):
        self.roots_patch.stop()
        self.temp.cleanup()

    def test_list_skips_symlinked_module_prop(self):
        outside = self.root / "outside.prop"
        outside.write_text("id=example\nname=External\n")
        (self.module / "module.prop").unlink()
        (self.module / "module.prop").symlink_to(outside)
        self.assertEqual(module_manager.list_modules(), [])

    def test_find_module_rejects_symlinked_module_prop(self):
        outside = self.root / "outside.prop"
        outside.write_text("id=example\nname=External\n")
        (self.module / "module.prop").unlink()
        (self.module / "module.prop").symlink_to(outside)
        with self.assertRaises(WCSError):
            module_manager._find_module("example")

    def test_disable_rejects_symlink_marker(self):
        outside = self.root / "outside"
        outside.write_text("outside")
        (self.module / "disable").symlink_to(outside)
        with mock.patch("core.module_manager._require_running", return_value={}), mock.patch(
            "core.module_manager._find_module", return_value=self.module
        ):
            with self.assertRaises(WCSError):
                module_manager.set_module_state("example", enabled=False)
        self.assertEqual(outside.read_text(), "outside")

    def test_remove_queues_marker_before_clearing_disable(self):
        (self.module / "disable").write_text("")
        with mock.patch("core.module_manager._require_running", return_value={}), mock.patch(
            "core.module_manager._find_module", return_value=self.module
        ):
            module_manager.queue_module_removal("example")
        self.assertTrue((self.module / "remove").is_file())
        self.assertFalse((self.module / "disable").exists())

if __name__ == "__main__":
    unittest.main()


class ExtrasValidationTests(unittest.TestCase):
    def test_package_name_validation(self):
        from core.extras import validate_package_name
        self.assertEqual(validate_package_name("com.example.app"), "com.example.app")
        for invalid in ("", "com..app", ".example.app", "com.example.", "com/example/app", "com.example;id"):
            with self.subTest(invalid=invalid), self.assertRaises(Exception):
                validate_package_name(invalid)

    def test_apk_validation_requires_manifest(self):
        import tempfile
        import zipfile
        from pathlib import Path
        from core.extras import validate_apk
        with tempfile.TemporaryDirectory() as tmp:
            good = Path(tmp) / "good.apk"
            with zipfile.ZipFile(good, "w") as archive:
                archive.writestr("AndroidManifest.xml", b"manifest")
            self.assertEqual(validate_apk(good), good.resolve())
            bad = Path(tmp) / "bad.apk"
            with zipfile.ZipFile(bad, "w") as archive:
                archive.writestr("not-an-apk.txt", b"no")
            with self.assertRaises(Exception):
                validate_apk(bad)

    def test_apk_rejects_symlink(self):
        import tempfile
        from pathlib import Path
        from core.extras import validate_apk
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "target.apk"
            target.write_bytes(b"x")
            link = Path(tmp) / "link.apk"
            link.symlink_to(target)
            with self.assertRaises(Exception):
                validate_apk(link)


class ExtrasCommandTests(unittest.TestCase):
    def test_install_apk_uses_waydroid_app_install(self):
        import tempfile
        import zipfile
        from pathlib import Path
        from unittest import mock
        from core import extras
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "sample.apk"
            with zipfile.ZipFile(apk, "w") as archive:
                archive.writestr("AndroidManifest.xml", b"manifest")
            with mock.patch.object(extras, "_require_running", return_value={}), mock.patch.object(
                extras, "run_command", return_value=mock.Mock(returncode=0, stdout="Success", stderr="")
            ) as run:
                result = extras.install_apk(apk)
            self.assertEqual(result["output"], "Success")
            self.assertEqual(run.call_args.args[0][:3], ["waydroid", "app", "install"])

    def test_remove_app_rejects_shell_metacharacters(self):
        from unittest import mock
        from core import extras
        with mock.patch.object(extras, "_require_running", return_value={}), mock.patch.object(extras, "run_command") as run:
            with self.assertRaises(Exception):
                extras.remove_app("com.example.app;id")
            run.assert_not_called()

    def test_certification_id_is_extracted_and_validated(self):
        from unittest import mock
        from core import extras
        output = mock.Mock(returncode=0, stdout="1234567890123456\n", stderr="")
        with mock.patch.object(extras, "_require_running", return_value={}), mock.patch.object(
            extras, "run_command", return_value=output
        ):
            self.assertEqual(extras.get_android_id(), "1234567890123456")

    def test_extras_inspection_reports_runtime_package_evidence(self):
        from unittest import mock
        from core import extras
        with mock.patch.object(extras, "_require_running", return_value={"android": "17", "arch": "x86_64"}), mock.patch.object(
            extras, "_shell_value", side_effect=[
                "package:com.google.android.gsf\npackage:com.google.android.gms\npackage:com.android.vending\npackage:org.microg.gms.droidguard",
                "libndk_translation.so",
                "/system/lib64/libwvdrmengine.so",
            ]
        ), mock.patch.object(extras, "_run_microg_probe", return_value={"status": "PROBED"}):
            result = extras.inspect_extras()
        self.assertTrue(result["google_services_framework"])
        self.assertTrue(result["google_play_services"])
        self.assertTrue(result["google_play_store"])
        self.assertEqual(result["microg_related_packages"], ["org.microg.gms.droidguard"])
        self.assertEqual(result["microg_diagnostics"]["status"], "PROBED")
        self.assertEqual(result["native_bridge_property"], "libndk_translation.so")
        self.assertEqual(result["widevine_library_paths"], ["/system/lib64/libwvdrmengine.so"])

    def test_microg_probe_parser_reports_evidence_without_claiming_authentication(self):
        from core import extras
        output = """WCS_PROBE_BEGIN
WCS_PATH=com.google.android.gms
WCS_PATH=org.microg.gms
WCS_PATH=com.example.untrusted
WCS_ENABLED=com.google.android.gms
WCS_PRIV=com.google.android.gms
WCS_ALLOWLIST=/system/etc/permissions/privapp-permissions-microg.xml
WCS_ALLOWLIST=relative.xml
WCS_SPOOF_INDICATOR=com.google.android.gms
WCS_WEBVIEW_QUERY_OK
WCS_WEBVIEW_CURRENT=com.android.webview
WCS_CUSTOM_TABS_QUERY_OK
WCS_CUSTOM_TABS_SERVICE
WCS_GSERVICES_DB_PRESENT
WCS_ANDROID_ID_PRESENT
WCS_PROBE_END
"""
        result = extras.parse_microg_probe(output)
        self.assertEqual(result["status"], "PROBED")
        self.assertTrue(result["complete"])
        self.assertEqual(result["packages"]["path_observed"], ["com.google.android.gms", "org.microg.gms"])
        self.assertEqual(result["packages"]["unambiguous_org_microg_hints"], ["org.microg.gms"])
        self.assertEqual(result["privileged_allowlist_files"], ["/system/etc/permissions/privapp-permissions-microg.xml"])
        self.assertEqual(result["signature_spoofing"]["status"], "RUNTIME_REQUIRED")
        self.assertEqual(result["signature_spoofing"]["advisory_indicators"], ["com.google.android.gms"])
        self.assertEqual(result["gservices"], {"database": "PRESENT", "android_id": "PRESENT"})
        self.assertEqual(result["authentication"]["status"], "RUNTIME_REQUIRED")

    def test_microg_probe_parser_rejects_incomplete_or_failed_output(self):
        from core import extras
        result = extras.parse_microg_probe("WCS_PROBE_BEGIN\n", returncode=1, error="permission denied")
        self.assertEqual(result["status"], "PROBE_FAILED")
        self.assertFalse(result["complete"])
        self.assertEqual(result["error"], "permission denied")

    def test_microg_probe_uses_read_only_guest_shell_command(self):
        from core import extras
        output = mock.Mock(returncode=0, stdout="WCS_PROBE_BEGIN\nWCS_PROBE_END\n", stderr="")
        with mock.patch.object(extras, "run_command", return_value=output) as run:
            result = extras._run_microg_probe()
        command = run.call_args.args[0]
        self.assertEqual(command[:5], ["waydroid", "shell", "--", "sh", "-c"])
        self.assertIn(extras.MICROG_PROBE, command)
        self.assertNotIn("--install-module", extras.MICROG_PROBE)
        self.assertNotIn("mknod", extras.MICROG_PROBE)
        self.assertEqual(result["status"], "PROBED")

    def test_microg_command_is_exposed_without_changing_existing_commands(self):
        from core.cli import build_parser
        self.assertEqual(build_parser().parse_args(["microg"]).command, "microg")
        self.assertEqual(build_parser().parse_args(["extras"]).command, "extras")
