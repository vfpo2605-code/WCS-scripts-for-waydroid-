# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations

import tempfile
import zipfile
import unittest
from pathlib import Path
from unittest import mock

from core import arm_translation, feature_manager
from core.common import WCSError


class ArmTranslationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.overlay = self.root / "overlay"
        self.system = self.overlay / "system"
        self.system.mkdir(parents=True)
        self.config = self.root / "waydroid.cfg"
        self.data = self.root / "waydroid-data"
        self.data.mkdir()
        self.config.write_text(
            "[waydroid]\narch = x86_64\nmount_overlays = True\n\n"
            "[properties]\n# keep this comment\n"
            "ro.dalvik.vm.native.bridge = libimage_native_bridge.so\n"
            "persist.waydroid.multi_windows = true\n",
            encoding="utf-8",
        )
        state_dir = self.root / "wcs-state"
        self.state_root = state_dir / "arm-translation"
        self.state_file = self.state_root / "state.json"
        self.patches = [
            mock.patch.object(arm_translation, "STATE_DIR", state_dir),
            mock.patch.object(arm_translation, "STATE_ROOT", self.state_root),
            mock.patch.object(arm_translation, "STATE_FILE", self.state_file),
            mock.patch.object(arm_translation, "inspect", return_value={
                "running": False,
                "android": "13",
                "sdk": "33",
                "host_arch": "x86_64",
                "arch": "x86_64",
                "mount_overlays": "true",
                "overlay_dir": str(self.overlay),
                "config_path": str(self.config),
                "images_path": str(self.root / "images"),
                "data_path": str(self.data),
                "status": {"session": "STOPPED", "container": "STOPPED"},
                "lxc_state": "STOPPED",
            }),
            mock.patch.object(arm_translation, "require_stopped"),
            mock.patch.object(arm_translation, "run_command", return_value=__import__("subprocess").CompletedProcess(["waydroid"], 0, "", "")),
        ]
        for patcher in self.patches:
            patcher.start()
        self.addCleanup(self.temp.cleanup)
        self.addCleanup(lambda: [patcher.stop() for patcher in reversed(self.patches)])

    def _archive(self, feature: str, android: str = "13") -> Path:
        spec = arm_translation.SOURCES[feature][android]
        path = self.root / f"{feature}-{android}.zip"
        root = spec["archive_root"]
        entries = {
            f"{root}/prebuilts/etc/init/{feature}.rc": b"on early-init\n",
            f"{root}/prebuilts/etc/binfmt_misc/arm64": b"binfmt\n",
            f"{root}/prebuilts/lib/arm/libtranslator.so": b"32-bit\n",
            f"{root}/prebuilts/lib64/arm64/libtranslator.so": b"64-bit\n",
            f"{root}/prebuilts/lib64/{REQUIRED[feature]}": b"native-bridge-" + feature.encode(),
        }
        if feature == "libhoudini":
            entries[f"{root}/prebuilts/bin/houdini"] = b"houdini32"
            entries[f"{root}/prebuilts/bin/houdini64"] = b"houdini64"
            entries[f"{root}/prebuilts/lib/libhoudini.so"] = b"houdini32-lib"
        else:
            entries[f"{root}/prebuilts/bin/ndk_translation_program_runner_binfmt_misc"] = b"ndk32"
            entries[f"{root}/prebuilts/bin/ndk_translation_program_runner_binfmt_misc_arm64"] = b"ndk64"
            entries[f"{root}/prebuilts/etc/ld.config.arm.txt"] = b"arm linker config"
            entries[f"{root}/prebuilts/etc/ld.config.arm64.txt"] = b"arm64 linker config"
            entries[f"{root}/prebuilts/etc/init/ndk_translation.rc"] = b"on early-init\n"
        for required in arm_translation.REQUIRED_PAYLOAD[feature]:
            entries[f"{root}/prebuilts/{required}"] = b"payload-" + required.encode()
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
            for name, data in entries.items():
                archive.writestr(name, data)
        return path

    def _install(self, feature: str):
        archive = self._archive(feature)
        with mock.patch.object(arm_translation, "_download_source", return_value=archive):
            return arm_translation.install(feature)

    def test_libndk_installs_even_when_image_already_declares_another_bridge(self):
        destination = self.system / "lib64/libndk_translation.so"
        destination.parent.mkdir(parents=True)
        destination.write_bytes(b"image-provided-ndk-bridge")
        result = self._install("libndk")
        self.assertEqual(result["feature"], "libndk")
        self.assertTrue(result["replaces_image_bridge_override"])
        self.assertEqual(destination.read_bytes(), b"native-bridge-libndk")
        text = self.config.read_text()
        self.assertIn("ro.dalvik.vm.native.bridge = libndk_translation.so", text)
        self.assertIn("persist.waydroid.multi_windows = true", text)
        waydroid_text = text
        self.assertIn("[waydroid]", waydroid_text)
        self.assertIn("ro.dalvik.vm.native.bridge = libndk_translation.so", waydroid_text)
        setting_file = self.data / "misc/waydroid_settings"
        self.assertIn("ro.dalvik.vm.native.bridge=libndk_translation.so", setting_file.read_text())
        self.assertIn("# keep this comment", text)
        self.assertTrue(self.state_file.is_file())

    def test_remove_restores_preexisting_overlay_file_and_properties(self):
        destination = self.system / "lib64/libndk_translation.so"
        destination.parent.mkdir(parents=True)
        destination.write_bytes(b"image-provided-ndk-bridge")
        self._install("libndk")
        message = arm_translation.remove("libndk")
        self.assertIn("libndk removido", message)
        self.assertEqual(destination.read_bytes(), b"image-provided-ndk-bridge")
        text = self.config.read_text()
        self.assertIn("ro.dalvik.vm.native.bridge = libimage_native_bridge.so", text)
        self.assertIn("persist.waydroid.multi_windows = true", text)
        self.assertNotIn("ro.dalvik.vm.native.bridge", text.split("[waydroid]", 1)[1].split("[", 1)[0])
        self.assertFalse((self.data / "misc/waydroid_settings").exists())
        self.assertFalse((self.data / "misc").exists())
        self.assertFalse(self.state_root.exists())

    def test_settings_file_and_waydroid_section_are_restored_without_losing_other_entries(self):
        misc = self.data / "misc"
        misc.mkdir()
        settings = misc / "waydroid_settings"
        settings.write_text("persist.waydroid.foo=bar\nro.dalvik.vm.native.bridge=libimage.so\n")
        original_cfg = self.config.read_text()
        self._install("libndk")
        self.assertIn("ro.dalvik.vm.native.bridge=libndk_translation.so", settings.read_text())
        self.assertIn("persist.waydroid.foo=bar", settings.read_text())
        arm_translation.remove("libndk")
        self.assertEqual(settings.read_text(), "persist.waydroid.foo=bar\nro.dalvik.vm.native.bridge=libimage.so\n")
        self.assertEqual(self.config.read_text(), original_cfg)
        self.assertTrue(misc.is_dir())

    def test_switching_translators_restores_baseline_before_installing_other(self):
        ndk_file = self.system / "lib64/libndk_translation.so"
        ndk_file.parent.mkdir(parents=True)
        ndk_file.write_bytes(b"image-ndk")
        houdini_file = self.system / "lib64/libhoudini.so"
        houdini_file.write_bytes(b"image-houdini")
        self._install("libndk")
        result = self._install("libhoudini")
        self.assertEqual(result["active_native_bridge"], "libhoudini.so")
        self.assertEqual(ndk_file.read_bytes(), b"image-ndk")
        self.assertEqual(houdini_file.read_bytes(), b"native-bridge-libhoudini")
        self.assertIn("ro.dalvik.vm.native.bridge = libhoudini.so", self.config.read_text())
        self.assertEqual(arm_translation.status()["active"], "libhoudini")
        houdini_rc = self.system / "etc/init/houdini.rc"
        self.assertTrue(houdini_rc.is_file())
        self.assertIn("/system/bin/houdini64", houdini_rc.read_text())
        self.assertIn("arm64_dyn", houdini_rc.read_text())

    def test_houdini_init_hook_is_generated_and_removed_with_translator(self):
        rc = self.system / "etc/init/houdini.rc"
        rc.parent.mkdir(parents=True)
        rc.write_text("# image-owned Houdini hook\n", encoding="utf-8")
        self._install("libhoudini")
        self.assertIn("arm64_exe", rc.read_text())
        arm_translation.remove("libhoudini")
        self.assertEqual(rc.read_text(), "# image-owned Houdini hook\n")

    def test_android_16_and_17_are_refused_before_download(self):
        for android, sdk in (("16", "36"), ("17", "37")):
            with self.subTest(android=android), mock.patch.object(arm_translation, "inspect", return_value={
                "running": False, "android": android, "sdk": sdk,
                "host_arch": "x86_64", "arch": "x86_64", "mount_overlays": "true",
                "overlay_dir": str(self.overlay), "config_path": str(self.config),
                "status": {"session": "STOPPED", "container": "STOPPED"}, "lxc_state": "STOPPED",
            }), mock.patch.object(arm_translation, "require_stopped"), mock.patch.object(
                arm_translation, "_download_source"
            ) as download:
                with self.assertRaisesRegex(WCSError, f"Android {android}"):
                    arm_translation.install("libndk")
                download.assert_not_called()

    def test_houdini_package_does_not_require_nonexistent_bin_arm_directories(self):
        archive = self._archive("libhoudini", "13")
        stage = self.root / "houdini-real-layout"
        files, dirs = arm_translation._extract_prebuilts(archive, "libhoudini", "13", stage)
        self.assertIn("bin/houdini", files)
        self.assertIn("bin/houdini64", files)
        self.assertIn("lib/arm/libtranslator.so", files)
        self.assertIn("lib64/arm64/libtranslator.so", files)
        self.assertFalse((stage / "bin/arm").exists())
        self.assertFalse((stage / "bin/arm64").exists())

    def test_package_missing_required_upstream_payload_is_rejected(self):
        archive = self.root / "incomplete.zip"
        root = arm_translation.SOURCES["libhoudini"]["13"]["archive_root"]
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr(f"{root}/prebuilts/lib64/libhoudini.so", b"only-library")
            output.writestr(f"{root}/prebuilts/bin/arm64/runner", b"arm64")
        with self.assertRaisesRegex(WCSError, "pacote libhoudini está incompleto"):
            arm_translation._extract_prebuilts(archive, "libhoudini", "13", self.root / "stage-incomplete")

    def test_package_with_path_traversal_is_rejected(self):
        archive = self.root / "bad.zip"
        root = arm_translation.SOURCES["libndk"]["13"]["archive_root"]
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr(f"{root}/prebuilts/../../escape", b"no")
        with self.assertRaises(WCSError):
            arm_translation._extract_prebuilts(archive, "libndk", "13", self.root / "stage")

    def test_catalog_describes_both_installable_mutually_exclusive_alternatives(self):
        catalog = {item["id"]: item for item in feature_manager.catalog()}
        for feature in ("libndk", "libhoudini"):
            self.assertEqual(catalog[feature]["status"], "INSTALLABLE_ANDROID11_13_X86_64")
            self.assertIn("somente um pode ficar ativo", catalog[feature]["description"])


REQUIRED = {
    "libndk": "libndk_translation.so",
    "libhoudini": "libhoudini.so",
}


if __name__ == "__main__":
    unittest.main()
