# Third-party notices and implementation references

WCS is distributed under GPL-3.0-or-later. The project does not bundle Magisk, Zygisk Next,
LSPosed, Android system images, or vendor images. At runtime, the Magisk APK is fetched from
its official GitHub release URL and checked against a pinned SHA-256 value.

## Waydroid Script

- Project: https://github.com/casualsnek/waydroid_script
- License declared by upstream: GPL-3.0
- Reference areas inspected: `stuff/magisk.py`, `stuff/general.py`, `tools/images.py`,
  `tools/container.py`, and the README.
- WCS uses the documented concept of integrating Magisk through Waydroid's system overlay and
  init triggers, rather than the conventional boot-image patch path. WCS does not call the old
  Waydroid Script and does not depend on its download locations.

## Waydroid Manager Magisk integration

- Project: https://github.com/felipeoes/waydroid-manager
- Reference file inspected: `waydroid_manager/daemon/magisk.py`
- Upstream file declares SPDX `GPL-3.0-or-later`.
- The WCS Magisk 31.0 adaptation uses the same publicly documented, version-specific binary
  patch offsets needed for the Waydroid no-SELinux-label environment. This is a derivative
  compatibility technique, not an assertion that WCS has passed the upstream project's tests.
  The WCS code is separately structured and contains additional validation, backup, and rollback
  handling. The upstream project and its license remain credited here.

## ARM Native Bridge payloads (libndk / libhoudini)

- Installer reference: https://github.com/casualsnek/waydroid_script (`stuff/ndk.py`, `stuff/houdini.py`, `stuff/general.py`).
- libndk Android 11 payload: https://github.com/supremegamers/vendor_google_proprietary_ndk_translation-prebuilt/tree/9324a8914b649b885dad6f2bfd14a67e5d1520bf
- libndk Android 13 payload: https://github.com/supremegamers/vendor_google_proprietary_ndk_translation-prebuilt/tree/68734c52556d3d7a6db34c603dd9276915c29f2f
- libhoudini Android 11 payload: https://github.com/supremegamers/vendor_intel_proprietary_houdini/tree/81f2a51ef539a35aead396ab7fce2adf89f46e88
- libhoudini Android 13 payload: https://github.com/supremegamers/vendor_intel_proprietary_houdini/tree/2f8f088671182e17e67321e098e8411a3972a628
- WCS does not bundle these proprietary translator binaries. It downloads the pinned upstream ZIP only at installation time and checks the MD5 value published by the upstream Waydroid Script installer before extracting it.
- libndk is Google's proprietary ARM translation runtime; libhoudini is Intel's proprietary runtime distributed via the Windows Subsystem for Android payload. Their own terms/licensing apply. WCS does not grant additional rights to redistribute or use them.
- Only one Native Bridge provider can be selected through `ro.dalvik.vm.native.bridge` at a time. WCS backs up/restores overlay collisions and Waydroid property overrides when switching or removing providers.
- The pinned upstream payloads are for Android 11 and 13. WCS refuses to apply them to newer Android versions without a matching verified payload.

## Digitalis / Berberis Native Bridge bundle

- Integration reference and pinned binary source: https://github.com/MIXIDtheSilly/Refract/tree/ddef6e6ae7de37dd3e400d6a07d3f18cb21a0ebc/prebuilts/digitalis-qpr2
- Upstream Waydroid integration notes: https://github.com/MIXIDtheSilly/Refract/blob/ddef6e6ae7de37dd3e400d6a07d3f18cb21a0ebc/docs/digitalis_waydroid.md
- Bundle: 74 files for WayDroid-ATV LineageOS 23.2 / Android 16 QPR2, build date 2026-10-08. Manifest Git blob SHA-1 is pinned in `core/digitalis_translation.py`; each artifact is checked against the pinned SHA-256 manifest before installation.
- WCS does not include the translator binaries in its source ZIP. It downloads the pinned files at installation time from `raw.githubusercontent.com` and validates them before writing to the Waydroid overlay.
- The upstream bundle notice identifies Digitalis/Berberis (AOSP `frameworks/libs/binary_translation`) as Apache License 2.0. The guest Bionic libraries retain their AOSP component licenses: predominantly Apache 2.0, Bionic BSD-style, ICU Unicode, BoringSSL OpenSSL/ISC, zlib zlib license, SQLite public domain, and libc++ Apache 2.0 with LLVM exception. See the upstream bundle `NOTICE` at the pinned commit for provenance and details.
- The bundle is distributed upstream "AS IS", without warranty. WCS does not claim to have authored the translator or to provide support/warranty for third-party binaries.
- The QPR2 guest Bionic layout is not interchangeable with Android 16 QPR0 or Android 17. WCS restricts this bundle to the identified QPR2 target and preserves the image's provider on unsupported builds.

## Magisk

- Project and release source: https://github.com/topjohnwu/Magisk
- License and notices: see the upstream repository.
- WCS does not redistribute the APK. It downloads the pinned v31.0 release from the official
  release endpoint and validates SHA-256 before extraction.

## Zygisk Next and LSPosed

- Zygisk Next: https://github.com/LSPosed/ZygiskNext
- LSPosed: https://github.com/LSPosed/LSPosed
- WCS does not bundle either project. Their runtime compatibility is not implied by this notice.

## microG / DresOS Magisk Modules

- Project: https://github.com/The-DresOS-Foundation/DresOS-Magisk-Modules
- WCS discovers the upstream stable microG release through the GitHub Releases API, requires the release asset's published SHA-256 digest, then delegates installation to Magisk.
- WCS does not redistribute the microG module or APK payloads in its source archive.
- The upstream module's Android/API compatibility and signature-spoofing requirements apply; WCS currently blocks Android 17 because API 37 is not documented by the module release.

## F-Droid

- Smart Dock package: https://f-droid.org/packages/cu.axel.smartdock/
- F-Droid Privileged Extension OTA: https://f-droid.org/packages/org.fdroid.fdroid.privileged.ota/
- WCS downloads the official APK/OTA over HTTPS at install time. Smart Dock is installed as a regular APK. The privileged OTA is checked structurally, then repackaged into a systemless Magisk module; the F-Droid APK signing is still enforced by Android Package Manager on installation.

## WayDroid-ATV image channels

- Project: https://github.com/WayDroid-ATV/waydroid-builds
- WCS uses the published OTA channels for the explicit GAPPS/VANILLA image-variant switch. The operation snapshots `system.img` and `vendor.img` before running `waydroid init -f` and `waydroid upgrade`; it does not include `/data` in that image backup.
